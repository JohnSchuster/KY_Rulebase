<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Assessment Summary" entity="global">
      <goal-control attr="xrd_buttonset_selection">
        <caption type="unknown">Click here to determine the radio button set selection</caption>
        <visibility default="enabled" />
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </goal-control>
      <goal-control attr="xrd_nominal_selection">
        <caption type="unknown">Click here to determine nominal selection text</caption>
        <visibility default="enabled" />
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </goal-control>
      <goal-control attr="xrd_selected_emp_status">
        <caption type="unknown">Click here to determine the selected employment status</caption>
        <visibility default="enabled" />
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </goal-control>
      <custom-properties>
        <property name="xRulzCustomScreen">false</property>
        <property name="xRulzScreenId" />
      </custom-properties>
    </screen>
    <screen type="Question" id="s2@Interviews_screens_xint" title="Radio Button Set Tests" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>Tests the selection of a text attribute using jQuery ButtonSet</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 3</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="xrd_buttonset_selection" input-type="Radiobutton">
        <default default="SEL01" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select an Option?</caption>
        <list>
          <option text="Selection 0" default-visibility="true">SEL00</option>
          <option text="Selection 1" default-visibility="true">SEL01</option>
          <option text="Selection 2" default-visibility="true">SEL02</option>
          <option text="Selection 3" default-visibility="true">SEL03</option>
          <option text="Selection 4" default-visibility="true">Selection 4</option>
          <option text="Selection 5" default-visibility="true">Selection 5</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">true</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="xrd_nominal_selection" input-type="Radiobutton">
        <default default="NOM00" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is the nominal selection?</caption>
        <list>
          <option text="Nominal 00" default-visibility="true">NOM00</option>
          <option text="Nominal 01" default-visibility="true">NOM01</option>
          <option text="Nominal 02" default-visibility="true">NOM02</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </input-control>
      <custom-properties>
        <property name="xRulzCustomScreen">false</property>
        <property name="xRulzScreenId" />
      </custom-properties>
    </screen>
    <screen type="Question" id="xrulz_screen_15" title="Employment Status - Lab" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pbsmall"&gt;Below are descriptions of several categories related to loss of employment.&lt;/p&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li class="tbsmall"&gt;Currently Employed (Full-time or part-time)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) You continue working full-time in accordance with your employer's customary full-time work schedule or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;You are working part-time, working on-call, as needed, PRN status&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Leave of Absence&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) On FMLA, Short-term disability, etc.&lt;/li&gt;
	  &lt;li class="nsmall"&gt;You are temporarily away from work for personal reasons and you are expected to return to your position&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tbsmall"&gt;Suspension&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) You are temporarily away from work due to a diciplinary action or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;investigation initiated by your employer&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tbsmall"&gt;Quit&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) An employee may choose to leave a job for changes in personal circumstances, working conditions, prospects of other work, etc.&lt;/li&gt;
	&lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Retired (Voluntary or Involuntary)&lt;/li&gt;
    &lt;ul&gt;
      &lt;li class="nsmall"&gt;(eg.) You voluntarily retired from the workforce, you are  receiving retirement/pension or retainer benefits, or&lt;/li&gt;
      &lt;li class="nsmall"&gt;you retired in accordance with the employer mandqatory retirement policy.&lt;/li&gt;
    &lt;/ul&gt;	  
  &lt;li class="tbsmall"&gt;Discharged (aka. Terminated, fired, let-go, sacked, canned, etc)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) Employer chooses to require the employee to leave, generally, the employer states that it is the fault of the employee:&lt;/li&gt;
	  &lt;li class="nsmall"&gt;attendance, policy violation, work performance, failed drug test, etc.&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Laid Off&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) Position eliminated or a business slow-down occured due to economic cycles or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;the company's need to restructure itself, the firm itself going out of business or a change in the function of the employer&lt;/li&gt;
	     &lt;ul&gt;
		   &lt;li class="nsmall"&gt;(eg.) A certain type of product or service is no longer offered by the company therefore jobs related to that product or service are no longer needed&lt;/li&gt;
		&lt;/ul&gt;
    &lt;/ul&gt;	
  &lt;li class="tbsmall"&gt;Labor Dispute&lt;/li&gt;	
     &lt;ul&gt;
	    &lt;li class="nsmall"&gt;You are a member of a labor union and are involved in ongoing strike actions undertaken by the labor union&lt;/li&gt;
     &lt;/ul&gt;	 
&lt;/ul&gt;  
&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="xrd_selected_emp_status" input-type="Radiobutton">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Which category best describes your status?&lt;/p&gt;</caption>
        <list>
          <option text="Currently Employed" default-visibility="true">ES01</option>
          <option text="Leave Of Abscence" default-visibility="true">ES02</option>
          <option text="Suspended" default-visibility="true">ES03</option>
          <option text="Quit" default-visibility="true">ES04</option>
          <option text="Retired" default-visibility="true">ES05</option>
          <option text="Discharged" default-visibility="true">ES06</option>
          <option text="Laid Off" default-visibility="true">ES07</option>
          <option text="Labor Dispute" default-visibility="true">ES08</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="xRulzUseButtonSet">false</property>
        </custom-properties>
      </input-control>
      <custom-properties>
        <property name="xRulzCustomScreen">true</property>
        <property name="xRulzScreenId">xr_cs_01</property>
      </custom-properties>
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <screen ref="s2@Interviews_screens_xint" />
        <screen ref="xrulz_screen_15" />
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>