<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Assessment Summary" entity="global">
      <goal-control attr="fpr_claimant_is_payable">
        <caption type="unknown">Click here to determine if the claimant is payable (qualifying)</caption>
        <visibility default="enabled" />
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </goal-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items />
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>