<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Kentucky Unemployment Insurance: Eligibility Review" entity="global">
      <control type="Label">
        <visibility attr="rb_label_07" default="true" />
        <caption>&lt;p&gt;This online review includes a series of questions that you are required to answer. &lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="b5@Rules_IC_IO_Visibility_doc" default="true" />
        <caption>&lt;p&gt;Our system is available: Monday to Friday 7:00 AM to 7:00 PM (ET) and Sunday 10:00 AM to 9:00 PM (ET).&lt;/p&gt;&lt;p&gt;You must complete and save your eligibility review within those times.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <goal-control type="Goal" flow="f1@Interviews_Screens_xint">
        <visibility attr="b5@Rules_IC_IO_Visibility_doc" default="enabled" />
        <caption>&lt;h3&gt;Click here to begin your review...&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </goal-control>
      <control type="Label">
        <visibility attr="rb_label_01" default="false" />
        <caption>&lt;br /&gt;&lt;h3&gt;You have completed your eligibility review and may request your benefits.&lt;/h3&gt;&lt;h3&gt;You must return and complete your next eligibility review on : %opa_eri_next_interview_date%.&lt;/h3&gt;&lt;p&gt; To print this information to the default printer, &lt;a href="#" onclick="javascript:window.print();"&gt;click here&lt;/a&gt;&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_13" default="false" />
        <caption>&lt;h3&gt;You have completed your eligibility review. You must return and complete your next eligibility review on : %opa_eri_next_interview_date% . &lt;/h3&gt;&lt;p&gt;To print this information to the default printer, &lt;a href="#" onclick="javascript:window.print();"&gt;click here&lt;/a&gt;&lt;/p&gt;&lt;br&gt;&lt;p&gt;&lt;a style="color:red; font-weight:bold; font-size=22;" &gt;IMPORTANT:&lt;/a&gt;&lt;/style&gt;&lt;/p&gt;&lt;br&gt;&lt;p&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt;Based on answers provided, an issue has been detected and will be  investigated. If more information is needed, you will be contacted.&lt;br&gt;&lt;br&gt;If you are due to request your benefit check this week, you will need to return to this website to request your check&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;{text-decoration:underline;}" &gt; this Friday before 7PM EST.&lt;/a&gt;&lt;/style&gt;&lt;br&gt;&lt;br&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; If you are unable to request your check this week, report to your local office next week.&lt;/a&gt;&lt;/style&gt;&lt;/p&gt;&lt;/br&gt;




</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_09" default="false" />
        <caption>&lt;p&gt;You must have a current claim before completing an eligibility review.&lt;/p&gt;&lt;p&gt; If you are not sure whether you should file a claim, please contact your local office.&lt;/p&gt;&lt;br /&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_18" default="false" />
        <caption>&lt;p&gt;Your review period has closed. In-State customers, please contact your local office for assistance. Out-of-State customers, please contact the Interstate section at 502-564-2384. &lt;/p&gt;&lt;br /&gt;&lt;p&gt;You may close your browser window at this time.&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="opa_label_21" default="false" />
        <caption>&lt;br /&gt;&lt;p&gt;You completed an eligibility review on %i_eri_last_intvw_date%&lt;/p&gt;&lt;p&gt;You cannot complete another interview at this time.&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_15" default="false" />
        <caption>&lt;p&gt;You are not due to complete an eligibility review yet.&lt;/p&gt;&lt;br /&gt;&lt;p&gt;Your next eligibility review date is on %i_eri_date%&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_22" default="false" />
        <caption>&lt;p&gt;Your first eligibility review must be completed at your local unemployment office.&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_16" default="false" />
        <caption>&lt;br /&gt;&lt;p&gt;You stated that you are in school or training. &lt;/p&gt;&lt;p&gt;You may be contacted by your local office to verify that you have been approved to attend the school or training.&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_19" default="false" />
        <caption>&lt;p&gt;You are now required to seek full-time work and register for work with a state employment office to continue receiving Unemployment Insurance.&lt;/p&gt;&lt;br /&gt;&lt;p&gt;You may register online by &lt;a href="https://selfreg.ky.gov"TARGET="_blank"&gt;Click here&lt;/a&gt;  If you live outside of KY, please register with your state of residence. You can find state specific sites by &lt;a href="http://www.careeronestop.org/jobsearch/cos_jobsites.aspx
"TARGET="_blank"&gt;clicking here&lt;/a&gt;&lt;br /&gt;&lt;p&gt;If you need help registering, please contact your local office as soon as possible.&lt;/p&gt;&lt;p&gt;You will be required to enter employer job contacts during your next eligibility review.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label_17" default="false" />
        <caption>&lt;p&gt;You have successfully completed your Interstate Registration. &lt;/p&gt;&lt;/br&gt;&lt;p&gt;You are not due to complete an eligibility review yet.&lt;/p&gt;&lt;br /&gt;&lt;p&gt;Your next eligibility review date is on %i_eri_date%&lt;/p&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility attr="rb_label12" default="false" />
        <caption>&lt;h3&gt;Your Local Office is:&lt;/h3&gt;&lt;table class="kylo"&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_branch%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_address%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_city%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_state%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_zip%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_phone_number%&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;%rb_local_office_hours%&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <goal-control type="Goal" flow="f12@Interviews_Screens_xint">
        <visibility attr="rb_finish_and_save_flow" default="hidden" />
        <caption>Click here to Confirm and Finish Your Review</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </goal-control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s20@Interviews_Screens_xint" title="Your Status Has Been Changed" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Based on the information provided, you are now required to seek full-time work and register with a state employment office to continue receiving Unemployment Insurance.&lt;/h3&gt; &lt;br /&gt;&lt;h3&gt;Once this review is complete, please make sure you register for work.&lt;/h3&gt;&lt;h3&gt;You may register online at &lt;a href="https://selfreg.ky.gov"TARGET="_blank"&gt;click here&lt;/a&gt;&lt;/h3&gt;&lt;h3&gt; If you live outside of KY, please register with your state of residence. You can find state specific sites by &lt;a href="http://www.careeronestop.org/jobsearch/cos_jobsites.aspx
"TARGET="_blank"&gt;clicking here&lt;/a&gt;&lt;/h3&gt; &lt;br /&gt;&lt;h3&gt; If you need help registering, please contact your local office as soon as possible.&lt;/h3&gt;

</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s21@Interviews_Screens_xint" title="Date of your expected return to work" entity="global">
      <input-control type="Date" attr="opa_return_to_prior_emp_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>The date you expect to return to work with your prior employer ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s12@Interviews_Screens_xint" title="Verifying Your Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;You are currently exempt from seeking work or being registered with a state employment office.&lt;/h3&gt;&lt;h3&gt;Please answer the following questions to verify that this is correct.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_returning_to_most_recent" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you returning to work with your most recent employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_assisted_by_labor_union" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you have a labor union to assist you with finding employment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_unemp_labor_dispute" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Is your unemployment due to a labor dispute with your prior employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s19@Interviews_Screens_xint" title="Union Hall Details" entity="global">
      <input-control type="Text" attr="opa_union_hall" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is your union hall name:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_union_hall_phone_number" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is your union hall phone number, Example 222 333 4444 :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s15@Interviews_Screens_xint" title="Veterans" entity="global">
      <input-control type="Statement" attr="opa_you_are_veteran" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you a veteran:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers  are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s18@Interviews_Screens_xint" title="Veteran Separation and Disability" entity="global">
      <input-control type="Statement" attr="opa_disabled_veteran" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you a disabled veteran:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_separated_3_years" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Have you left the military within the last three (3) years:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s65@Interviews_Screens_xint" title="Are you ready for your Eligibility Review?" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;Complete each of the questions and then click the &lt;b&gt;Continue&lt;/b&gt; button to continue to the next screen.&lt;/p&gt;&lt;br /&gt;&lt;p&gt;&lt;b&gt; You should check your answers on each screen carefully before clicking &lt;b&gt;Continue.&lt;/b&gt; &lt;/b&gt;&lt;/p&gt;&lt;br /&gt;&lt;p&gt;Please collect information before starting this interview, such as your list of job contacts, names, addresses and interview results.&lt;/p&gt;&lt;br /&gt;
&lt;p&gt;For security reasons, the web page will time out after 20 minutes of inactivity. Clicking on any button, on any screen, will reset the 20 minute counter. If you time out, you will lose the information you have entered and you will need to start the review again.&lt;/p&gt;&lt;br /&gt;
&lt;p&gt;&lt;b&gt;Use of the browser "Back" button will produce unpredictable results. DO NOT use the browser "Back" button while in this application. At any time during the review, if you want to review your answers, click the Return to Start link at the top of the page and your answers will be saved and you can click Continue through each page again.&lt;/b&gt;&lt;/p&gt;&lt;br&gt;

&lt;p&gt;If you are using a public computer (at a public library, for instance), we suggest that you do not leave the screen unattended. &lt;/p&gt;&lt;br /&gt;
&lt;p&gt;Once you complete the eligibility review, if there are no problems you will be able to request your check.&lt;/p&gt;
&lt;p&gt; If any response requires more review by claims staff, you will receive additional instructions from your local office as soon as possible.&lt;/p&gt;
&lt;br /&gt;
&lt;p&gt;A red  &lt;a style="color:red; font-weight:bold; font-size=16;" &gt;*&lt;/a&gt; &lt;/style&gt; next to a question means that you must supply an answer.&lt;/p&gt;
&lt;br /&gt;
&lt;p&gt;&lt;a style="color:red; font-weight:bold; font-size=16;" &gt;This eligibility review is a requirement to continue receiving Unemployment Insurance. Intentionally submitting false information is a criminal act. Any violation will result in prosecution under KRS.341.370 (2). &lt;/a&gt;&lt;/style&gt;&lt;/p&gt;
&lt;br/&gt;
&lt;p&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt;YOU ARE RESPONSIBLE FOR THE ACCURACY OF ALL YOUR ANSWERS &lt;/a&gt;&lt;/style&gt;&lt;/p&gt;



</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;h3&gt;If you understand these directions and are ready to begin the interview select Yes.&lt;/p&gt;&lt;p&gt;If you are not ready select No.  &lt;br /&gt;Then press the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="rb_ins_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select Yes or No:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="opa_ky_ui_er_saved" title="Save Confirmation" entity="global" attr="rb_screen_save_confirmation_displayed">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Please click the Continue button to see the results of your Eligibility Review.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">True</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s62@Interviews_Screens_xint" title="Your Interview is almost complete" entity="global" attr="rb_screen_intv_comp_disp">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;h2&gt;Do not commit fraud.&lt;/h2&gt;&lt;h3&gt;It is your responsibility to ensure that you have answered all the questions correctly and honestly.&lt;/h3&gt;
</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Select "Yes" to confirm you want to finish and save your eligibility review interview.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Select "No" to return to the Start Page.&lt;/h3&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="rb_fs_confirmed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Finish and Save Your Eligibility Review Interview :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/br&gt;&lt;/br&gt;&lt;a style="color:red; font-weight:bold; font-size=22;" &gt;NOTICE:&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; Please do &lt;a style="color:red; font-weight:bold; font-size=18;{text-decoration:underline;}" &gt;NOT&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; click the Continue button more than &lt;a style="color:red; font-weight:bold; font-size=18;{text-decoration:underline;}" &gt;ONE&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; time.&lt;br&gt;&lt;br/&gt; The system is processing and saving your entries.  This process may take several seconds.&lt;/br&gt;&lt;/br&gt;  If you click the Continue button again during this processing time, some or all of your data could be &lt;a style="color:red; font-weight:bold; font-size=18;{text-decoration:underline;}" &gt;LOST&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; and you will &lt;a style="color:red; font-weight:bold; font-size=18;{text-decoration:underline;}" &gt;NOT&lt;/a&gt;&lt;/style&gt;&lt;a style="color:red; font-weight:bold; font-size=18;" &gt; receive important information regarding your Eligibility Review.&lt;/a&gt;&lt;/style&gt;&lt;/p&gt;
&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s25@Interviews_Screens_xint" title="Interstate Registration for Unemployment Insurance" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;To qualify for unemployment benefits, you must be registered for work with a state employment office (KRS 341.350).&lt;/h3&gt;&lt;p&gt;As an Interstate claimant, you are required to register for work in the state that you live, though you may be seeking work in multiple states.&lt;/p&gt;&lt;p&gt;Please complete the questions below to verify your registration with a state employment office.&lt;/p&gt;&lt;br /&gt;&lt;a style="color:red; font-weight:bold;" &gt;If you have NOT registered for work in your state, then you cannot continue with this review.&lt;/a&gt;&lt;/style&gt;&lt;/p&gt;&lt;br&gt;

</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="opa_registration_state" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Which state did you register with:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Alabama" default-visibility="true">Alabama</option>
          <option text="Alaska" default-visibility="true">Alaska</option>
          <option text="Arkansas" default-visibility="true">Arkansas</option>
          <option text="Arizona" default-visibility="true">Arizona</option>
          <option text="California" default-visibility="true">California</option>
          <option text="Colorado" default-visibility="true">Colorado</option>
          <option text="Connecticut" default-visibility="true">Connecticut</option>
          <option text="District Of Columbia" default-visibility="true">District Of Columbia</option>
          <option text="Delaware" default-visibility="true">Delaware</option>
          <option text="Florida" default-visibility="true">Florida</option>
          <option text="Georgia" default-visibility="true">Georgia</option>
          <option text="Hawaii" default-visibility="true">Hawaii</option>
          <option text="Iowa" default-visibility="true">Iowa</option>
          <option text="Idaho" default-visibility="true">Idaho</option>
          <option text="Illinois" default-visibility="true">Illinois</option>
          <option text="Indiana" default-visibility="true">Indiana</option>
          <option text="Kansas" default-visibility="true">Kansas</option>
          <option text="Kentucky" default-visibility="true">Kentucky</option>
          <option text="Louisiana" default-visibility="true">Louisiana</option>
          <option text="Massachusetts" default-visibility="true">Massachusetts</option>
          <option text="Maryland" default-visibility="true">Maryland</option>
          <option text="Maine" default-visibility="true">Maine</option>
          <option text="Michigan" default-visibility="true">Michigan</option>
          <option text="Minnesota" default-visibility="true">Minnesota</option>
          <option text="Missouri" default-visibility="true">Missouri</option>
          <option text="Mississippi" default-visibility="true">Mississippi</option>
          <option text="Montana" default-visibility="true">Montana</option>
          <option text="North Carolina" default-visibility="true">North Carolina</option>
          <option text="North Dakota" default-visibility="true">North Dakota</option>
          <option text="Nebraska" default-visibility="true">Nebraska</option>
          <option text="New Hampshire" default-visibility="true">New Hampshire</option>
          <option text="New Jersey" default-visibility="true">New Jersey</option>
          <option text="New Mexico" default-visibility="true">New Mexico</option>
          <option text="Nevada" default-visibility="true">Nevada</option>
          <option text="New York" default-visibility="true">New York</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oklahoma" default-visibility="true">Oklahoma</option>
          <option text="Oregon" default-visibility="true">Oregon</option>
          <option text="Pennsylvania" default-visibility="true">Pennsylvania</option>
          <option text="Puerto Rico" default-visibility="true">Puerto Rico</option>
          <option text="Rhode Island" default-visibility="true">Rhode Island</option>
          <option text="South Carolina" default-visibility="true">South Carolina</option>
          <option text="South Dakota" default-visibility="true">South Dakota</option>
          <option text="Tennessee" default-visibility="true">Tennessee</option>
          <option text="Texas" default-visibility="true">Texas</option>
          <option text="Utah" default-visibility="true">Utah</option>
          <option text="Virginia" default-visibility="true">Virginia</option>
          <option text="Virgin Islands" default-visibility="true">Virgin Islands</option>
          <option text="Vermont" default-visibility="true">Vermont</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wisconsin" default-visibility="true">Wisconsin</option>
          <option text="West Virginia" default-visibility="true">West Virginia</option>
          <option text="Wyoming" default-visibility="true">Wyoming</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_interstate_register_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Date registered ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_registration_was_online" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Did you register online at a web site:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers  are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s27@Interviews_Screens_xint" title="Address of your %opa_registration_state% Unemployment Registration Office" entity="global">
      <input-control type="Text" attr="opa_registration_addr_line1" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Address line 1:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_registration_add_line2" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Address line 2:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_registration_town_city" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Town / city :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_registration_zipcode" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Zip code, Examples 12345, 12345 6789:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:10em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="opa_registration_phone_number" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Office phone number, Example 222 333 4444:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers  are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s14@Interviews_Screens_xint" title="Type of Work and Job Search" entity="global">
      <input-control type="Text" attr="opa_selected_naics_category" input-type="Listbox">
        <default default="Accommodation and Food Services" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the general type of work you are looking for:</caption>
        <list>
          <option text="Accommodation and Food Services" default-visibility="true">Accommodation and Food Services</option>
          <option text="Administrative and Support Services" default-visibility="true">Administrative and Support Services</option>
          <option text="Agriculture, Forestry, Fishing and Hunting" default-visibility="true">Agriculture, Forestry, Fishing and Hunting</option>
          <option text="Air Transportation" default-visibility="true">Air Transportation</option>
          <option text="Arts, Entertainment, and Recreation" default-visibility="true">Arts, Entertainment, and Recreation</option>
          <option text="Construction" default-visibility="true">Construction</option>
          <option text="Educational Services" default-visibility="true">Educational Services</option>
          <option text="Finance and Insurance" default-visibility="true">Finance and Insurance</option>
          <option text="Health Care and Social Assistance" default-visibility="true">Health Care and Social Assistance</option>
          <option text="Information" default-visibility="true">Information</option>
          <option text="Manufacturing" default-visibility="true">Manufacturing</option>
          <option text="Management of Companies and Enterprises" default-visibility="true">Management of Companies and Enterprises</option>
          <option text="Mining, Quarrying, and Oil and Gas Extraction" default-visibility="true">Mining, Quarrying, and Oil and Gas Extraction</option>
          <option text="Other Services (except Public Administration)" default-visibility="true">Other Services (except Public Administration)</option>
          <option text="Paper Manufacturing" default-visibility="true">Paper Manufacturing</option>
          <option text="Professional, Scientific, and Technical Services" default-visibility="true">Professional, Scientific, and Technical Services</option>
          <option text="Public Administration" default-visibility="true">Public Administration</option>
          <option text="Real Estate and Rental and Leasing" default-visibility="true">Real Estate and Rental and Leasing</option>
          <option text="Retail Trade" default-visibility="true">Retail Trade</option>
          <option text="Transportation and Warehousing" default-visibility="true">Transportation and Warehousing</option>
          <option text="Utilities" default-visibility="true">Utilities</option>
          <option text="Waste Management and Remediation Services" default-visibility="true">Waste Management and Remediation Services</option>
          <option text="Wholesale Trade" default-visibility="true">Wholesale Trade</option>
          <option text="Wholesale Electronic Markets and Agents and Brokers" default-visibility="true">Wholesale Electronic Markets and Agents and Brokers</option>
          <option text="Wood Product Manufacturing" default-visibility="true">Wood Product Manufacturing</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s45@Interviews_Screens_xint" title="Agriculture, Forestry, Fishing and Hunting" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Crop Production" default-visibility="true">Crop Production</option>
          <option text="Animal Production" default-visibility="true">Animal Production</option>
          <option text="Forestry and Logging" default-visibility="true">Forestry and Logging</option>
          <option text="Fishing, Hunting and Trapping" default-visibility="true">Fishing, Hunting and Trapping</option>
          <option text="Support Activities for Agriculture and Forestry" default-visibility="true">Support Activities for Agriculture and Forestry</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s46@Interviews_Screens_xint" title="Mining, Quarrying, and Oil and Gas Extraction" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Oil and Gas Extraction" default-visibility="true">Oil and Gas Extraction</option>
          <option text="Mining (except Oil and Gas)" default-visibility="true">Mining (except Oil and Gas)</option>
          <option text="Support Activities for Mining" default-visibility="true">Support Activities for Mining</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s47@Interviews_Screens_xint" title="Construction" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Construction of Buildings" default-visibility="true">Construction of Buildings</option>
          <option text="Heavy and Civil Engineering Construction" default-visibility="true">Heavy and Civil Engineering Construction</option>
          <option text="Specialty Trade Contractors" default-visibility="true">Specialty Trade Contractors</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s48@Interviews_Screens_xint" title="%opa_selected_naics_category% details" entity="global">
      <input-control type="Text" attr="opa_non_naics_detail" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Describe your type of work: </caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s49@Interviews_Screens_xint" title="Manufacturing" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Apparel Manufacturing" default-visibility="true">Apparel Manufacturing</option>
          <option text="Beverage and Tobacco Product Manufacturing" default-visibility="true">Beverage and Tobacco Product Manufacturing</option>
          <option text="Chemical Manufacturing" default-visibility="true">Chemical Manufacturing</option>
          <option text="Computer and Electronic Product Manufacturing" default-visibility="true">Computer and Electronic Product Manufacturing</option>
          <option text="Electrical Equipment, Appliance, and Component Manufacturing" default-visibility="true">Electrical Equipment, Appliance, and Component Manufacturing</option>
          <option text="Fabricated Metal Product Manufacturing" default-visibility="true">Fabricated Metal Product Manufacturing</option>
          <option text="Food Manufacturing" default-visibility="true">Food Manufacturing</option>
          <option text="Furniture and Related Product Manufacturing" default-visibility="true">Furniture and Related Product Manufacturing</option>
          <option text="Leather and Allied Product Manufacturing" default-visibility="true">Leather and Allied Product Manufacturing</option>
          <option text="Machinery Manufacturing" default-visibility="true">Machinery Manufacturing</option>
          <option text="Miscellaneous Manufacturing" default-visibility="true">Miscellaneous Manufacturing</option>
          <option text="Nonmetallic Mineral Product Manufacturing" default-visibility="true">Nonmetallic Mineral Product Manufacturing</option>
          <option text="Paper Manufacturing" default-visibility="true">Paper Manufacturing</option>
          <option text="Petroleum and Coal Products Manufacturing" default-visibility="true">Petroleum and Coal Products Manufacturing</option>
          <option text="Plastics and Rubber Products Manufacturing" default-visibility="true">Plastics and Rubber Products Manufacturing</option>
          <option text="Primary Metal Manufacturing" default-visibility="true">Primary Metal Manufacturing</option>
          <option text="Printing and Related Support Activities" default-visibility="true">Printing and Related Support Activities</option>
          <option text="Textile Mills" default-visibility="true">Textile Mills</option>
          <option text="Textile Product Mills" default-visibility="true">Textile Product Mills</option>
          <option text="Transportation Equipment Manufacturing" default-visibility="true">Transportation Equipment Manufacturing</option>
          <option text="Wood Product Manufacturing" default-visibility="true">Wood Product Manufacturing</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s51@Interviews_Screens_xint" title="Wholesale Trade" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Merchant Wholesalers, Durable Goods" default-visibility="true">Merchant Wholesalers, Durable Goods</option>
          <option text="Merchant Wholesalers, Nondurable Goods" default-visibility="true">Merchant Wholesalers, Nondurable Goods</option>
          <option text="Wholesale Electronic Markets and Agents and Brokers" default-visibility="true">Wholesale Electronic Markets and Agents and Brokers</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s52@Interviews_Screens_xint" title="Retail Trade" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Building Material and Garden Equipment and Supplies Dealers" default-visibility="true">Building Material and Garden Equipment and Supplies Dealers</option>
          <option text="Clothing and Clothing Accessories Stores" default-visibility="true">Clothing and Clothing Accessories Stores</option>
          <option text="Electronics and Appliance Stores" default-visibility="true">Electronics and Appliance Stores</option>
          <option text="Food and Beverage Stores" default-visibility="true">Food and Beverage Stores</option>
          <option text="Furniture and Home Furnishings Stores" default-visibility="true">Furniture and Home Furnishings Stores</option>
          <option text="Gasoline Stations" default-visibility="true">Gasoline Stations</option>
          <option text="General Merchandise Stores" default-visibility="true">General Merchandise Stores</option>
          <option text="Health and Personal Care Stores" default-visibility="true">Health and Personal Care Stores</option>
          <option text="Miscellaneous Store Retailers" default-visibility="true">Miscellaneous Store Retailers</option>
          <option text="Motor Vehicle and Parts Dealers" default-visibility="true">Motor Vehicle and Parts Dealers</option>
          <option text="Nonstore Retailers" default-visibility="true">Nonstore Retailers</option>
          <option text="Sporting Goods, Hobby, Book, and Music Stores" default-visibility="true">Sporting Goods, Hobby, Book, and Music Stores</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s53@Interviews_Screens_xint" title="Transportation, Warehousing, Postal, Storage" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Couriers and Messengers" default-visibility="true">Couriers and Messengers</option>
          <option text="Pipeline Transportation" default-visibility="true">Pipeline Transportation</option>
          <option text="Postal Service" default-visibility="true">Postal Service</option>
          <option text="Rail Transportation" default-visibility="true">Rail Transportation</option>
          <option text="Scenic and Sightseeing Transportation" default-visibility="true">Scenic and Sightseeing Transportation</option>
          <option text="Support Activities for Transportation" default-visibility="true">Support Activities for Transportation</option>
          <option text="Transit and Ground Passenger Transportation" default-visibility="true">Transit and Ground Passenger Transportation</option>
          <option text="Truck Transportation" default-visibility="true">Truck Transportation</option>
          <option text="Warehousing and Storage" default-visibility="true">Warehousing and Storage</option>
          <option text="Water Transportation" default-visibility="true">Water Transportation</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s54@Interviews_Screens_xint" title="Information" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Publishing Industries (except Internet)" default-visibility="true">Publishing Industries (except Internet)</option>
          <option text="Motion Picture and Sound Recording Industries" default-visibility="true">Motion Picture and Sound Recording Industries</option>
          <option text="Broadcasting (except Internet)" default-visibility="true">Broadcasting (except Internet)</option>
          <option text="Telecommunications" default-visibility="true">Telecommunications</option>
          <option text="Data Processing, Hosting and Related Services" default-visibility="true">Data Processing, Hosting and Related Services</option>
          <option text="Other Information Services" default-visibility="true">Other Information Services</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s55@Interviews_Screens_xint" title="Finance and Insurance" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Monetary Authorities-Central Bank" default-visibility="true">Monetary Authorities-Central Bank</option>
          <option text="Credit Intermediation and Related Activities" default-visibility="true">Credit Intermediation and Related Activities</option>
          <option text="Securities, Commodity Contracts, and Other Financial Investments and Related Activities" default-visibility="true">Securities, Commodity Contracts, and Other Financial Investments and Related Activities</option>
          <option text="Insurance Carriers and Related Activities" default-visibility="true">Insurance Carriers and Related Activities</option>
          <option text="Funds, Trusts, and Other Financial Vehicles" default-visibility="true">Funds, Trusts, and Other Financial Vehicles</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s56@Interviews_Screens_xint" title="Real Estate and Rental and Leasing" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Real Estate" default-visibility="true">Real Estate</option>
          <option text="Rental and Leasing Services" default-visibility="true">Rental and Leasing Services</option>
          <option text="Lessors of Nonfinancial Intangible Assets (except Copyrighted Works)" default-visibility="true">Lessors of Nonfinancial Intangible Assets (except Copyrighted Works)</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s57@Interviews_Screens_xint" title="Health Care and Social Assistance" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Ambulatory Health Care Services" default-visibility="true">Ambulatory Health Care Services</option>
          <option text="Hospitals" default-visibility="true">Hospitals</option>
          <option text="Nursing and Residential Care Facilities" default-visibility="true">Nursing and Residential Care Facilities</option>
          <option text="Social Assistance" default-visibility="true">Social Assistance</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s58@Interviews_Screens_xint" title="Arts, Entertainment, and Recreation" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Performing Arts, Spectator Sports, and Related Industries" default-visibility="true">Performing Arts, Spectator Sports, and Related Industries</option>
          <option text="Museums, Historical Sites, and Similar Institutions" default-visibility="true">Museums, Historical Sites, and Similar Institutions</option>
          <option text="Amusement, Gambling, and Recreation Industries" default-visibility="true">Amusement, Gambling, and Recreation Industries</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s59@Interviews_Screens_xint" title="Accommodation and Food Services" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Accommodation" default-visibility="true">Accommodation</option>
          <option text="Food Services and Drinking Places" default-visibility="true">Food Services and Drinking Places</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s60@Interviews_Screens_xint" title="Other Services (except Public Administration)" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Repair and Maintenance" default-visibility="true">Repair and Maintenance</option>
          <option text="Personal and Laundry Services" default-visibility="true">Personal and Laundry Services</option>
          <option text="Religious, Grantmaking, Civic, Professional, and Similar Organizations" default-visibility="true">Religious, Grantmaking, Civic, Professional, and Similar Organizations</option>
          <option text="Private Households" default-visibility="true">Private Households</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s61@Interviews_Screens_xint" title="Public Administration" entity="global">
      <input-control type="Text" attr="opa_naics_work_type_detail" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Select the specific type of work you are looking for:</caption>
        <list>
          <option text="Justice, Public Order, and Safety Activities" default-visibility="true">Justice, Public Order, and Safety Activities</option>
          <option text="Administration of Human Resource Programs" default-visibility="true">Administration of Human Resource Programs</option>
          <option text="Administration of Environmental Quality Programs" default-visibility="true">Administration of Environmental Quality Programs</option>
          <option text="Administration of Housing Programs, Urban Planning, and Community Development" default-visibility="true">Administration of Housing Programs, Urban Planning, and Community Development</option>
          <option text="Administration of Economic Programs" default-visibility="true">Administration of Economic Programs</option>
          <option text="Space Research and Technology" default-visibility="true">Space Research and Technology</option>
          <option text="National Security and International Affairs" default-visibility="true">National Security and International Affairs</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s4@Interviews_Screens_xint" title="Are you ready to work" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;To receive Unemployment Insurance Benefits, you must be ready to work.&lt;/h3&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_cq_ab_able_to_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you physically and mentally able to hold a job:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_av_for_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you available to work full time:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ro_refused_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Have you refused a job offer or referral:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_st_in_training" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you enrolled in school or training:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s34@Interviews_Screens_xint" title="Seeking work full-time" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;You have listed less than the required number of job contacts.&lt;/h3&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="opa_cq_sk_fulltime_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Why are you not seeking full-time work:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_sk_problem_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>When do you expect to be able to continue seeking work ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_sk_any_employment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What efforts have you made to seek employment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_sk_temp_layoff" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you on a temporary layoff with your last employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_sk_additional_info" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Additional information:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s31@Interviews_Screens_xint" title="Layoff expected return to work date" entity="global">
      <input-control type="Date" attr="opa_cq_sk_layoff_return_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>What is your temporary layoff, expected return to work date ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s36@Interviews_Screens_xint" title="Work Refusal" entity="global">
      <input-control type="Text" attr="opa_cq_ro_job_referral" input-type="Dropdown">
        <default default="Select one" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Were you offered a job or a referral:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Job" default-visibility="true">Job</option>
          <option text="Referral" default-visibility="true">Referral</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_permanent_job" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Was the job permanent or temporary:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Permanent" default-visibility="true">Permanent</option>
          <option text="Temporary" default-visibility="true">Temporary</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_offering_employer" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Which employer offered you the job or referral:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_ro_offer_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What date were you offered a job or referral ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_individual_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Who offered the job or gave the referral:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_offer_method" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>How was the job or referral offered to you:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="In Person" default-visibility="true">In Person</option>
          <option text="Offer Letter " default-visibility="true">Offer Letter </option>
          <option text="Email" default-visibility="true">Email</option>
          <option text="Phone Call" default-visibility="true">Phone Call</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_reason_for_refusal" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Why did you refuse this job or referral:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_period_unemployed" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>How long have you been unemployed (on the date you refused the job):</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Less Than One Week" default-visibility="true">Less Than One Week</option>
          <option text="Less Than Two Weeks" default-visibility="true">Less Than Two Weeks</option>
          <option text="Less Than One Month" default-visibility="true">Less Than One Month</option>
          <option text="Less Than Three Months" default-visibility="true">Less Than Three Months</option>
          <option text="Less Than Six Months" default-visibility="true">Less Than Six Months</option>
          <option text="Less Than One Year" default-visibility="true">Less Than One Year</option>
          <option text="More Than One Year" default-visibility="true">More Than One Year</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_other_local_jobs" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What other jobs are available to you in the local job market:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ro_try_change_circ" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Did you try to change the circumstances that prevented you from accepting the job or referral:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;For example: arranging child care or transportation, securing a license or permit, etc.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_cq_ro_fam_shifts" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Did caring for children or family members restrict the location, hours, days or shifts you were available to work during your previous employment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s37@Interviews_Screens_xint" title="Job Offer Details" entity="global">
      <input-control type="Date" attr="opa_cq_ro_job_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>On what date was the job to begin ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_job_title" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the job title offered:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_offered_location" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the job location:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_job_duties" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What were the specific job duties:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_starting_pay" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the starting pay (Example $7.50 Per Hr):</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_hours_shift" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What hours or shift would you have worked:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="First Shift" default-visibility="true">First Shift</option>
          <option text="Second Shift" default-visibility="true">Second Shift</option>
          <option text="Third Shift" default-visibility="true">Third Shift</option>
          <option text="Rotating Shift" default-visibility="true">Rotating Shift</option>
          <option text="Split Shift" default-visibility="true">Split Shift</option>
          <option text="Part Time" default-visibility="true">Part Time</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_days_tobe_worked" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What are the days you would have worked:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_experience" input-type="Dropdown">
        <default default="Select one" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is your experience in the line of work offered:</caption>
        <list>
          <option text="Select one" default-visibility="true">Select one</option>
          <option text="None" default-visibility="true">None</option>
          <option text="Beginner/Little Experience" default-visibility="true">Beginner/Little Experience</option>
          <option text="Some Experience" default-visibility="true">Some Experience</option>
          <option text="Expert" default-visibility="true">Expert</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_skills" input-type="Dropdown">
        <default default="Select one" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What are your skills and training in the line of work offered:</caption>
        <list>
          <option text="Select one" default-visibility="true">Select one</option>
          <option text="No Skills or Training" default-visibility="true">No Skills or Training</option>
          <option text="Some Skills or Training" default-visibility="true">Some Skills or Training</option>
          <option text="Full/Complete Skills or Training" default-visibility="true">Full/Complete Skills or Training</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_tools_equip_licenses" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What are the tools, equipment or licenses you would be required to provide if you accepted this job:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s38@Interviews_Screens_xint" title="Referral Details" entity="global">
      <input-control type="Date" attr="opa_cq_ro_ref_int_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>What date was the referral interview ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers  are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s39@Interviews_Screens_xint" title="Previous Employer Details" entity="global">
      <input-control type="Number" attr="opa_cq_ro_hrs_per_week" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>How many hours did you work per week with your previous employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_days_per_week" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>How many days did you work per week with your previous employer:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="1" default-visibility="true">1</option>
          <option text="2" default-visibility="true">2</option>
          <option text="3" default-visibility="true">3</option>
          <option text="4" default-visibility="true">4</option>
          <option text="5" default-visibility="true">5</option>
          <option text="6" default-visibility="true">6</option>
          <option text="7" default-visibility="true">7</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_prior_emp_shift" input-type="Dropdown">
        <default default="First Shift" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What shift did you work with your previous employer:</caption>
        <list>
          <option text="First Shift" default-visibility="true">First Shift</option>
          <option text="Second Shift" default-visibility="true">Second Shift</option>
          <option text="Third Shift" default-visibility="true">Third Shift</option>
          <option text="Rotating Shift" default-visibility="true">Rotating Shift</option>
          <option text="Split Shift" default-visibility="true">Split Shift</option>
          <option text="Part Time" default-visibility="true">Part Time</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_ro_prior_emp_distance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is the distance (in miles) you had to travel to work with your previous employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ro_pay_freq" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was your pay period at your previous employer :</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Hourly" default-visibility="true">Hourly</option>
          <option text="Daily" default-visibility="true">Daily</option>
          <option text="Weekly" default-visibility="true">Weekly</option>
          <option text="Bi-Weekly" default-visibility="true">Bi-Weekly</option>
          <option text="Monthly" default-visibility="true">Monthly</option>
          <option text="Yearly" default-visibility="true">Yearly</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Currency" attr="opa_cq_ro_pe_rate_of_pay" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was your pay rate with your previous employer ( Example $25.50 ):</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s40@Interviews_Screens_xint" title="Temporary Job " entity="global">
      <input-control type="Date" attr="opa_cq_ro_temp_job_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When was the temporary job to end ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s41@Interviews_Screens_xint" title="Child or Family Care" entity="global">
      <input-control type="Text" attr="opa_cq_ro_limitations" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Explain how child or family care limited your availability to work:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">4</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s35@Interviews_Screens_xint" title="Your Availability" entity="global">
      <input-control type="Text" attr="opa_cq_av_limitations" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What are the limitations on your availability:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_av_imitation_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>When did these limitations begin:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_av_limitation_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When do you expect the situation to end:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_av_alternatives" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What alternatives do you have to deal with these limitations:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_av_arrangements" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What arrangements have you made to use these alternatives:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_ck_av_effort_made" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What efforts have you made to find employment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_av_additional_info" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Provide any additional information regarding the limitations:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s30@Interviews_Screens_xint" title="Released to Work Date" entity="global">
      <input-control type="Date" attr="opa_cq_ab_released_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When were you released to work ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s29@Interviews_Screens_xint" title="Doctor's Care" entity="global">
      <input-control type="Text" attr="opa_cq_ab_work_restrictions" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What are your work restrictions:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ab_released_to_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Have you been released to return to work:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ab_notification" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Did you notify your employer that you are under medical care (if you expect recall to your regular employer):</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s28@Interviews_Screens_xint" title="Ability to work full-time" entity="global">
      <input-control type="Text" attr="opa_cq_ab_why" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Why are you not able to work:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ab_explanation_detail" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Explain in detail what attempts you made to resolve the problem:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">4</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_ab_date_change" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When do you expect the problem to end or the conditions to change ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ab_doctors_care" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you under the care of a medical doctor:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_cq_ab_temp_layoff" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you on a temporary layoff with your last employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_ab_additional_info" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Provide any additional information about your inability to work:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">3</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s32@Interviews_Screens_xint" title="Expected Release Date" entity="global">
      <input-control type="Date" attr="opa_cq_ab_release_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>What is the date you will be released to work ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s16@Interviews_Screens_xint" title="School or Training Details" entity="global">
      <input-control type="Text" attr="opa_cq_st_facility_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Name of the educational facility you are attending:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_st_enrollment_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was your enrollment date ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_st_completion_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>What is the scheduled completion date ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_cq_st_prior_emp_training" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Did you attend school or training while working &lt;b&gt;full-time&lt;/b&gt; with your last employer:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_offered_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What do you plan to do, if offered full-time work during your school hours:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_affect" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What is the effect of school or training on your seeking and accepting full time employment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_additional_info" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Any additional information about the school or training:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s42@Interviews_Screens_xint" title="School or Training Enrollment and Schedule" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;How many hours do you normally attend school or training each day ?&lt;/h3&gt;&lt;h3&gt;Leave blank any days you do not plan to attend school or training&lt;/h3&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Number" attr="opa_cq_st_mon_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Monday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_tue_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Tuesday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_wed_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Wednesday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_thu_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Thursday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_friday_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Friday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_sat_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Saturday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="opa_cq_st_sun_hrs" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Sunday :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:3em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s43@Interviews_Screens_xint" title="School/Training While Working Full-Time" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;You previously answered that you have attended school or training while working full-time.&lt;/h3&gt;&lt;h3&gt;Please give the dates of your school or training enrollment.&lt;/h3&gt;&lt;br /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="opa_cq_st_emp_train_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the start date of school or training ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="opa_cq_st_emp_train_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the end date of school or training ( DD-Month-20YY ) :</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s44@Interviews_Screens_xint" title="Address of %opa_cq_st_facility_name%" entity="global">
      <input-control type="Text" attr="opa_cq_st_addr_l1" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Address line 1:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_addr_l2" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Address line 2:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_addr_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>City:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:30em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_state" input-type="Dropdown">
        <default default="Kentucky" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>State:</caption>
        <list>
          <option text="Alabama" default-visibility="true">Alabama</option>
          <option text="Alaska" default-visibility="true">Alaska</option>
          <option text="Arkansas" default-visibility="true">Arkansas</option>
          <option text="Arizona" default-visibility="true">Arizona</option>
          <option text="California" default-visibility="true">California</option>
          <option text="Colorado" default-visibility="true">Colorado</option>
          <option text="Connecticut" default-visibility="true">Connecticut</option>
          <option text="District Of Columbia" default-visibility="true">District Of Columbia</option>
          <option text="Delaware" default-visibility="true">Delaware</option>
          <option text="Florida" default-visibility="true">Florida</option>
          <option text="Georgia" default-visibility="true">Georgia</option>
          <option text="Hawaii" default-visibility="true">Hawaii</option>
          <option text="Iowa" default-visibility="true">Iowa</option>
          <option text="Idaho" default-visibility="true">Idaho</option>
          <option text="Illinois" default-visibility="true">Illinois</option>
          <option text="Indiana" default-visibility="true">Indiana</option>
          <option text="Kansas" default-visibility="true">Kansas</option>
          <option text="Kentucky" default-visibility="true">Kentucky</option>
          <option text="Louisiana" default-visibility="true">Louisiana</option>
          <option text="Massachusetts" default-visibility="true">Massachusetts</option>
          <option text="Maryland" default-visibility="true">Maryland</option>
          <option text="Maine" default-visibility="true">Maine</option>
          <option text="Michigan" default-visibility="true">Michigan</option>
          <option text="Minnesota" default-visibility="true">Minnesota</option>
          <option text="Missouri" default-visibility="true">Missouri</option>
          <option text="Mississippi" default-visibility="true">Mississippi</option>
          <option text="Montana" default-visibility="true">Montana</option>
          <option text="North Carolina" default-visibility="true">North Carolina</option>
          <option text="North Dakota" default-visibility="true">North Dakota</option>
          <option text="Nebraska" default-visibility="true">Nebraska</option>
          <option text="New Hampshire" default-visibility="true">New Hampshire</option>
          <option text="New Jersey" default-visibility="true">New Jersey</option>
          <option text="New Mexico" default-visibility="true">New Mexico</option>
          <option text="Nevada" default-visibility="true">Nevada</option>
          <option text="New York" default-visibility="true">New York</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oklahoma" default-visibility="true">Oklahoma</option>
          <option text="Oregon" default-visibility="true">Oregon</option>
          <option text="Pennsylvania" default-visibility="true">Pennsylvania</option>
          <option text="Puerto Rico" default-visibility="true">Puerto Rico</option>
          <option text="Rhode Island" default-visibility="true">Rhode Island</option>
          <option text="South Carolina" default-visibility="true">South Carolina</option>
          <option text="South Dakota" default-visibility="true">South Dakota</option>
          <option text="Tennessee" default-visibility="true">Tennessee</option>
          <option text="Texas" default-visibility="true">Texas</option>
          <option text="Utah" default-visibility="true">Utah</option>
          <option text="Virginia" default-visibility="true">Virginia</option>
          <option text="Virgin Islands" default-visibility="true">Virgin Islands</option>
          <option text="Vermont" default-visibility="true">Vermont</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wisconsin" default-visibility="true">Wisconsin</option>
          <option text="West Virginia" default-visibility="true">West Virginia</option>
          <option text="Wyoming" default-visibility="true">Wyoming</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_cq_st_zipcode" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Zip code, Example 12345</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:10em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s13@Interviews_Screens_xint" title="Impairments or Disabilities or Limitations" entity="global">
      <input-control type="Statement" attr="opa_visual_impairment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you have a visual impairment:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_blind_info_request" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Would you like to receive additional information from the Office for the Blind:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_vocational_info_request" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you want information about overcoming working limitations:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_functional_limitation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you have any limitations that keep you from being available to work full time:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s50@Interviews_Screens_xint" title="Referrals and Support Services" entity="global">
      <input-control type="Statement" attr="opa_job_location_help" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need help to locate job openings:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_job_email_help" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need help setting up a service to contact you by email about jobs:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_resume_assistance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need help to create a resume:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_interview_prep" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need help to prepare for an interview:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_other_job_help" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Describe another type of help we can provide:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:25em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_high_school_diploma" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you have a high school diploma:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_opt_in_diploma_info" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need information about earning a high school diploma:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="opa_opt_in_training_info" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you need information about school or training:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="opa_impairments" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you have any, impairments, disabilities, or limitations:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s3@Interviews_Screens_xint" title="List %opa_contact_minimum% employers you contacted to seek work between: %opa_earliest_contact_date% and %opa_latest_contact_date%.You are required to list one job contact per week if you are receiving regular UI or Emergency Unemployment Compensation (EUC).  If you are receiving Extended Benefits (EB), you are required to list two job contacts per week." entity="global">
      <container-control type="Entity" entity="the_contact" rel="contacts">
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="defining-attr-prefix" type="string">Employer_</property>
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Tabular</property>
          <property name="add-instance-text" type="string" />
          <property name="remove-instance-text" type="string" />
        </internal-properties>
        <custom-properties />
        <input-control type="Text" attr="contact_employer_name" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Employer's company name :</caption>
          <internal-properties>
            <property name="IsHTML" type="boolean">false</property>
            <property name="StyleOverride" type="string">width:20em;</property>
            <property name="ClassOverride" type="string" />
            <property name="lines" type="integer">1</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Date" attr="contact_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Date contacted ( DD-Month-20YY ) </caption>
          <internal-properties>
            <property name="IsHTML" type="boolean">false</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="lines" type="integer">1</property>
            <property name="__input-style" type="string">ymd</property>
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s9@Interviews_Screens_xint" title="Complete your list of contacted employers" entity="global">
      <control type="Label">
        <visibility attr="rb_label_10" default="false" />
        <caption>&lt;h3&gt;%rb_entity_date_range_msg%&lt;/h3&gt;&lt;br /&gt;&lt;h2&gt;You are not considered to be seeking full time work.&lt;/h2&gt;&lt;br /&gt;&lt;h3&gt;If you continue the interview, you may become ineligible for Unemployment Insurance.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="rb_add_contacts" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Do you wish to add more employers?</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br /&gt;&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s8@Interviews_Screens_xint" title="You Contacted:  %contact_employer_name% on %contact_date%; enter details..." entity="the_contact">
      <input-control type="Text" attr="contact_applied_for" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Position applied for:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_method" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Contact method (How did you get in touch):</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="In Person" default-visibility="true">In Person</option>
          <option text="Phone" default-visibility="true">Phone</option>
          <option text="Email" default-visibility="true">Email</option>
          <option text="Internet/Web" default-visibility="true">Internet</option>
          <option text="Mail" default-visibility="true">Mail</option>
          <option text="Fax" default-visibility="true">Fax</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">listbox-width:7em;</property>
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_person_info" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Name of the person contacted: </caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Phone or Fax #, Example 222 333 4444:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_url" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Web address:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_email" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Email address, Example someone@somesite.com</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:20em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="opa_contact_result" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>What was the result of this contact:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Uncertain" default-visibility="true">Uncertain</option>
          <option text="Unsuccessful" default-visibility="true">Unsuccessful</option>
          <option text="Call Again" default-visibility="true">Call Again</option>
          <option text="Possible Future Hire" default-visibility="true">Possible hire</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">listbox-width:7em;</property>
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr /&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="contact_address_line1" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Employer address line 1:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_address_line2" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Employer address line 2:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_address_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Employer town /  city:</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_state" input-type="Dropdown">
        <default default="Select One" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Employer's state:</caption>
        <list>
          <option text="Select One" default-visibility="true">Select One</option>
          <option text="Alabama" default-visibility="true">Alabama</option>
          <option text="Alaska" default-visibility="true">Alaska</option>
          <option text="Arizona" default-visibility="true">Arizona</option>
          <option text="Arkansas" default-visibility="true">Arkansas</option>
          <option text="California" default-visibility="true">California</option>
          <option text="Colorado" default-visibility="true">Colorado</option>
          <option text="Connecticut" default-visibility="true">Connecticut</option>
          <option text="Delaware" default-visibility="true">Delaware</option>
          <option text="District Of Columbia" default-visibility="true">District Of Columbia</option>
          <option text="Florida" default-visibility="true">Florida</option>
          <option text="Georgia" default-visibility="true">Georgia</option>
          <option text="Hawaii" default-visibility="true">Hawaii</option>
          <option text="Idaho" default-visibility="true">Idaho</option>
          <option text="Illinois" default-visibility="true">Illinois</option>
          <option text="Indiana" default-visibility="true">Indiana</option>
          <option text="Iowa" default-visibility="true">Iowa</option>
          <option text="Kansas" default-visibility="true">Kansas</option>
          <option text="Kentucky" default-visibility="true">Kentucky</option>
          <option text="Louisiana" default-visibility="true">Louisiana</option>
          <option text="Maine" default-visibility="true">Maine</option>
          <option text="Maryland" default-visibility="true">Maryland</option>
          <option text="Massachusetts" default-visibility="true">Massachusetts</option>
          <option text="Michigan" default-visibility="true">Michigan</option>
          <option text="Minnesota" default-visibility="true">Minnesota</option>
          <option text="Mississipi" default-visibility="true">Mississipi</option>
          <option text="Missouri" default-visibility="true">Missouri</option>
          <option text="Montana" default-visibility="true">Montana</option>
          <option text="Nebraska" default-visibility="true">Nebraska</option>
          <option text="Nevada" default-visibility="true">Nevada</option>
          <option text="New Hampshire" default-visibility="true">New Hampshire</option>
          <option text="New Jersey" default-visibility="true">New Jersey</option>
          <option text="New Mexico" default-visibility="true">New Mexico</option>
          <option text="New York" default-visibility="true">New York</option>
          <option text="North Carolina" default-visibility="true">North Carolina</option>
          <option text="North Dakota" default-visibility="true">North Dakota</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oklahoma" default-visibility="true">Oklahoma</option>
          <option text="Oregon" default-visibility="true">Oregon</option>
          <option text="Pennsylvania" default-visibility="true">Pennsylvania</option>
          <option text="Puerto Rico" default-visibility="true">Puerto Rico</option>
          <option text="Rhode Island" default-visibility="true">Rhode Island</option>
          <option text="South Carolina" default-visibility="true">South Carolina</option>
          <option text="South Dakota" default-visibility="true">South Dakota</option>
          <option text="Tennessee" default-visibility="true">Tennessee</option>
          <option text="Texas" default-visibility="true">Texas</option>
          <option text="Utah" default-visibility="true">Utah</option>
          <option text="Vermont" default-visibility="true">Vermont</option>
          <option text="Virgin Islands" default-visibility="true">Virgin Islands</option>
          <option text="Virginia" default-visibility="true">Virginia</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="West Virginia" default-visibility="true">West Virginia</option>
          <option text="Wisconsin" default-visibility="true">Wisconsin</option>
          <option text="Wyoming" default-visibility="true">Wyoming</option>
        </list>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="contact_address_zipcode" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Employer zip code, Examples 12345, 12345 6789</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string">width:15em;</property>
          <property name="ClassOverride" type="string" />
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;&lt;p&gt;Please check that your answers are correct before clicking the &lt;b&gt;Continue&lt;/b&gt; button.&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
    <screen type="Question" id="s67@Interviews_Screens_xint" title="Job Details:  Instructions and Examples" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;You have provided a list of employers and the date contacted.&lt;/h3&gt;&lt;h3&gt;On the following screens you will be asked to provide details about each of those employers.&lt;/h3&gt;&lt;h3&gt;You must list the position (job title) that you applied for and the contact method; in other words, how you contacted the employer.&lt;/h3&gt;&lt;h3&gt;Based on the contact method you will be asked to complete other information.&lt;/h3&gt;
</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Example 1: If you have contacted an employer by phone to apply for a construction job, you must ...&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;ul id="ui_example1"&gt;&lt;li&gt;Enter "Construction" in the Position Applied For&lt;/li&gt;
&lt;li&gt;Select "Phone" in the Method Used: &lt;/li&gt;
&lt;li&gt;Enter a phone number, example,  222-333-4444, in Phone Number: &lt;/li&gt;
&lt;li&gt;No other information would be required for this example.&lt;/li&gt;
&lt;/ul&gt;
&lt;br /&gt;
&lt;h3&gt;Example 2: If you applied for a job over the internet you must provide the web address, rather than a Contact Person, Address or Phone Number.&lt;/h3&gt;
</caption>
        <internal-properties>
          <property name="IsHTML" type="boolean">true</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="text-style" type="string">Normal</property>
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties>
        <property name="SaveEventScreensSetTrue">False</property>
      </custom-properties>
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <folder>
          <caption>Interstate Registration</caption>
          <items>
            <screen ref="s25@Interviews_Screens_xint" />
            <screen ref="s27@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Claim Classification</caption>
          <items>
            <screen ref="s12@Interviews_Screens_xint" />
            <screen ref="s20@Interviews_Screens_xint" />
            <screen ref="s21@Interviews_Screens_xint" />
            <screen ref="s19@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Type of Work</caption>
          <items>
            <screen ref="s14@Interviews_Screens_xint" />
            <screen ref="s45@Interviews_Screens_xint" />
            <screen ref="s46@Interviews_Screens_xint" />
            <screen ref="s47@Interviews_Screens_xint" />
            <screen ref="s48@Interviews_Screens_xint" />
            <screen ref="s49@Interviews_Screens_xint" />
            <screen ref="s51@Interviews_Screens_xint" />
            <screen ref="s52@Interviews_Screens_xint" />
            <screen ref="s53@Interviews_Screens_xint" />
            <screen ref="s54@Interviews_Screens_xint" />
            <screen ref="s55@Interviews_Screens_xint" />
            <screen ref="s56@Interviews_Screens_xint" />
            <screen ref="s57@Interviews_Screens_xint" />
            <screen ref="s58@Interviews_Screens_xint" />
            <screen ref="s59@Interviews_Screens_xint" />
            <screen ref="s60@Interviews_Screens_xint" />
            <screen ref="s61@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Claims Questionnaire</caption>
          <items>
            <screen ref="s4@Interviews_Screens_xint" />
            <folder>
              <caption>Seeking Work</caption>
              <items>
                <screen ref="s34@Interviews_Screens_xint" />
                <screen ref="s31@Interviews_Screens_xint" />
              </items>
            </folder>
            <folder>
              <caption>Refused Offer of Work</caption>
              <items>
                <screen ref="s36@Interviews_Screens_xint" />
                <screen ref="s37@Interviews_Screens_xint" />
                <screen ref="s38@Interviews_Screens_xint" />
                <screen ref="s39@Interviews_Screens_xint" />
                <screen ref="s40@Interviews_Screens_xint" />
                <screen ref="s41@Interviews_Screens_xint" />
              </items>
            </folder>
            <folder>
              <caption>Available for Work</caption>
              <items>
                <screen ref="s35@Interviews_Screens_xint" />
              </items>
            </folder>
            <folder>
              <caption>Ability to work</caption>
              <items>
                <screen ref="s30@Interviews_Screens_xint" />
                <screen ref="s29@Interviews_Screens_xint" />
                <screen ref="s28@Interviews_Screens_xint" />
                <screen ref="s32@Interviews_Screens_xint" />
              </items>
            </folder>
            <folder>
              <caption>Attending training</caption>
              <items>
                <screen ref="s16@Interviews_Screens_xint" />
                <screen ref="s42@Interviews_Screens_xint" />
                <screen ref="s43@Interviews_Screens_xint" />
                <screen ref="s44@Interviews_Screens_xint" />
              </items>
            </folder>
          </items>
        </folder>
        <folder>
          <caption>Veterans</caption>
          <items>
            <screen ref="s15@Interviews_Screens_xint" />
            <screen ref="s18@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Referrals and Support Services</caption>
          <items>
            <screen ref="s13@Interviews_Screens_xint" />
            <screen ref="s50@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Employers Contacted</caption>
          <items>
            <screen ref="s3@Interviews_Screens_xint" />
            <screen ref="s9@Interviews_Screens_xint" />
            <for-each relationship="contacts">
              <items>
                <screen ref="s8@Interviews_Screens_xint" />
              </items>
            </for-each>
            <screen ref="s67@Interviews_Screens_xint" />
          </items>
        </folder>
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>