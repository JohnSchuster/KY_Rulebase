package com.oracle.determinations.interview.engine.userplugins;

import com.oracle.determinations.engine.Session;
import com.oracle.determinations.engine.Attribute;
import com.oracle.determinations.engine.Entity;
import com.oracle.determinations.engine.EntityInstance;
import com.oracle.determinations.engine.Rulebase;
import com.oracle.determinations.interview.engine.InterviewSession;
import com.oracle.determinations.interview.engine.SecurityToken;
import com.oracle.determinations.interview.engine.plugins.InterviewSessionRegisterArgs;
import com.oracle.determinations.interview.engine.plugins.data.DataAdaptorPlugin;
import com.oracle.determinations.web.platform.eventmodel.events.OnGetScreenEvent;
import com.oracle.determinations.interview.engine.security.BasicSecurityToken;
import com.oracle.determinations.web.platform.controller.SessionContext;
import com.oracle.determinations.web.platform.eventmodel.handlers.OnGetScreenEventHandler;
import com.oracle.determinations.web.platform.plugins.PlatformSessionPlugin;
import com.oracle.determinations.web.platform.plugins.PlatformSessionRegisterArgs;
import com.oracle.determinations.web.siebel.SiebelDataAdapter;
import org.apache.log4j.Logger;
import java.util.HashSet;

/**
 * Implements a single save event driven by rule-base attribute values and screens.
 * Implements a workaround for a fault in OWD 10.1 that causes multiple handler registrations
 *      See logic in getInstance.
 *      This should be re-factored when upgraded to OWD 10.2, which should include a permanent fix.
 *
 * Business Requirement :
 *      Permits a rule author (and the end user) to control when an interview is "saved" to
 *      Siebel via the Data Adapter
 *      The rule-base controls whether the save only occurs once.
 *
 * The logger statements are used to support initial development and debug.
 *
 * @author Stephen Doody
 * @version v1.0
 */

public class SaveTxtDocument implements OnGetScreenEventHandler {
    private String opa_finish_and_save_goal = "";
    private String rb_save_confirmed = "";
    private final Boolean emitlog = false;

    private HashSet<String> hs = new HashSet<String>();

    //Method Required - by OnGetScreenEventHandler interface
    public void handleEvent (Object sender, OnGetScreenEvent event) {
        try{
            Logger log = Logger.getRootLogger();
            if (emitlog) {
                log.info("OWD_00 : <Registration Fix-HashSet> Event Handler Initialized ");
            }
            SessionContext currentContext = (SessionContext) sender;

            if (emitlog) {
                log.info("OWD_01 Screen: " + currentContext.getCurrentScreen().toString());
            }

            Session ruleSession = (Session)currentContext.getInterviewSession().getRuleSession();
            Rulebase currentRulebase = ruleSession.getRulebase();

            Entity globalEntity = currentRulebase.getEntity("global");
            EntityInstance globalInstance = globalEntity.getEntityInstance(ruleSession);

            /* opa_finish_and_save_goal */
            Attribute goalAttr = currentRulebase.getAttribute("opa_finish_and_save_goal", "global");
            if(goalAttr != null && goalAttr.getValue(globalInstance) != null){
                opa_finish_and_save_goal = goalAttr.getValue(globalInstance).toString();
            }
            /* rb_save_confirmed */
            Attribute savedAttr = currentRulebase.getAttribute("rb_save_confirmed", "global");
            if(savedAttr != null && savedAttr.getValue(globalInstance) != null){
                rb_save_confirmed = savedAttr.getValue(globalInstance).toString();
            }

            // Only return the document if the 'opa_finish_and_save_goal' attribute exists and is true
            // and the 'rb_save_confirmed' attribute is either false or unknown (aka null).
            // In the ky_ui_er rulebase, see the rules in SaveHandler.doc
            // The intent is that 'save' should occur exactly once in any given interview/session.

            if((goalAttr != null && goalAttr.getValue(globalInstance) != null)
                && (savedAttr != null && (savedAttr.getValue(globalInstance) == null
                ||  savedAttr.getValue(globalInstance).toString().equalsIgnoreCase("false")))
                &&  goalAttr.getValue(globalInstance).toString().equalsIgnoreCase("true"))
            {
                if (emitlog){
                    log.info("OWD_02a : Save Active");
                    log.info("OWD_02b Attribute, User Requested Interview Save : " + opa_finish_and_save_goal);
                    log.info("OWD_02c Attribute, Confirmation screen Displayed : " + rb_save_confirmed);
                }

                if(currentContext.getCaseID() != null){
                    SecurityToken token = new BasicSecurityToken("");
                    InterviewSession currentSession = (InterviewSession) currentContext.getInterviewSession();
                    /*
                    SiebelDataAdapter acts as a factory for getting instances of the plug-in.
                    SiebelDataAdapter factory = new SiebelDataAdapter();
                    DataAdaptorPlugin siebelDataAdapter = (SiebelDataAdaptor) factory.getInstance(args);
                    siebelDataAdapter.save(......)
                    */
                    SiebelDataAdapter sdaFactory = (SiebelDataAdapter) new SiebelDataAdapter();
                    InterviewSessionRegisterArgs isra = new InterviewSessionRegisterArgs(currentSession);

                    DataAdaptorPlugin dap = ( DataAdaptorPlugin ) sdaFactory.getInstance(isra);
                    if (emitlog){
                        log.info("OWD_03a : Case Id : " + currentContext.getCaseID().toString());
                        log.info("OWD_03b : Save Called");
                    }
                    // Save the session to Siebel using the data Adaptor
                    String newCaseID = dap.save(token, currentContext.getCaseID(), currentSession);

                    if(!newCaseID.equals("")){
                        if (emitlog){
                            log.info("OWD_03c : Save Success");
                        }
                        // New Case Id is returned from Siebel, it is the Session Id used to save the data

                        // Production Log
                        log.info("OWD_SAVE : Case Id : " + newCaseID);
                        
                        // Done with the original Case Id (Hashet key) for this Session
                        // Remove it to avoid a memory leak in the HashSet
                        if (hs.contains(currentContext.getCaseID())) {
                            hs.remove(currentContext.getCaseID());
                            if (emitlog){
                                log.info("OWD_Plugin  : Case Id : HashSet Removed " + currentContext.getCaseID());
                            }
                        }
                        // --------------------
                        // Note: Do not update the Case Id from within this event handler it
                        // may cause additional events to be triggered, saving the data multiple times
                        // currentContext.setCaseID(newCaseID);
                        // --------------------
                        }else{
                            // Production Log
                            log.info("OWD_FAILED_SAVE : Case Id " + currentContext.getCaseID());
                        }
                }else{
                    if (emitlog){
                        log.info("OWD_04 : Save Cancelled, Case ID is null.");
                    }
                }
            }else{
                if (emitlog){
                    log.info("OWD_05 Save event inactive.");
                    log.info("OWD_05a User Requested Interview Save : " + opa_finish_and_save_goal);
                    log.info("OWD_05b Confirmation screen Displayed : " + rb_save_confirmed);
                }
            }
        }
        catch(Exception ex){
            Logger logex = Logger.getRootLogger();
            logex.info("OWD_Exception ", ex);
            if (emitlog){
                logex.info("OWD_EX Attribute, User Requested Interview Save : " + opa_finish_and_save_goal);
                logex.info("OWD_EX Attribute, Confirmation screen Displayed : " + rb_save_confirmed);
            }
        }
        finally{}
    }

    public SaveTxtDocument() {
    }

    public PlatformSessionPlugin getInstance(PlatformSessionRegisterArgs args) {
        //
        // In OWD 10.1 a fault exists that may cause multiple calls to this method, to register the handler
        // This subsequently causes multiple instances to be invoked, resulting in multiple saves to Siebel...
        // This workaround prevents more than one instance being returned, for the initial SessionContext.
        //
        SessionContext sc = args.getContext();
        String sKey = sc.getCaseID();
        Logger logi = Logger.getRootLogger();
        if (hs.contains(sKey)) {
            if (emitlog){
                logi.info("OWD_Plugin Instance Set Null ");
            }
            return null; // Return null avoiding additional registrations
        }else{
            hs.add(sKey);
            if (emitlog){
                logi.info("OWD_Plugin Instance Returned ");
            }
            return new SaveTxtDocument();  // Return an instance of this event handler
        }
    }
}