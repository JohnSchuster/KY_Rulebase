<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Welcome to IFF UI Claim Entry" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="note"&gt;You are about to file an application for Unemployment Insurance benefits.
This process may take at least thirty(30) minutes to complete. 
Please allow enough time to complete the application.&lt;/h2&gt;

&lt;p class="pb"&gt;Knowingly submitting false information to obtain benefits is a criminal act.
Any violation will result in prosecution under KRS.331.370(2).&lt;/p&gt;


&lt;p class="note"&gt;Upon the completion of the application, you will receive a confirmation page.
This confirmation page contains important instructions on what to do after the claim has been filed.
Please note: If you do not see a confirmation page, your claim will not be processed.&lt;/p&gt;

&lt;p class="pb"&gt;You are responsible for reading and understanding the Rights and Responsibilities pamphlet (PAM-UI-400)&lt;/p&gt;
&lt;p class="pb"&gt;You may access The Rights and Responsibilities pamphlet (PAM-UI-400) by clicking &lt;a href="https://uiclaims.des.ky.gov/eBenefits_enu/help/PAM_UI_400.htm"&gt;here&lt;/a&gt;&lt;/p&gt; </caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <goal-control type="Goal" flow="f1@Interviews_IFFScreens_xint">
        <visibility default="enabled" />
        <caption>&lt;img src="../../../images/xrulz_start.png"&gt;</caption>
        <internal-properties>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </goal-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s12@Interviews_IFFScreens_xint" title="Kentucky Employment Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;your base period is &amp;nbsp  %fpr_base_period_start_date% &amp;nbsp through &amp;nbsp %fpr_base_period_end_date%&lt;/h3&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="b2@Rules_NSQnA_doc" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Did you work in Kentucky during your base period?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="b3@Rules_NSQnA_doc" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you receiving Unemployment Benefits from a state other than Kentucky?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s122@Interviews_IFFScreens_xint" title="Pension and other Compensation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;your base period is &amp;nbsp  %fpr_base_period_start_date% &amp;nbsp through &amp;nbsp %fpr_base_period_end_date%&lt;/h3&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_pension_benifit" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you currently receiving a pension check from and employer you worked for during your base period ?&lt;/b&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_workers_comp" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you receiving - or have you applied for; workers compensation payments during your base period?&lt;/b&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s134@Interviews_IFFScreens_xint" title="Rights and Responsibilities" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;h2&gt;CERTIFICATION/AUTHORIZATION&lt;/h2&gt;
&lt;p&gt;I certify that the information on this claim for unemployment benefits is true and correct to the best of my knowledge.&lt;br&gt;
I certify that I have read and understand the (PAM-UI-400), Rights and Responsibilities pamphlet and accept responsibility&lt;br&gt;
for reading this pamphlet and asking questions of claims personnel if I do not understand the instructions or any procedures &lt;br&gt;
law or regulation affecting my claim.&lt;br&gt; 
&lt;p class="pr"&gt;I understand that any false statements or omissions of material facts to obtain benefits is&lt;br&gt;
punishable by fine or imprisonment. I AUTHORIZE my former employer(s) to release all information &lt;br&gt;
requested in connection with my claim for unemployment benefits.&lt;/p&gt;
&lt;br&gt;
&lt;p&gt;You may access The Rights and Responsibilities pamphlet (PAM-UI-400) over the internet by clicking &lt;a href="https://uiclaims.des.ky.gov/eBenefits_enu/help/PAM_UI_400.htm"&gt;here&lt;/a&gt; 
&lt;br&gt;or by visiting your local Unemployment Insurance Office.&lt;/p&gt;

&lt;p&gt;Due to recent changes in the Unemployment Insurance law, you must now serve a  one week waiting period per benefit year.&lt;br&gt;
Your waiting week will always be your first payable week. You will request benefits for a two week period. If you are otherwise eligible, &lt;br&gt;
the amount of your first check will only be for one week. For further information, &lt;a href="http://www.kewes.ky.gov/"&gt;Please Click Here&lt;/a&gt;&lt;/p&gt;
&lt;br&gt;
&lt;p class="pb"&gt;Please enter you initials in the spaces provided to acknowledge the terms listed below&lt;/p&gt;
&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_access_pam" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I was given access to the PAM-UI-400 Rights and Responsibilities pamphlet&lt;p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_understand" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that I must report all wages earned&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_understand_waiting" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that effective January 1st, 2012,&lt;/p&gt;&lt;br&gt;
&lt;p&gt; Kentucky Unemployment Insurance Law requires one (waiting week) per benifit year&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;
Your waiting week will always be your first payable week. You will request benefits for a two week period&lt;br&gt;
If you are otherwise eligible, the amount of your first check will only be for one week&lt;br&gt;
Your maximum benifit amount will not change&lt;/p&gt;
 </caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_full_name_sig" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please enter your First Name, Middle Initial and Last Name in the space provided to CERTIFY&lt;/p&gt;
&lt;p&gt;the information provided is truthfull and accurate to the best of you knowledge and AUTHORIZE an Unemployment Benefits claim Initiation&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s138@Interviews_IFFScreens_xint" title="Confirmation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;p&gt;Your reference number is: A1234&lt;/p&gt;&lt;br&gt;
&lt;p&gt;The date to begin requesting your check for Unemployment Insurance benefits is :28-OCT-2012&lt;/p&gt;&lt;br&gt;
&lt;p&gt;Please use the following time frame to request your benefit checks - &lt;font color="green"&gt;every two weeks&lt;/font&gt;&lt;/p&gt;&lt;br&gt;
&lt;p&gt;All Unemployment Insurance claimants needing to request a benefit check
may may do so by clicking &lt;a href="http://www.kewes.ky.gov/"&gt;Here&lt;/a&gt;&lt;/p&gt;&lt;br&gt;
&lt;p&gt;Unemployment Insurance (UI) and Emergency Unemployment Compensation (EUC)&lt;/p&gt;
&lt;p&gt;claimants may also use the phone system by calling (877) 365.5534&lt;/p&gt;


</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s64@Interviews_IFFScreens_xint" title="Disqualified" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;b&gt;Your Registration Failed&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;
Your application for Unemployment Insurance with the State of Kentucky has been denied.&lt;br/&gt;&lt;br/&gt;
&lt;b&gt;Right to Protest or Appeal&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;
&lt;ol&gt;
&lt;li&gt;You have the right to protest or appeal this decision within 30 day of receiving this notice.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;In your protest or appeal, indicate the reason(s) why you do not agree with
the (re)determination. Also, provide any new or additional facts not
presented in your first statement.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;Attach copies of any documents, employer notices, correspondence, or
other types of information which may clarify the issue you are protesting.
These documents will not be returned so you should send duplicates or
copies.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;You must protest in writing or by fax.  In order to be on time, your protest
must be received by the bureau within 30 days of the date of this
determination&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;If your protest is not received in time, it will affect the decision you receive.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;If the 30 day protest period has already elapsed, your statement should
indicate why your protest was not on time.&lt;/li&gt;&lt;br/&gt;
&lt;/ol&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s45@Interviews_IFFScreens_xint" title="Base Period" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;About the base period&lt;/h2&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt;Your claim for Unemployment Insurance is effective the Sunday of the week in which you complete your claim.&lt;/li&gt;
  &lt;li&gt;The benefit year effective date is the date that your claim for Unemployment benefits officially begins.&lt;/li&gt;
  &lt;li&gt;The expire date is the date your benefit year ends – usually 52 weeks following the effective date.&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;
&lt;p&gt;Your benefit year effective date is: %fpr_claim_filing_effective_date% &lt;/p&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt;Your base period is the first four of the last five completed calendar quarters immediately prior to the quarter in which you file your claim.&lt;/li&gt;
  &lt;li&gt;The base period beginning date is the start of the 12 month period and the base period ending date is the ending date of that 12 month period.&lt;/li&gt;
  &lt;li&gt;Your earnings during this 12 month period will determine your weekly benefit amount.&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;
&lt;p&gt;The time between the base period start date and the base period end date is your base period&lt;/p&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt;Your base period start date is: &amp;nbsp %fpr_base_period_start_date%&lt;/li&gt;
  &lt;li&gt;Your base period end date is: &amp;nbsp %fpr_base_period_end_date%&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;You will receive notice of the weekly amount of your claim and the maximum amount of money you can receive.&lt;br&gt;
This amount is only applicable until your benefit year expiration date.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s147@Interviews_IFFScreens_xint" title="Ability to work" entity="global">
      <input-control type="Statement" attr="fpr_physically_able_to_work" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you physically able to work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_mentally_able" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you mentally able to work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s157@Interviews_IFFScreens_xint" title="Physical ability" entity="global">
      <input-control type="Statement" attr="fpr_physical_prevents_work" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does your physical health restriction limit your ability to work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_physical_start" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;When did your physical health restriction begin?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">d</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_physical_end" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;When do you expect the restriction to end?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">d</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s155@Interviews_IFFScreens_xint" title="Mental Ability" entity="global">
      <input-control type="Statement" attr="fpr_mental_prevents_work" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does your mental health restriction affect you ability to work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_mental_start" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;When did your mental health restrictions began?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_mental_end" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;When do you expect the restriction to end ?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s159@Interviews_IFFScreens_xint" title="Availability to work" entity="global">
      <input-control type="Statement" attr="fc_transportation_restricts" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you have reliable transportation?&lt;/b&gt;&lt;br&gt;
 &lt;b class="pb"&gt;(so you can look for and accept work)&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_is_in_school" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you currently attending school?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_caregiver_prevent_search" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you provide care to a dependent child, spouse or elder?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_se_restricts_available" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you self employed or working on a commision basis? &lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_is_incarcerated" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you currently incarcerated?&lt;/b&gt;&lt;br&gt;
&lt;b class="pb"&gt;(imprisoned, jailed, house arrest, work release, etc)&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s177@Interviews_IFFScreens_xint" title="School information" entity="global">
      <input-control type="Statement" attr="fpr_is_an_apprentice" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you in a trade union apprentice program?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_tra_approved" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Is your schooling approved under the trade act of 1974 (TAA)?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_school_prevents_search" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does your classtime prevent a suitable work search?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_school_prevents_work" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does your classtime prevent obtaining (accepting) suitable work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s178@Interviews_IFFScreens_xint" title="Type of Incarceration" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;b class="pb"&gt;Please tell us what type of incarceration you are under&lt;/b&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="fc_claimant_in_prision" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;I am currently in prison&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_claimant_house_arrest" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;I am currently under House Arrest&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s179@Interviews_IFFScreens_xint" title="Dependent Care" entity="global">
      <input-control type="Text" attr="fc_care_for" input-type="Dropdown">
        <default default="Child" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your relationship to the person you are caring for?&lt;/b&gt;</caption>
        <list>
          <option text="Spouse" default-visibility="true">Spouse</option>
          <option text="Child" default-visibility="true">Child</option>
          <option text="Parent or Grandparent" default-visibility="true">Parent or Grandparent</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_alternate_dep_care" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Can someone else take care of this person while you look for/accept work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_caregiver_prevent_search" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does your responsibility to provide dependent care prevent a suitable work search?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_care_date_start" input-type="default">
        <default default="2012-01-01" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>When did your responsibility of care began?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">d</property>
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_care_date_end" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When do you expect the responsibility of care to end?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">d</property>
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s54@Interviews_IFFScreens_xint" title="Federal - Military" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;your base period is &amp;nbsp  %fpr_base_period_start_date% &amp;nbsp through &amp;nbsp %fpr_base_period_end_date%&lt;/h3&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="fc_armed_forces" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Did you serve in the military during your base period?&lt;/b&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_federal" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Were you employed by the Federal government during your base period?&lt;/b&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_postal" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Did you work for the US Post office during your base period?&lt;/b&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s158@Interviews_IFFScreens_xint" title="Current work search" entity="global">
      <input-control type="Statement" attr="fc_claimant_looking_for_work" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you currently looking for work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_claimant_appl_qual" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you applying for jobs that you are qualified to do?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s139@Interviews_IFFScreens_xint" title="Labor Union" entity="global">
      <input-control type="Statement" attr="fc_union_member" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are You a member of a Labor Union?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_union_work" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Does A Labor Union find work for you?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s14@Interviews_IFFScreens_xint" title="Personal Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;The following questions will help us should there be a problem with your application&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="fpr_is_us_citizen" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you a US Citizen?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_alias" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Have you ever worked under a different name? (for example, maiden name, other married names)&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_claimant_birthday" input-type="default">
        <default attr="fc_claimant_birthday" default="1959-12-31" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>When is your birthday</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_home_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your primary phone number&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_cell_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;If you have an alternate phone number, please enter it here&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_email" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;If you have an E-Mail address - please enter it here&lt;/b&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_interpretor_needed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Should we need to contact you, Is an interpretor needed?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_interpretor_language" input-type="Dropdown">
        <default default="Spanish" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;If an interpretor is needed, what is the prefered language?&lt;/b&gt;</caption>
        <list>
          <option text="Spanish" default-visibility="true">Spanish</option>
          <option text="Portuguese" default-visibility="true">Portuguese</option>
          <option text="Chinese" default-visibility="true">Chinese</option>
          <option text="Tagalog" default-visibility="true">Tagalog</option>
          <option text="French" default-visibility="true">French</option>
          <option text="Vietnamese" default-visibility="true">Vietnamese</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;b class="pb"&gt;The following questions are optional and are for statistical purposes only&lt;/b&gt;
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="fc_gender" input-type="Dropdown">
        <default default="Male" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your gender?&lt;/b&gt;</caption>
        <list>
          <option text="Male" default-visibility="true">Male</option>
          <option text="Female" default-visibility="true">Female</option>
          <option text="No Answer" default-visibility="true">No Answer</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_ethnic_group" input-type="Dropdown">
        <default default="Not Hispanic or Latino" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your ethnic group?&lt;/b&gt;</caption>
        <list>
          <option text="Hispanic or Latino" default-visibility="true">Hispanic or Latino</option>
          <option text="Not Hispanic or Latino" default-visibility="true">Not Hispanic or Latino</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_race" input-type="Dropdown">
        <default default="White" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your race?&lt;/b&gt;</caption>
        <list>
          <option text="White" default-visibility="true">White</option>
          <option text="Black or African American" default-visibility="true">Black or African American</option>
          <option text="Asian" default-visibility="true">Asian</option>
          <option text="American Indian or Alaskan Native" default-visibility="true">American Indian or Alaskan Native</option>
          <option text="Native Hawaiian or Other Pacific Islander" default-visibility="true">Native Hawaiian or Other Pacific Islander</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_disability" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you have a disability&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s192@Interviews_IFFScreens_xint" title="Mailing Address" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please verify the accuracy of all the information you enter&lt;br&gt;
If this information changes at some point in the future, you will be required to update it&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="fc_mailing_address" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Mailing address?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_mailing_additional" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Suite or appt number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_mailing_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;City&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_mailing_state" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;State?&lt;/b&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_mailing_county" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;County?&lt;/b&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string">Body_body</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_mailing_zip_code" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Zip code?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_po_box" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Is the information you entered above to a Post Office Box?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s195@Interviews_IFFScreens_xint" title="Physical Address " entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please enter the physical address where you reside - do NOT enter a P.O.&lt;/p&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="fc_legal_res_address" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Street address?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_legal_res_additional" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Suite or appt number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_legal_res_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;City?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_legal_res_state" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;State?&lt;/b&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_legal_res_county" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;County?&lt;/b&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_legal_res_zip_code" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;Zip code?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s208@Interviews_IFFScreens_xint" title="Institution of Incarceration" entity="global">
      <input-control type="Text" attr="fc_incarcerated_at" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is the name of the institution you are incarcerated at?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_work_release" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you in a work release program?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s209@Interviews_IFFScreens_xint" title="House Arrest" entity="global">
      <input-control type="Statement" attr="fc_can_telework" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Have you been offered an opportunity to telework?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_allowed_to_leave" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are you allowed to leave your residence to look for(accept) work?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s210@Interviews_IFFScreens_xint" title="Transportation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please answer the following questions about your transportation&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="fc_claimant_valid_license" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you have a valid driver's license?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_claimant_owns_vehicle" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you own a reliable vehicle?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_alternate_transportation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;If you do not have a valid license or you do not own a vehicle&lt;/b&gt;&lt;br&gt;
&lt;b&gt;do you have a reliable alternative means of transportation?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s71@Interviews_IFFScreens_xint" title="Payment Method Informatiom" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pr"&gt;You are responsible for the accuracy of payment method data&lt;/p&gt;
&lt;hr&gt;
&lt;p class="pb"&gt;Facts About checks:&lt;/p&gt;&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt;If you are found payable, you should receive your check within 3–4 business days of making your claim for benefit.&lt;/li&gt;
  &lt;li&gt;You must make your request for benefits on the date you are given at the completion of filing your claim and every 2 weeks thereafter.&lt;/li&gt;
  &lt;li&gt;To have Unemployment Insurance payment checks mailed to your residence, select Check from the list below.&lt;/li&gt;
&lt;/ul&gt;&lt;br&gt;
&lt;p class="pb"&gt;Facts About Direct Deposit:&lt;/p&gt;&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt;Enrolment in direct Deposit is not a request for benefits. You must make your request for benefits on the date you are given at the completion of your claim and every 2 weeks thereafter.&lt;/li&gt;
  &lt;li&gt;If you are found payable, you should expect a deposit in your account within 3-4 business days after requesting your benefits.&lt;/li&gt;
  &lt;li&gt;You can confirm deposit of your unemployment insurance benefits by contacting your bank.&lt;/li&gt;
  &lt;li&gt;New or changed direct deposits will result in one paper check after submission.&lt;/li&gt;
  &lt;li&gt;The Office of Employment and Training must be notified of any account changes immediately in order to ensure proper payment of funds.&lt;/li&gt;
  &lt;li&gt;Should the bank not be able to process the deposited funds into the specified account, the claimant is responsible for any resulting bank fees incurred.&lt;/li&gt;
  &lt;li&gt;The authorization to deposit funds into the noted account will remain in effect until the claimant initiates a change.&lt;/li&gt;
  &lt;li&gt;To have Unemployment Insurance payments automatically deposited to your bank, select Direct Deposit from the list below.&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_payment_method" input-type="Dropdown">
        <default default="Check" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Based on the information above, what is Your preferred method of payment?&lt;/b&gt;</caption>
        <list>
          <option text="Check" default-visibility="true">Check</option>
          <option text="Direct  Deposit" default-visibility="true">Direct  Deposit</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Witholding Taxes - Federal and State&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="fc_federal_tax" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you want 10 percent of your benefit check withheld for Federal taxes?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_state_tax" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do You want 4 percent of your benefit check withheld for State Taxes?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s140@Interviews_IFFScreens_xint" title="Alien Status" entity="global">
      <input-control type="Statement" attr="fc_alien_is_valid" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Do you have a valid alien registration number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_alien_registration_no" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is your alien registration number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s124@Interviews_IFFScreens_xint" title="Resident  Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;your base period is &amp;nbsp  %fpr_base_period_start_date% &amp;nbsp through &amp;nbsp %fpr_base_period_end_date%&lt;/h3&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_in_kentucky_filing" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Are You currently a resident of Kentucky?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fc_work_in_other_state" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;Other than being on a military assignment,&lt;/b&gt;&lt;br&gt;
&lt;b&gt;did you work in a state other than Kentucky duiring your base period?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s211@Interviews_IFFScreens_xint" title="Filing Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;To File Your Kentucky Unemployment Claim You will Need:&lt;/h3&gt;
&lt;br&gt;
&lt;i class="pb"&gt;Information about you&lt;/i&gt;
&lt;ul class="ck"&gt;
  &lt;li&gt; Your date of Birth&lt;/li&gt;
  &lt;li&gt; Your complete address&lt;/li&gt;
  &lt;li&gt; Your primary phone number and (optional) an alternative phone number &lt;/li&gt;
  &lt;li&gt; If NOT a US Citizen, your Alien Registration Number&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;
&lt;i class="pb"&gt;Employment Information: (for the last 18 months)&lt;/i&gt;
&lt;ul class="ck"
  &lt;li&gt; Company - name&lt;/li&gt;
  &lt;li&gt; Company - complete and current mailing address (including zip code)&lt;/li&gt;
  &lt;li&gt; Company - Phone Number (including area code)&lt;/li&gt;
  &lt;li&gt; Dates of Employment (Starting –through - Ending)&lt;/li&gt;
  &lt;li&gt; Reason(s) you are no longer working (for each employer listed)&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;
&lt;i class="pb"&gt;Other Information You May Need:&lt;/i&gt;
&lt;ul class="ck"&gt;
  &lt;li&gt;If you worked in a state(s) other than Kentucky in the past 18 months, A list of states in which you worked&lt;/li&gt;
  &lt;li&gt;If you worked for any temporary agencies, you must provide the names of the temporary agencies - NOT the location or companies the agency assigned you to work at&lt;/li&gt;
  &lt;li&gt;If you worked for the Federal Government, provide the Agency name AND Component Name. You may also be asked to provide a copy of the Standard Form 8 (SF 8).&lt;/li&gt;
  &lt;li&gt;If you were in the US Military, provide a copy of your DD214 member 4 to your nearest local office (Kentucky Career Center)&lt;/li&gt;
  &lt;li&gt;If you worked for a skilled Trade Union – list the contractor(s) for whom you worked. Not the union&lt;/li&gt;
&lt;/ul&gt;
&lt;br&gt;
&lt;i class="pb"&gt;If you do not have this information available&lt;/i&gt;
&lt;ul class="ck"&gt;
  &lt;li&gt;Log-off &lt;/li&gt;
  &lt;li&gt;Gather the required information&lt;/li&gt;
  &lt;li&gt;Return to this site and continue the claim filing process.&lt;/li&gt;
&lt;/ul&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s214@Interviews_IFFScreens_xint" title="Direct Deposit" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../../images/directDepositHelp.gif"&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="note"&gt;You have elected to use Direct Deposit as your method of receiving payment.
You are responsible for the accuracy of the following information.&lt;/p&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="fc_bankholder_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is the Account Holders name?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_bankholder_bank" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;What is the name of the Bank?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Number" attr="fc_bankholder_routing_number" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b class="pr"&gt;What Bank Routing Number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Number" attr="fc_bankholder_acct_number" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b class="pg"&gt;What is your Account Number?&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="fc_bankholder_account_type" input-type="Dropdown">
        <default default="Checking" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;b&gt;What type of account is it?&lt;/b&gt;</caption>
        <list>
          <option text="Checking" default-visibility="true">Checking</option>
          <option text="Savings" default-visibility="true">Savings</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <screen ref="s211@Interviews_IFFScreens_xint" />
        <screen ref="s45@Interviews_IFFScreens_xint" />
        <screen ref="s14@Interviews_IFFScreens_xint" />
        <screen ref="s71@Interviews_IFFScreens_xint" />
        <screen ref="s214@Interviews_IFFScreens_xint" />
        <screen ref="s124@Interviews_IFFScreens_xint" />
        <screen ref="s140@Interviews_IFFScreens_xint" />
        <screen ref="s192@Interviews_IFFScreens_xint" />
        <screen ref="s195@Interviews_IFFScreens_xint" />
        <screen ref="s54@Interviews_IFFScreens_xint" />
        <screen ref="s12@Interviews_IFFScreens_xint" />
        <screen ref="s139@Interviews_IFFScreens_xint" />
        <screen ref="s158@Interviews_IFFScreens_xint" />
        <screen ref="s147@Interviews_IFFScreens_xint" />
        <screen ref="s157@Interviews_IFFScreens_xint" />
        <screen ref="s155@Interviews_IFFScreens_xint" />
        <screen ref="s159@Interviews_IFFScreens_xint" />
        <screen ref="s210@Interviews_IFFScreens_xint" />
        <screen ref="s177@Interviews_IFFScreens_xint" />
        <screen ref="s179@Interviews_IFFScreens_xint" />
        <screen ref="s178@Interviews_IFFScreens_xint" />
        <screen ref="s208@Interviews_IFFScreens_xint" />
        <screen ref="s209@Interviews_IFFScreens_xint" />
        <screen ref="s122@Interviews_IFFScreens_xint" />
        <screen ref="s134@Interviews_IFFScreens_xint" />
        <screen ref="s138@Interviews_IFFScreens_xint" />
        <screen ref="s64@Interviews_IFFScreens_xint" />
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>