<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Demonstration: OET Claim Filing, Version 0.1 " entity="global">
      <goal-control type="Goal" flow="f3@Interviews_Screens_xint">
        <visibility default="enabled" />
        <caption>&lt;img src="../../../images/start.png"</caption>
        <internal-properties>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </goal-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../images/watermark.png" class="center" &gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <goal-control attr="fpr_non_zero_issues">
        <caption type="unknown">Click here to determine if at least one issue has been raised</caption>
        <visibility default="enabled" />
        <internal-properties>
          <property name="IsHTML" type="boolean">false</property>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </goal-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s7@Interviews_Screens_xint" title="Claim Filing Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="tcb"&gt;This is an application for Unemployment Insurance. Intentionally submitting false information to obtain benefits is a criminal act.&lt;br&gt;
Any violation will result in prosecution under KRS.331.370(2).&lt;/p&gt;&lt;br&gt;
&lt;p class="tcu"&gt;YOU ARE RESPONSIBLE FOR THE ACCURACY OF ALL OF YOUR ANSWERS&lt;/p&gt;
&lt;br&gt;
&lt;h2&gt;To file your Kentucky Unemployment claim, you will need:&lt;/h2&gt;
&lt;p class="pb"&gt;Persoinal information&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;Date of birth&lt;/li&gt;
  &lt;li&gt;Complete mailing address&lt;/li&gt;
  &lt;li&gt;Phone number&lt;/li&gt;
  &lt;li&gt;Alien registration number If not a US Citizen&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;Employment information for last 18 months&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;Employer name&lt;/li&gt;
  &lt;li&gt;Employer address&lt;/li&gt;
  &lt;li&gt;Employer phone number&lt;/li&gt;
  &lt;li&gt;Start and end dates&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;Other information&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;List of state(s) you worked in other than Kentucky in the past 18 months&lt;/li&gt;
  &lt;li&gt;Standard Form 8 and/or 50 if worked for Federal Government in the past 18 months&lt;/li&gt;
  &lt;li&gt;DD214 member 4 if served in US Military in the past 18 months&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;If you do not have this information, exit the system, gather required information and return to this site and continue the claim filing process.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s8@Interviews_Screens_xint" title="Benefit Period Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;
&lt;h2 class="tc"&gt;Important Dates!&lt;/h2&gt;
&lt;br&gt;
&lt;p&gt;There are two important time periods when filing a claim:&lt;b&gt; Base Period&lt;/b&gt; and &lt;b&gt;Benefit Year&lt;/b&gt;&lt;/p&gt;&lt;br&gt;
&lt;p&gt;Based on today's date, your dates are as follows:
&lt;br&gt;
&lt;br&gt;
&lt;table class="nxtable"&gt;
  &lt;tr&gt;
    &lt;th class="nxth"&gt;Base Period&lt;/th&gt;
    &lt;th class="nxth"&gt;Date&lt;/th&gt;
	&lt;th class="nxth"&gt;Benefit Year&lt;/th&gt;
	&lt;th class="nxth"&gt;Date&lt;/th&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td class="nxtd"&gt;Start Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_base_period_start_date%&lt;/td&gt;
	&lt;td class="nxtd"&gt;Effective Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_effective_date%&lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td class="nxtd"&gt;End Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_base_period_end_date% &lt;/td&gt;
    &lt;td class="nxtd"&gt;End Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%mr_byed%&lt;/td&gt;
  &lt;/tr&gt;
  &lt;/table&gt;
&lt;br&gt;&lt;br&gt;
&lt;p&gt;Your wages/earnings in the &lt;b&gt;Base Period&lt;/b&gt; determine your weekly benefit amount.
&lt;br&gt;Your Base Period is the first four of the last five calendar quarters immediately prior to the quarter in which you file your claim.
&lt;br&gt;If you do not have sufficient earnings in your Base Period, you may not qualify for benefits.&lt;/p&gt;
&lt;br&gt;&lt;br&gt;
&lt;p&gt;The &lt;b&gt;Benefit Year&lt;/b&gt; Effective Date is the Sunday of the week in which you complete your claim.  
&lt;br&gt;The Benefit Year End Date (or BYE) is approximately 1 year after the Effective Date.  
&lt;br&gt;Should you qualify for benefits, you will be mailed your weekly benefit amount, which is valid until your BYE.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s10@Interviews_Screens_xint" title="Military Experience" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_served_in_military" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;P&gt;Did you serve in the military between %g01_base_period_start_date% and %g01_effective_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s11@Interviews_Screens_xint" title="Unemployment Benefits from state other than Kentucky" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_ui_balance_other_state" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you still have a balance in another state, whether or not you were found eligible?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s12@Interviews_Screens_xint" title="Personal Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please provide the following information in order to help us in the event we need to contact you.&lt;/p&gt;
&lt;hr&gt;

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_is_citizen" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a United States citizen?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_claimant_alias" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please list other names under which you have worked (maiden name, married name, etc.):&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_claimant_birthday" input-type="default">
        <default default="1959-12-31" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Birth Date:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_claimant_home_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Primary phone number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_claimant_alternate_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Alternate phone number&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_claimant_email" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Email address:&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_interpreter_required" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Should we need to contact you, is an interpreter needed?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_interpretor_language" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Prefered language?&lt;/p&gt;</caption>
        <list>
          <option text="Spanish" default-visibility="true">Spanish</option>
          <option text="Portuguese" default-visibility="true">Portuguese</option>
          <option text="Chinese" default-visibility="true">Chinese</option>
          <option text="Tagalog" default-visibility="true">Tagalog</option>
          <option text="French" default-visibility="true">French</option>
          <option text="Vietnamese" default-visibility="true">Vietnamese</option>
          <option text="English" default-visibility="true">English</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;The following questions are optional and are for statistical purposes only&lt;/p&gt;
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_claimant_gender" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Gender:&lt;/p&gt;</caption>
        <list>
          <option text="Male" default-visibility="true">Male</option>
          <option text="Female" default-visibility="true">Female</option>
          <option text="No Answer" default-visibility="true">No Answer</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_claimant_ethnic_group" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Ethnic group:&lt;/p&gt;</caption>
        <list>
          <option text="Hispanic or Latino" default-visibility="true">Hispanic or Latino</option>
          <option text="Not Hispanic or Latino" default-visibility="true">Not Hispanic or Latino</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_claimant_race" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Race:&lt;/p&gt;</caption>
        <list>
          <option text="White" default-visibility="true">White</option>
          <option text="Black or African American" default-visibility="true">Black or African American</option>
          <option text="Asian" default-visibility="true">Asian</option>
          <option text="American Indian or Alaskan Native" default-visibility="true">American Indian or Alaskan Native</option>
          <option text="Native Hawaiian or Other Pacific Islander" default-visibility="true">Native Hawaiian or Other Pacific Islander</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_disability" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a disability&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s13@Interviews_Screens_xint" title="Mailing Address" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please verify the information below and update if needed.&lt;/p&gt;
&lt;hr&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_current_street_address" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Street address:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_current_appt_num" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Suite or Apt. Number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_current_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_current_state" input-type="Dropdown">
        <default default="KY" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;State:&lt;/p&gt;</caption>
        <list>
          <option text="Alabama" default-visibility="true">AL</option>
          <option text="Alaska" default-visibility="true">AK</option>
          <option text="Arizona" default-visibility="true">AZ</option>
          <option text="Arkansas" default-visibility="true">AR</option>
          <option text="California" default-visibility="true">CA</option>
          <option text="Colorado" default-visibility="true">CO</option>
          <option text="Connecticut" default-visibility="true">CT</option>
          <option text="Delaware" default-visibility="true">DE</option>
          <option text="District Of Columbia" default-visibility="true">DC</option>
          <option text="Florida" default-visibility="true">FL</option>
          <option text="Georgia" default-visibility="true">GA</option>
          <option text="Hawaii" default-visibility="true">HI</option>
          <option text="Idaho" default-visibility="true">ID</option>
          <option text="Illinois" default-visibility="true">IL</option>
          <option text="Indiana" default-visibility="true">IN</option>
          <option text="Iowa" default-visibility="true">IA</option>
          <option text="Kansas" default-visibility="true">KS</option>
          <option text="Kentucky" default-visibility="true">KY</option>
          <option text="Louisiana" default-visibility="true">LA</option>
          <option text="Maine" default-visibility="true">ME</option>
          <option text="Maryland" default-visibility="true">MD</option>
          <option text="Massachusetts" default-visibility="true">MA</option>
          <option text="Michigan" default-visibility="true">MI</option>
          <option text="Minnesota" default-visibility="true">MN</option>
          <option text="Mississippi" default-visibility="true">MS</option>
          <option text="Missouri" default-visibility="true">MO</option>
          <option text="Montana" default-visibility="true">MT</option>
          <option text="Nebraska" default-visibility="true">NE</option>
          <option text="Nevada" default-visibility="true">NV</option>
          <option text="New Hampshire" default-visibility="true">NH</option>
          <option text="New Jersey" default-visibility="true">NJ</option>
          <option text="New Mexico" default-visibility="true">NM</option>
          <option text="New York" default-visibility="true">NY</option>
          <option text="North Carolina" default-visibility="true">NC</option>
          <option text="North Dakota" default-visibility="true">ND</option>
          <option text="Ohio" default-visibility="true">OH</option>
          <option text="Oklahoma" default-visibility="true">OK</option>
          <option text="Oregon" default-visibility="true">OR</option>
          <option text="Pennsylvania" default-visibility="true">PA</option>
          <option text="Rhode Island" default-visibility="true">RI</option>
          <option text="South Carolina" default-visibility="true">SC</option>
          <option text="South Dakota" default-visibility="true">SD</option>
          <option text="Tennessee" default-visibility="true">TN</option>
          <option text="Texas" default-visibility="true">TX</option>
          <option text="Utah" default-visibility="true">UT</option>
          <option text="Vermont" default-visibility="true">VT</option>
          <option text="Virginia" default-visibility="true">VA</option>
          <option text="Washington" default-visibility="true">WA</option>
          <option text="West Virginia" default-visibility="true">WV</option>
          <option text="Wisconsin" default-visibility="true">WI</option>
          <option text="Wyoming" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_current_county" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;County:&lt;/p&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string">Body_body</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_current_zip" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Zip code:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_current_address_is_po" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the address contain a post office box number?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s14@Interviews_Screens_xint" title="Physical Address" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please enter the physical address at which you reside.&lt;/p&gt;
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_permanent_address" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Street address:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_permanent_appt_no" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Suite or Apt Number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_permanent_city" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_permanent_county" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;County:&lt;/p&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_permanent_state" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;State:&lt;/p&gt;</caption>
        <list>
          <option text="Alabama" default-visibility="true">AL</option>
          <option text="Alaska" default-visibility="true">AK</option>
          <option text="Arizona" default-visibility="true">AZ</option>
          <option text="Arkansas" default-visibility="true">AR</option>
          <option text="California" default-visibility="true">CA</option>
          <option text="Colorado" default-visibility="true">CO</option>
          <option text="Connecticut" default-visibility="true">CT</option>
          <option text="Delaware" default-visibility="true">DE</option>
          <option text="District Of Columbia" default-visibility="true">DC</option>
          <option text="Florida" default-visibility="true">FL</option>
          <option text="Georgia" default-visibility="true">GA</option>
          <option text="Hawaii" default-visibility="true">HI</option>
          <option text="Idaho" default-visibility="true">ID</option>
          <option text="Illinois" default-visibility="true">IL</option>
          <option text="Indiana" default-visibility="true">IN</option>
          <option text="Iowa" default-visibility="true">IA</option>
          <option text="Kansas" default-visibility="true">KS</option>
          <option text="Kentucky" default-visibility="true">KY</option>
          <option text="Louisiana" default-visibility="true">LA</option>
          <option text="Maine" default-visibility="true">ME</option>
          <option text="Maryland" default-visibility="true">MD</option>
          <option text="Massachusetts" default-visibility="true">MA</option>
          <option text="Michigan" default-visibility="true">MI</option>
          <option text="Minnesota" default-visibility="true">MN</option>
          <option text="Mississippi" default-visibility="true">MS</option>
          <option text="Missouri" default-visibility="true">MO</option>
          <option text="Montana" default-visibility="true">MT</option>
          <option text="Nebraska" default-visibility="true">NE</option>
          <option text="Nevada" default-visibility="true">NV</option>
          <option text="New Hampshire" default-visibility="true">NH</option>
          <option text="New Jersey" default-visibility="true">NJ</option>
          <option text="New Mexico" default-visibility="true">NM</option>
          <option text="New York" default-visibility="true">NY</option>
          <option text="North Carolina" default-visibility="true">NC</option>
          <option text="North Dakota" default-visibility="true">ND</option>
          <option text="Ohio" default-visibility="true">OH</option>
          <option text="Oklahoma" default-visibility="true">OK</option>
          <option text="Oregon" default-visibility="true">OR</option>
          <option text="Pennsylvania" default-visibility="true">PA</option>
          <option text="Rhode Island" default-visibility="true">RI</option>
          <option text="South Carolina" default-visibility="true">SC</option>
          <option text="South Dakota" default-visibility="true">SD</option>
          <option text="Tennessee" default-visibility="true">TN</option>
          <option text="Texas" default-visibility="true">TX</option>
          <option text="Utah" default-visibility="true">UT</option>
          <option text="Vermont" default-visibility="true">VT</option>
          <option text="Virginia" default-visibility="true">VA</option>
          <option text="Washington" default-visibility="true">WA</option>
          <option text="West Virginia" default-visibility="true">WV</option>
          <option text="Wisconsin" default-visibility="true">WI</option>
          <option text="Wyoming" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_permanent_zip" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Zip code:&lt;/p&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s15@Interviews_Screens_xint" title="Your Alien Registration Number" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_aa_alien_reg_code" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your alien registration number?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s16@Interviews_Screens_xint" title="Payment Method" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;p class="pbb"&gt;If you are found payable, you should receive payment within 3-4 business days after requesting your benefits.&lt;br&gt;
You must make your request for benefits on the date you are given at the completion of filing your claim and every 2 weeks thereafter.&lt;/p&gt;
&lt;br&gt;&lt;br&gt;
&lt;p class="pb"&gt;Information about direct deposit:&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;You can confirm deposit of your unemployment insurance benefits by contacting your bank&lt;/li&gt;
  &lt;li&gt;New or changed direct deposits will result in one paper check for the first 2 week period after submission&lt;/li&gt;
  &lt;li&gt;Should the bank not be able to process the deposited funds into the specified account, the claimant is responsible for any resulting bank fees&lt;/li&gt;
  &lt;li&gt;The authorization to deposit funds into the provided account will remain in effect until the claimant initiates a change&lt;/li&gt;
 &lt;/ul&gt;
&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_payment_method" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pb"&gt;What is your preferred method of receiving unemployment benefits payment?&lt;/p&gt;</caption>
        <list>
          <option text="Check" default-visibility="true">Check</option>
          <option text="Direct  Deposit" default-visibility="true">Direct  Deposit</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s17@Interviews_Screens_xint" title="Direct Deposit" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../../images/directDepositHelp.gif" class="center" /&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="note"&gt;You have elected to use Direct Deposit as your method of receiving payment.
You are responsible for the accuracy of the following information.&lt;/p&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_direct_deposit_name" input-type="default">
        <default default="Fotzapple" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Account holders name:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_direct_deposit_bank" input-type="default">
        <default default="Fourth Second" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Bank name:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_direct_deposit_routing" input-type="default">
        <default default="5551212" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pr"&gt;Routing number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fpr_direct_deposit_account" input-type="default">
        <default default="5551212" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pg"&gt;Account number&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_direct_deposit_type" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Account type&lt;/p&gt;</caption>
        <list>
          <option text="Checking" default-visibility="true">Checking</option>
          <option text="Savings" default-visibility="true">Savings</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s18@Interviews_Screens_xint" title="Benefit Withholdings" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pbb"&gt;If you are found payable, your benefits are taxable&lt;/p&gt;&lt;br&gt;
&lt;p class="pbb"&gt;Unemployment insurance benefits are taxable and must be reported 
on your income tax return.&lt;br&gt;OET will report the total amount of your benefits 
to the Internal Revenue Service and will provide&lt;br&gt;you with an annual 
statement (Form 1099G), no later than January 31st of each year.&lt;/p&gt;&lt;br&gt;&lt;br&gt;&lt;p&gt;
You may elect to have 10 percent of your benefits withheld for federal taxes 
and 4 percent withheld for state taxes.&lt;br&gt;This is optional and may be changed once 
during your benefit year.&lt;/p&gt; 
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_withhold_federal" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do You want 10 percent of your benefit check withheld for Federal Taxes?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_withhold_state" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do You want 4 percent of your benefit check withheld for State Taxes?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s19@Interviews_Screens_xint" title="Workers Compensation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_received_workers_comp" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive workers compensation benefits between %g01_base_period_start_date% and %g01_base_period_end_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_eligible_workers_comp" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you eligible to receive workers compensation benefits between %g01_base_period_start_date% and %g01_base_period_end_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s20@Interviews_Screens_xint" title="Workers Compensation Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;If you did receive or were eligible to receive Worker's Compensation between 
these dates you will need to provide documentation&lt;br&gt;(ie. paystubs or letter) 
showing the dates of eligibility.  You should be able to obtain this from your employer’s 
insurance carrier or Worker’s Compensation.&lt;br&gt;  
You will need to provide proof of Worker’s Compensation benefits or notify your 
nearest Kentucky Career Center Office that you are in the process of obtaining this information.
&lt;br&gt;&lt;br&gt;
You will need to provide proof of this information to your nearest Kentucky Career Center Office. 
If you live outside of Kentucky, please contact the Interstate Office.&lt;/p&gt;
&lt;br&gt;
&lt;p class="pr"&gt;Failure to report within 10 days of the mail date of this letter may delay 
the processing of your claim or result in the denial of benefits.&lt;br&gt; 
Thank you for your cooperation.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s21@Interviews_Screens_xint" title="Natural Disaster Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_natural_disaster" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you unemployed as a result of a natural disaster?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s22@Interviews_Screens_xint" title="Distance to Kentucky" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_within_commuting_distance" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you within commuting distance to Kentucky?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s26@Interviews_Screens_xint" title="Trade Union" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_union_member" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a member in good standing of a trade union?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s27@Interviews_Screens_xint" title="Trade Union Work Search" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_union_provides_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the trade union find work for you?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s28@Interviews_Screens_xint" title="Information about your type of work" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_area_of_expertise" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your field of work or industry?&lt;/p&gt;</caption>
        <list>
          <option text="Accommodation and Food Services" default-visibility="true">Accommodation and Food Services</option>
          <option text="Administrative and Support Services" default-visibility="true">Administrative and Support Services</option>
          <option text="Agriculture, Forestry, Fishing and Hunting" default-visibility="true">Agriculture, Forestry, Fishing and Hunting</option>
          <option text="Air Transportation" default-visibility="true">Air Transportation</option>
          <option text="Arts, Entertainment, and Recreation" default-visibility="true">Arts, Entertainment, and Recreation</option>
          <option text="Construction" default-visibility="true">Construction</option>
          <option text="Educational Services" default-visibility="true">Educational Services</option>
          <option text="Finance and Insurance" default-visibility="true">Finance and Insurance</option>
          <option text="Health Care and Social Assistance" default-visibility="true">Health Care and Social Assistance</option>
          <option text="Information" default-visibility="true">Information</option>
          <option text="Manufacturing" default-visibility="true">Manufacturing</option>
          <option text="Management of Companies and Enterprises" default-visibility="true">Management of Companies and Enterprises</option>
          <option text="Mining, Quarrying, and Oil and Gas Extraction" default-visibility="true">Mining, Quarrying, and Oil and Gas Extraction</option>
          <option text="Other Services (except Public Administration)" default-visibility="true">Other Services (except Public Administration)</option>
          <option text="Paper Manufacturing" default-visibility="true">Paper Manufacturing</option>
          <option text="Professional, Scientific, and Technical Services" default-visibility="true">Professional, Scientific, and Technical Services</option>
          <option text="Public Administration" default-visibility="true">Public Administration</option>
          <option text="Real Estate and Rental and Leasing" default-visibility="true">Real Estate and Rental and Leasing</option>
          <option text="Retail Trade" default-visibility="true">Retail Trade</option>
          <option text="Transportation and Warehousing" default-visibility="true">Transportation and Warehousing</option>
          <option text="Utilities" default-visibility="true">Utilities</option>
          <option text="Waste Management and Remediation Services" default-visibility="true">Waste Management and Remediation Services</option>
          <option text="Wholesale Trade" default-visibility="true">Wholesale Trade</option>
          <option text="Wholesale Electronic Markets and Agents and Brokers" default-visibility="true">Wholesale Electronic Markets and Agents and Brokers</option>
          <option text="Wood Product Manufacturing" default-visibility="true">Wood Product Manufacturing</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_advanced_ed_required" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your job require advanced education or a certification or a license?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_refused_suitable" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you refused an offer of work since %g01_filing_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s29@Interviews_Screens_xint" title="Your Availability For Work" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_has_reliable_transportation" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have reliable transportation (personal vehicle, public transportation, etc.) to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_is_in_school" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you enrolled in a school or training program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_cares" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the care of others (child care, elder care, care of family member, etc.) limit your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_in_jail" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you incarcerated or scheduled to report for incarceration (imprisoned, jailed, house arrest, work release, etc.)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_is_self_employed" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you self-employed?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_on_commission" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you work on a commission basis?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_is_closely_held" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a corporate officer in a closely-held corporation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s30@Interviews_Screens_xint" title="Your Transportation Restrictions " entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_trans_restrict_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did this restriction on your transportation begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_knows_when_trans_restrict_ends" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when this restriction on your transportation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_trans_no_good" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your transportation problem prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_transpo_prev_accept_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your transportation problems prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_has_alt_trans" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have any alternate means of transportation?&lt;/p&gt; </caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s31@Interviews_Screens_xint" title="Your Transportation Restriction End Date" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_trans_restrict_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect this restriction on your transportation to end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s32@Interviews_Screens_xint" title="Your Alternative Transportation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_alt_trans_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe your alternate means of transportation.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">3</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s33@Interviews_Screens_xint" title="Your School or Training Program" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_training_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did you begin school or training program?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_training_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect to complete your school or training program?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_training_hrs_per_wk" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week (on-line or in-person) do you attend class(es) for your school or training program?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_school_no_look" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your school or training program prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_school_no_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Will your school or training program prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_gives_up_school" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you be willing to give up your school or training in favor of suitable employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_is_apprentice" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you in a trade union apprentice program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimants_school_is_ok" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has your enrollment in school or training program been approved by the Division of Unemployment Insurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s34@Interviews_Screens_xint" title="Approved School or Training Program Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_training_schedule_change" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has there been a change to the program or schedule since you were approved?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_approved_training_program" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_program_study_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the begin date for the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_program_study_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the end date for the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s36@Interviews_Screens_xint" title="Care of Others Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_claimant_cares_alternatly" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have any alternate means of care (daycare, babysitter, eldercare, family member, etc.)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_care_no_look" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your duty of dependent care prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_care_no_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your duty of dependent care prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_dependent_care_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the limitation due to the care of others begin?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_knows_dependent_conclusion" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when the limitation due to the care of others will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_dependent_care_hrs_per_wk" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to the care of others?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s37@Interviews_Screens_xint" title="Care of Others Conclusion" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_dependent_care_conclusion" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect the limitation due to the care of others to end? &lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s38@Interviews_Screens_xint" title="Care of Others Alternate" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_alternate_care_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe your alternate means of care.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s39@Interviews_Screens_xint" title="Self Employment Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_self_empl_hours" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to self employment work?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_will_quit_self_empl" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you be willing to quit self employment work if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_self_emp_prevents_search" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your self-employment prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_self_empl_prevents_accept" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your self-employment prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s40@Interviews_Screens_xint" title="Officer in Corporation Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_co_hours" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to serving as an officer of a closely held corporation?&lt;/p.
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_will_quit_co" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you be willing to quit serving as an officer of a closely held corporation if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_co_prevents_search" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your corporate officer position prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_co_prevents_accept" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your corporate officer position prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s41@Interviews_Screens_xint" title="Incarceration Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_work_release_eligable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you permitted to look for or accept work under a work release program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_jail_no_look" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your incarceration prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_jail_no_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your incarceration prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_incarceration_facility" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the facility at which you are incarcerated?  If under house arrest, please list ‘Home’&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_incarceration_begin_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your incarceration begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_incarceration_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect your incarceration to end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s42@Interviews_Screens_xint" title="Work Ability Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_has_physical_health_issue" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a physical condition that limits your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_mental_health_issues" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a mental health condition that limits your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_ss_disability_last_twelve" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you receiving or been approved for Social Security disability payments in the last 12 months?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_applied_ss_disability" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have an application in progress for Social Security disability payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s43@Interviews_Screens_xint" title="Physical Limitation Information" entity="global" attr="b1@Interviews_Screens_xint">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_physical_health_prevents_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your physical health condition prevent you from working?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_physical_begin_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your physical limitation begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_restriction_end_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when physical limitation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_medical_document_in_support" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation supporting your physical limitation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_perform_limited_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is there any work you can perform?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;What is your physical limitation? Check all that apply.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_lift_fifty" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Lifting 50 lbs. or more&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_repetitive_motion" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Repetitive Motion&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_standing_long" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Standing&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_restricted_hours" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Limited Hours (please provide the number of work hours restricted to) &lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s44@Interviews_Screens_xint" title="Physical Limitation Ending" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_physical_limit_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect your physical limitation to end?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s45@Interviews_Screens_xint" title="Mental Health Limitation Information" entity="global" attr="b2@Interviews_Screens_xint">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_mental_health_prevents_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your mental health condition prevent you from working?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fpr_mental_issue_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your mental health limitation begin?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_no_longer_mental_ill" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when mental health limitation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_mental_health_document" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation supporting your mental health limitation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_some_mental_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Can you perform any work in any capacity?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_mental_condition_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe how you are limited.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">4</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s46@Interviews_Screens_xint" title="Mental Health Improvement" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_mental_health_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect your mental health condition to end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s47@Interviews_Screens_xint" title="Social Security Disability Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_disability_on_physical" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you apply for disability based on a physical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_disability_on_mental" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you apply for disability based on a mental health condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s65@Interviews_Screens_xint" title="Claim Filing Certification and Authorization" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;p class="tcb"&gt;Intentionally submitting false information is a criminal act.  Any violation will result in prosecution under KRS.341.370 (2).&lt;p&gt;
&lt;br&gt;
&lt;p class="tcb"&gt;You may access the Rights and Responsibilities pamphlet (PAM-UI-400) by clicking &lt;a href="https://uiclaims.des.ky.gov/eBenefits_enu/help/PAM_UI_400.htm"&gt;here&lt;/a&gt; or at your local Unemployment Insurance Office.&lt;/p&gt;
&lt;br&gt;
&lt;p class="tcb"&gt;Effective January 1, 2012, Kentucky Unemployment Insurance law requires a one week waiting period per Benefit Year.&lt;br&gt; 
Your waiting period week will be your first payable week. 
If you are found eligible for benefits you will request benefits for two week periods,&lt;br&gt;however your first check will only be for one week.&lt;/p&gt;
&lt;br&gt;
&lt;p class="pb"&gt;Please enter your initials in each box to acknowledge each statement.&lt;/p&gt;
&lt;hr&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_final_pam_acceptance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I was given access to the PAM-UI-400, Rights and Responsibilities pamphlet.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_final_wage_report_acceptance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that I must report ALL WAGES EARNED.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_final_job_search_acceptance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that I must look for one or more jobs per week.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_final_waiting_period_acceptance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that there is a one week waiting period per Benefit Year.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_final_employer_release" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I authorize my former employer(s) to release all information requested in connection with my claim
for unemployment insurance benefits.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fpr_final_info_certification" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I certify that the information I have provided on this claim for unemployment insurance benefits is true 
and correct to the best of my knowledge.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class ="pb"&gt;Please enter your full name in the box to the right to complete your application.&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_final_rights" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand my rights and wish to submit my application for unemployment insurance benefits.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="xrulz_screen_15" title="Employment Status for %fpr_emt_visible_name% " entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pbsmall"&gt;Below are descriptions of several categories related to loss of employment.&lt;/p&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li class="tbsmall"&gt;Currently Employed (Full-time or part-time)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) You continue working full-time in accordance with your employer's customary full-time work schedule or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;You are working part-time, working on-call, as needed, PRN status&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Leave of Absence&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) On FMLA, Short-term disability, etc.&lt;/li&gt;
	  &lt;li class="nsmall"&gt;You are temporarily away from work for personal reasons and you are expected to return to your position&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tbsmall"&gt;Suspension&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) You are temporarily away from work due to a diciplinary action or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;investigation initiated by your employer&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tbsmall"&gt;Quit&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) An employee may choose to leave a job for changes in personal circumstances, working conditions, prospects of other work, etc.&lt;/li&gt;
	&lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Retired (Voluntary or Involuntary)&lt;/li&gt;
    &lt;ul&gt;
      &lt;li class="nsmall"&gt;(eg.) You voluntarily retired from the workforce, you are  receiving retirement/pension or retainer benefits, or&lt;/li&gt;
      &lt;li class="nsmall"&gt;you retired in accordance with the employer mandqatory retirement policy.&lt;/li&gt;
    &lt;/ul&gt;	  
  &lt;li class="tbsmall"&gt;Discharged (aka. Terminated, fired, let-go, sacked, canned, etc)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) Employer chooses to require the employee to leave, generally, the employer states that it is the fault of the employee:&lt;/li&gt;
	  &lt;li class="nsmall"&gt;attendance, policy violation, work performance, failed drug test, etc.&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Laid Off&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;(eg.) Position eliminated or a business slow-down occured due to economic cycles or&lt;/li&gt;
	  &lt;li class="nsmall"&gt;the company's need to restructure itself, the firm itself going out of business or a change in the function of the employer&lt;/li&gt;
	     &lt;ul&gt;
		   &lt;li class="nsmall"&gt;(eg.) A certain type of product or service is no longer offered by the company therefore jobs related to that product or service are no longer needed&lt;/li&gt;
		&lt;/ul&gt;
    &lt;/ul&gt;	
  &lt;li class="tbsmall"&gt;Labor Dispute&lt;/li&gt;	
     &lt;ul&gt;
	    &lt;li class="nsmall"&gt;You are a member of a labor union and are involved in ongoing strike actions undertaken by the labor union&lt;/li&gt;
     &lt;/ul&gt;	 
&lt;/ul&gt;  
&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_the_selected_status" input-type="Dropdown">
        <default default="Quit" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Which category best describes your status for %g01_employment_instance_id%?&lt;/p&gt;</caption>
        <list>
          <option text="Currently Employed" default-visibility="true">Currently Employed</option>
          <option text="leave Of Abscence" default-visibility="true">leave Of Abscence</option>
          <option text="Suspended" default-visibility="true">Suspended</option>
          <option text="Quit" default-visibility="true">Quit</option>
          <option text="Retired" default-visibility="true">Retired</option>
          <option text="Discharged" default-visibility="true">Discharged</option>
          <option text="Laid Off" default-visibility="true">Laid Off</option>
          <option text="Labor Dispute" default-visibility="true">Labor Dispute</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s5@Interviews_Screens_xint" title="Resignation for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_emp_request_resignation" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer request your resignation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s67@Interviews_Screens_xint" title="Resignation Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated the employer requested your resignation.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emt_reason_emr_req_resign" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason that your employer requested your resignation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_terminated_if_not_resigned" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you have been discharged (terminated) if you had not resigned?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s70@Interviews_Screens_xint" title="Quit Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please select the circumstances that most closely reflects the reason you quit this employment&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;ul&gt;
  &lt;li class="tbsmall"&gt;Personal Reasons&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;examples of Personal Reasons include but are not limited to:&lt;/li&gt;
      &lt;li class="nsmall"&gt;non work-related injury or health condition&lt;/li&gt;
	  &lt;li class="nsmall"&gt;domestic circumstances&lt;/li&gt;
	  &lt;li class="nsmall"&gt;attending school&lt;/li&gt;
	  &lt;li class="nsmall"&gt;relocation&lt;/li&gt;
	  &lt;li class="nsmall"&gt;military reassignment&lt;/li&gt;
	&lt;/ul&gt;
  &lt;li class="tbsmall"&gt;Work-Related&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;examples of Work-Related Reasons include but are not limited to:&lt;/li&gt;
	  &lt;li class="nsmall"&gt;working conditions&lt;/li&gt;
	  &lt;li class="nsmall"&gt;hurt on the job&lt;/li&gt;
	  &lt;li class="nsmall"&gt;lack of training&lt;/li&gt;
	  &lt;li class="nsmall"&gt;safety concerns&lt;/li&gt;
	  &lt;li class="nsmall"&gt;dispute in the workplace&lt;/li&gt;
	  &lt;li class="nsmall"&gt;employer breach of contract&lt;/li&gt;
	  &lt;li class="nsmall"&gt;harassment&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tbsmall"&gt;Accepted an Offer of Work&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="nsmall"&gt;quit to go to a new job&lt;/li&gt;
	  &lt;li class="nsmall"&gt;quit while maintaining other employment&lt;/li&gt;
	&lt;/ul&gt;  
&lt;/ul&gt;  </caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emr_quit_circumstance" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Which circumstance best describes your reason for quitting?&lt;/p&gt;
</caption>
        <list>
          <option text="Personal Reasons" default-visibility="true">Personal Reasons</option>
          <option text="Work-Related" default-visibility="true">Work-Related</option>
          <option text="Accepted an Offer of Work" default-visibility="true">Accepted an Offer of Work</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s71@Interviews_Screens_xint" title="Employer Address Details for %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emr_street_address" input-type="default">
        <default default="702 Capital Ave" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp Street Address:&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_city" input-type="default">
        <default default="Frankfort" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_state" input-type="Dropdown">
        <default default="KY" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp State:&lt;/p&gt;</caption>
        <list>
          <option text="Alabama" default-visibility="true">AL</option>
          <option text="Alaska" default-visibility="true">AK</option>
          <option text="Arizona" default-visibility="true">AZ</option>
          <option text="Arkansas" default-visibility="true">AR</option>
          <option text="California" default-visibility="true">CA</option>
          <option text="Colorado" default-visibility="true">CO</option>
          <option text="Connecticut" default-visibility="true">CT</option>
          <option text="Delaware" default-visibility="true">DE</option>
          <option text="District Of Columbia" default-visibility="true">DC</option>
          <option text="Florida" default-visibility="true">FL</option>
          <option text="Georgia" default-visibility="true">GA</option>
          <option text="Hawaii" default-visibility="true">HI</option>
          <option text="Idaho" default-visibility="true">ID</option>
          <option text="Illinois" default-visibility="true">IL</option>
          <option text="Indiana" default-visibility="true">IN</option>
          <option text="Iowa" default-visibility="true">IA</option>
          <option text="Kansas" default-visibility="true">KS</option>
          <option text="Kentucky" default-visibility="true">KY</option>
          <option text="Louisiana" default-visibility="true">LA</option>
          <option text="Maine" default-visibility="true">ME</option>
          <option text="Maryland" default-visibility="true">MD</option>
          <option text="Massachusetts" default-visibility="true">MA</option>
          <option text="Michigan" default-visibility="true">MI</option>
          <option text="Minnesota" default-visibility="true">MN</option>
          <option text="Mississippi" default-visibility="true">MS</option>
          <option text="Missouri" default-visibility="true">MO</option>
          <option text="Montana" default-visibility="true">MT</option>
          <option text="Nebraska" default-visibility="true">NE</option>
          <option text="Nevada" default-visibility="true">NV</option>
          <option text="New Hampshire" default-visibility="true">NH</option>
          <option text="New Jersey" default-visibility="true">NJ</option>
          <option text="New Mexico" default-visibility="true">NM</option>
          <option text="New York" default-visibility="true">NY</option>
          <option text="North Carolina" default-visibility="true">NC</option>
          <option text="North Dakota" default-visibility="true">ND</option>
          <option text="Ohio" default-visibility="true">OH</option>
          <option text="Oklahoma" default-visibility="true">OK</option>
          <option text="Oregon" default-visibility="true">OR</option>
          <option text="Pennsylvania" default-visibility="true">PA</option>
          <option text="Rhode Island" default-visibility="true">RI</option>
          <option text="South Carolina" default-visibility="true">SC</option>
          <option text="South Dakota" default-visibility="true">SD</option>
          <option text="Tennessee" default-visibility="true">TN</option>
          <option text="Texas" default-visibility="true">TX</option>
          <option text="Utah" default-visibility="true">UT</option>
          <option text="Vermont" default-visibility="true">VT</option>
          <option text="Virginia" default-visibility="true">VA</option>
          <option text="Washington" default-visibility="true">WA</option>
          <option text="West Virginia" default-visibility="true">WV</option>
          <option text="Wisconsin" default-visibility="true">WI</option>
          <option text="Wyoming" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="emr_zip" input-type="default">
        <default default="40601" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp Zip Code&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="emr_phone" input-type="default">
        <default default="5551212" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp Phone Number:&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_worked_in_state" input-type="Dropdown">
        <default default="KY" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp The State in which you worked&lt;/p&gt;</caption>
        <list>
          <option text="Alabama" default-visibility="true">AL</option>
          <option text="Alaska" default-visibility="true">AK</option>
          <option text="Arizona" default-visibility="true">AZ</option>
          <option text="Arkansas" default-visibility="true">AR</option>
          <option text="California" default-visibility="true">CA</option>
          <option text="Colorado" default-visibility="true">CO</option>
          <option text="Connecticut" default-visibility="true">CT</option>
          <option text="Delaware" default-visibility="true">DE</option>
          <option text="District Of Columbia" default-visibility="true">DC</option>
          <option text="Florida" default-visibility="true">FL</option>
          <option text="Georgia" default-visibility="true">GA</option>
          <option text="Hawaii" default-visibility="true">HI</option>
          <option text="Idaho" default-visibility="true">ID</option>
          <option text="Illinois" default-visibility="true">IL</option>
          <option text="Indiana" default-visibility="true">IN</option>
          <option text="Iowa" default-visibility="true">IA</option>
          <option text="Kansas" default-visibility="true">KS</option>
          <option text="Kentucky" default-visibility="true">KY</option>
          <option text="Louisiana" default-visibility="true">LA</option>
          <option text="Maine" default-visibility="true">ME</option>
          <option text="Maryland" default-visibility="true">MD</option>
          <option text="Massachusetts" default-visibility="true">MA</option>
          <option text="Michigan" default-visibility="true">MI</option>
          <option text="Minnesota" default-visibility="true">MN</option>
          <option text="Mississippi" default-visibility="true">MS</option>
          <option text="Missouri" default-visibility="true">MO</option>
          <option text="Montana" default-visibility="true">MT</option>
          <option text="Nebraska" default-visibility="true">NE</option>
          <option text="Nevada" default-visibility="true">NV</option>
          <option text="New Hampshire" default-visibility="true">NH</option>
          <option text="New Jersey" default-visibility="true">NJ</option>
          <option text="New Mexico" default-visibility="true">NM</option>
          <option text="New York" default-visibility="true">NY</option>
          <option text="North Carolina" default-visibility="true">NC</option>
          <option text="North Dakota" default-visibility="true">ND</option>
          <option text="Ohio" default-visibility="true">OH</option>
          <option text="Oklahoma" default-visibility="true">OK</option>
          <option text="Oregon" default-visibility="true">OR</option>
          <option text="Pennsylvania" default-visibility="true">PA</option>
          <option text="Rhode Island" default-visibility="true">RI</option>
          <option text="South Carolina" default-visibility="true">SC</option>
          <option text="South Dakota" default-visibility="true">SD</option>
          <option text="Tennessee" default-visibility="true">TN</option>
          <option text="Texas" default-visibility="true">TX</option>
          <option text="Utah" default-visibility="true">UT</option>
          <option text="Vermont" default-visibility="true">VT</option>
          <option text="Virginia" default-visibility="true">VA</option>
          <option text="Washington" default-visibility="true">WA</option>
          <option text="West Virginia" default-visibility="true">WV</option>
          <option text="Wisconsin" default-visibility="true">WI</option>
          <option text="Wyoming" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s72@Interviews_Screens_xint" title="Pension Income for Employer %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emr_contributed_pension" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you contribute to this pension?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_paid_under_railroad" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is this pension paid under the Social Security Act or the Railroad Retirement Act of 1974?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_receiving_monthly_retirement" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you receiving monthly payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s73@Interviews_Screens_xint" title="13 A - monthly distribution for %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Currency" attr="emr_gross_pension_amt" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the gross amount received monthly?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emr_date_first_pension_pymt" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did you receive the first payment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s75@Interviews_Screens_xint" title="Employer Details for %g01_fpr_employer_instance_id% " entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emr_wage_type" input-type="Dropdown">
        <default default="Hourly" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Wage Type?&lt;/p&gt;</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Hourly" default-visibility="true">Hourly</option>
          <option text="Salary" default-visibility="true">Salary</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_employer_type" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Employment Type?&lt;/p&gt;</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Full-Time" default-visibility="true">Full-Time</option>
          <option text="Part-Time" default-visibility="true">Part-Time</option>
          <option text="As-Needed" default-visibility="true">As-Needed</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_job_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Job Title?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_job_duties" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Job Duties?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Currency" attr="emr_rate_of_pay" input-type="default">
        <default default="10" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Rate of Pay?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_wage_frequency" input-type="Radiobutton">
        <default default="Per/hour" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;The rate of pay is...&lt;/p&gt;</caption>
        <list>
          <option text="Per/hour" default-visibility="true">Per/hour</option>
          <option text="Per/year" default-visibility="true">Per/year</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;For this period of employment, were you&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emr_business_owner" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp A business owner/officer of a corporation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_school_worker" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp An educational employee?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_sports_professional" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp An athletic professional?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_riverboat_worker" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp A water transportation employee?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s74@Interviews_Screens_xint" title="13 B - lump sum distribution fror %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Currency" attr="emr_retirement_lump_sum" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was total lump sum amount?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emr_lump_sum_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did you receive the payment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_monthly_option_available" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you have the option to receive monthly payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Currency" attr="emp_lump_monthly_option_amt" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Yes, what would have been the gross amount received monthly?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s76@Interviews_Screens_xint" title="Athletic Professional Information  for %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emr_paid_athletic" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you paid to participate in athletic events?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_athletic_paid_to_train" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you paid to train or prepare to participate in athletic events?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_athletic_between" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you currently in between seasons?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_athletic_reasonable_assure" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you been given reasonable assurance that you will return in the upcoming season?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_athletic_contract" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you under contract for the upcoming season?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s77@Interviews_Screens_xint" title="Athletic Professional Detail Information for %g01_fpr_employer_instance_id% %fpr_emr_vis_date_range%" entity="fpr_employer">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;l</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emr_athletic_orginization" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;With what organization to you intend to participate for the upcoming season?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_athletic_person_reasonable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name and title of the individual who provided you reasonable assurance of your return?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emr_athletic_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the last season end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emr_athletic_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When does the upcoming season begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s78@Interviews_Screens_xint" title="Quit Details (Personal) for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated you quit this employment for personal reasons.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emr_personal_quit_circumstance" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason for leaving&lt;/p&gt;
</caption>
        <list>
          <option text="Attend school or a training program" default-visibility="true">Attend school or a training program</option>
          <option text="To move or relocate" default-visibility="true">To move or relocate</option>
          <option text="Responsibility for the care for family member(s) (i.e. dependent care)" default-visibility="true">Responsibility for the care for family member(s) (i.e. dependent care)</option>
          <option text="Lack of transportation" default-visibility="true">Lack of transportation</option>
          <option text="Domestic circumstances" default-visibility="true">Domestic circumstances</option>
          <option text="Retirement (non-mandatory retirement)" default-visibility="true">Retirement (non-mandatory retirement)</option>
          <option text="Medical condition or injury (not caused by the work)" default-visibility="true">Medical condition or injury (not caused by the work)</option>
          <option text="Accompany your spouse when he/she was reassigned by the military" default-visibility="true">Accompany your spouse when he/she was reassigned by the military</option>
          <option text="Other" default-visibility="true">Other</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emr_other_quit_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Other, please explain&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_gt_100_lt_100" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave employment, which was one hundred (100) road miles or more from your home, to accept work that is less than one hundred (100) road miles?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_left_nmre_concurrent_mre" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave employment with recent suitable work, that was concurrent with your most recent work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_given_bona_fide_offer" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you given another bona fide offer of work, during your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_accepted_offer" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you accept the other offer, during your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_thought_work_would_go_on" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you have a reasonable expectation the employment would continue?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s79@Interviews_Screens_xint" title="Military Spouse Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <input-control type="Statement" attr="emt_left_with_military_spouse" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was your military spouse re-assigned to a state other than Kentucky?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emt_reassigned_state" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What State?&lt;/p&gt;</caption>
        <list>
          <option text="Alabama" default-visibility="true">AL</option>
          <option text="Alaska" default-visibility="true">AK</option>
          <option text="Arizona" default-visibility="true">AZ</option>
          <option text="Arkansas" default-visibility="true">AR</option>
          <option text="California" default-visibility="true">CA</option>
          <option text="Colorado" default-visibility="true">CO</option>
          <option text="Connecticut" default-visibility="true">CT</option>
          <option text="Delaware" default-visibility="true">DE</option>
          <option text="District Of Columbia" default-visibility="true">DC</option>
          <option text="Florida" default-visibility="true">FL</option>
          <option text="Georgia" default-visibility="true">GA</option>
          <option text="Hawaii" default-visibility="true">HI</option>
          <option text="Idaho" default-visibility="true">ID</option>
          <option text="Illinois" default-visibility="true">IL</option>
          <option text="Indiana" default-visibility="true">IN</option>
          <option text="Iowa" default-visibility="true">IA</option>
          <option text="Kansas" default-visibility="true">KS</option>
          <option text="Kentucky" default-visibility="true">KY</option>
          <option text="Louisiana" default-visibility="true">LA</option>
          <option text="Maine" default-visibility="true">ME</option>
          <option text="Maryland" default-visibility="true">MD</option>
          <option text="Massachusetts" default-visibility="true">MA</option>
          <option text="Michigan" default-visibility="true">MI</option>
          <option text="Minnesota" default-visibility="true">MN</option>
          <option text="Mississippi" default-visibility="true">MS</option>
          <option text="Missouri" default-visibility="true">MO</option>
          <option text="Montana" default-visibility="true">MT</option>
          <option text="Nebraska" default-visibility="true">NE</option>
          <option text="Nevada" default-visibility="true">NV</option>
          <option text="New Hampshire" default-visibility="true">NH</option>
          <option text="New Jersey" default-visibility="true">NJ</option>
          <option text="New Mexico" default-visibility="true">NM</option>
          <option text="New York" default-visibility="true">NY</option>
          <option text="North Carolina" default-visibility="true">NC</option>
          <option text="North Dakota" default-visibility="true">ND</option>
          <option text="Ohio" default-visibility="true">OH</option>
          <option text="Oklahoma" default-visibility="true">OK</option>
          <option text="Oregon" default-visibility="true">OR</option>
          <option text="Pennsylvania" default-visibility="true">PA</option>
          <option text="Rhode Island" default-visibility="true">RI</option>
          <option text="South Carolina" default-visibility="true">SC</option>
          <option text="South Dakota" default-visibility="true">SD</option>
          <option text="Tennessee" default-visibility="true">TN</option>
          <option text="Texas" default-visibility="true">TX</option>
          <option text="Utah" default-visibility="true">UT</option>
          <option text="Vermont" default-visibility="true">VT</option>
          <option text="Virginia" default-visibility="true">VA</option>
          <option text="Washington" default-visibility="true">WA</option>
          <option text="West Virginia" default-visibility="true">WV</option>
          <option text="Wisconsin" default-visibility="true">WI</option>
          <option text="Wyoming" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emt_next_duty" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date are you to report to the next duty station?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pr"&gt;Please provide the Division with a copy of your spouse’s PCS Orders via mail or fax.&lt;br&gt; Be sure to include your name and social security number on the document.&lt;br&gt; Failure to provide this information will may result in a delay in processing your claim. &lt;br&gt; The address and fax number will provided at the conclusion of this application.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s80@Interviews_Screens_xint" title="Work Alternatives Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <input-control type="Statement" attr="emt_concerns_expressed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you express your concerns regarding your reason for quitting with the employer prior to leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;if Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emt_concerns_expressed_with" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp  What was the name of the person with whom you discussed your concerns?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emt_concerns_expressed_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emt_concerns_expressed_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you discuss your concerns?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_action_employer_took" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What specific actions did the employer take to address or correct the issue(s)?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_notice_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you give notice prior to leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;if Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_notice_given_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp To whom did you give notice?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_notice_given_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_notice_given_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you give notice?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_allowed_until_notice_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Did the employer allow you to work until the end of your notice?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pursued_alt_prior" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you pursue alternatives to quitting before leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;if Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_pursued_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe all alternatives that were pursued before leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_not_pursued_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Why were alternatives not pursued?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s81@Interviews_Screens_xint" title="Quit Details (Work Related) for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated you quit this employment for work-related reasons&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_work_related_circumstance" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason for leaving&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Disciplinary action imposed by the employer" default-visibility="true">Disciplinary action imposed by the employer</option>
          <option text="Dispute in the workplace" default-visibility="true">Dispute in the workplace</option>
          <option text="Drug or alcohol test required by the employer" default-visibility="true">Drug or alcohol test required by the employer</option>
          <option text="Equipment problems" default-visibility="true">Equipment problems</option>
          <option text="Work-related injury or health condition" default-visibility="true">Work-related injury or health condition</option>
          <option text="Harassment" default-visibility="true">Harassment</option>
          <option text="Lack of training or experience" default-visibility="true">Lack of training or experience</option>
          <option text="Religious beliefs" default-visibility="true">Religious beliefs</option>
          <option text="Pay practices or rate of pay" default-visibility="true">Pay practices or rate of pay</option>
          <option text="Distance to work" default-visibility="true">Distance to work</option>
          <option text="Work hours required by the employer" default-visibility="true">Work hours required by the employer</option>
          <option text="Reduction in workforce initiative by the employer (i.e. accepting a buyout)" default-visibility="true">Reduction in workforce initiative by the employer (i.e. accepting a buyout)</option>
          <option text="Failed to uphold your conditions of hire (i.e. failing to maintain a certification)" default-visibility="true">Failed to uphold your conditions of hire (i.e. failing to maintain a certification)</option>
          <option text="Anticipation of a layoff or discharge/after being given a date of discharge or layoff" default-visibility="true">Anticipation of a layoff or discharge/after being given a date of discharge or layoff</option>
          <option text="Failure to return from a temporary layoff" default-visibility="true">Failure to return from a temporary layoff</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_other_work_circumstance" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Other, please explain&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s82@Interviews_Screens_xint" title="Disciplinary Action Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_discipline_imposed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What disciplinary action did the employer impose that caused you to leave the employment?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_discipline_imposed_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was this disciplinary action imposed?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_discipline_imposed_with_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this disciplinary action administered in accordance with the employee handbook or employer policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_dicipline_reasonable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the disciplinary action reasonable for the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_discipline_imposed_warned" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Had you previously received warnings or disciplinary action during this employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s83@Interviews_Screens_xint" title="Dispute in the Workplace Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dispute_circumstances" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What circumstances surrounding the dispute led to you leaving the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_dispute_workplace_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the dispute in the workplace impact your employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_dispute_unsuitable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the dispute cause the employment to become unsuitable?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_dispute_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dispute_with_person" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;With whom did the dispute take place?&lt;/p&gt;</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Management" default-visibility="true">Management</option>
          <option text="Supervisor" default-visibility="true">Supervisor</option>
          <option text="Co-Worker" default-visibility="true">Co-Worker</option>
          <option text="Customer" default-visibility="true">Customer</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other&lt;p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dispute_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Please describe&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s84@Interviews_Screens_xint" title="Drug or Alcohol Test Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_drug_test_required" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does this employer require a (drug, alcohol) test for the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_drug_policy_reasonable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this employer's (drug, alcohol) policy reasonable for the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_reason_no_drugtest" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Why did you leave the employment rather than submit to (or complete) the employer’s drug and/or alcohol test?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_proposed_drugtest_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was the test to be conducted?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drugtest_reason" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the reason for the drug and/or alcohol test?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Random" default-visibility="true">Random</option>
          <option text="Post accident" default-visibility="true">Post accident</option>
          <option text="Pre-employment" default-visibility="true">Pre-employment</option>
          <option text="Reasonable suspicion" default-visibility="true">Reasonable suspicion</option>
          <option text="Follow-up testing" default-visibility="true">Follow-up testing</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drugtest_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Please describe&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s85@Interviews_Screens_xint" title="Equipment Problems Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_equipment_problem_leave" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final equipment problem(s) that caused you to leave the employment.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_equipment_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the equipment problem(s) impact your employment?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_final_date_equipment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_equipnent_onetime" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the problem(s) with the equipment a one-time incident?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_equipment_standards_repaired" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the equipment serviced/repaired in accordance with industry standards?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_equipmenmt_trained" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you trained or authorized to use the equipment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_equipment_gives_good_cause" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the equipment problems give you good cause for quitting?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_equipment_employer_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the employer made aware of the equipment problem(s) prior to you quitting the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_equipment_awareness_detail" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp How was the employer made aware?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s86@Interviews_Screens_xint" title="Work-Related Injury or Health Condition Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_medical_injury_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the injury occur or when did the medical condition begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_medical_quit_condition" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What type of injury or medical condition caused you to leave the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_employment_caused_injury" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this injury or medical condition caused by the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_medical_documents" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation to show that the condition was caused by the work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_work_comp_approved" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you approved for Workers Compensation due to this injury or medical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_leave_exhausted" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you exhaust all available leave time (including short term disability, FMLA, etc.) prior to leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_doctor_restriction" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has your doctor provided you with any restrictions for returning to this position?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_employer_accomodate_doctor" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Was the employer able to accommodate these restrictions?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s87@Interviews_Screens_xint" title="Lack of Training/Experience Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_training_unsuitable" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your lack of training or experience negatively impact your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_training_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Please describe.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_prior_training_experience" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you have prior experience doing this type of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_employer_training" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer provide you with training in order to perform your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_training_warnings" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive any type of warning regarding your work performance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s88@Interviews_Screens_xint" title="Harassment Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_harrassment_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe final incident of harassment that caused you to leave the employment&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_harrassment_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the incident(s) of harassment impact your employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_harrassment_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_harrassment_repeated" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were there repeated occurrences of this harassment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_harrassment_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the employer have a harassment policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_harrassment_reporting" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you follow the proper procedures to report the alleged harassment (such as filing a formal complaint, 
addressing your concerns with the employer)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_harassment_at_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the harassment during your employment make the work unsuitable?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s89@Interviews_Screens_xint" title="Religious Beliefs Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_religious_conflict" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the conditions of this employment conflict with your religious beliefs?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_religious_event" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that caused you to leave the employment&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_religious_event" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How, specifically, did this incident conflict with your religious beliefs?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_religious_event_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_religious_event_is_recurring" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this conflict with your religious beliefs a recurring issue?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_religious_event_conflict" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of any possible conflict between your job duties and your religious beliefs 
prior to the start of the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_religious_event_changed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the conditions of work change after you accepted the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_religious_event_change_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe these changes.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s90@Interviews_Screens_xint" title="Rate of Pay/Pay Practices Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_pay_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_pay_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that caused you to leave the employment.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pay_change" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the rate of pay change from the rate agreed upon at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_pay_frequency" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer’s pay practice (e.g. pay dates, etc.) change from what was agreed upon at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s91@Interviews_Screens_xint" title="Rate of Pay Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class= "pb"&gt;You have indicated that the rate of pay changed from the rate agreed upon at the time of hire.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pay_rate_change_universal" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the change applied to all employees?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_pay_rate_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the change&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s93@Interviews_Screens_xint" title="Distance to Work Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_distance_changed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the distance to work increase since your date of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_work_distance_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What specific reason regarding the distance to work caused you to leave the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s94@Interviews_Screens_xint" title="Mileage Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated that the distance to work increased since your date of hire.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_distance_change_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the change occur?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="scr_miles_increased" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;By how many miles has the distance increased?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_employer_changed_the_distance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the change in the distance to work initiated the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s95@Interviews_Screens_xint" title="Work Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_work_hour_change_quit" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final event that took place regarding your work hours which caused you to leave the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_work_hour_change_hire" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the working hours (shift, number of hours, etc.) change since your date of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_work_hour_change_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Please explain&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_work_hours_dicipline" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the change in working hours imposed as a form of disciplinary action?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_work_hours_change_temp" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were these working hours implemented for a limited period of time?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_work_hour_change_duration" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp How long were these changes expected to last?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s96@Interviews_Screens_xint" title="Reduction in Workforce Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emr_substantial_reduction" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer initiate a reduction in workforce/buyout?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emr_took_buyout" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer offer you an incentive package/buyout for voluntarily accepting the reduction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_workforce_could_remain" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Could you have continued work if you had not accepted the reduction of workforce package/buyout?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s97@Interviews_Screens_xint" title="Conditions of Hire Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_condition_of_hire_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What condition of your employment contract did you fail to meet? (e.g. failure to pass a test, failure to earn or maintain a certification other than a driver’s license)?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_condition_of_hire_failure" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Why did you fail to meet this condition of employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_condition_settled_at_hire" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of your responsibility to meet this condition or maintain a specific certification at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_responsible_condition" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you responsible to meet this condition as a requirement for continued employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_failed_to_meet_condition" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive any warning(s) regarding your failure to meet this condition of employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s98@Interviews_Screens_xint" title="Anticipation of  Layoff Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_anticipation_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident (or reason) that caused you to leave the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_anticipation_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer give you specific date that you would be laid off or discharged?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_anticipation_date_given" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What was the specific date of lay off or discharge given by the employer?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_anticipation_explanation_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer give you an explanation for the pending discharge or layoff?&lt;/p&gt;	</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_anticipation_work_ongoing" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If you had not left the employment, would on going work have been available to you?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s103@Interviews_Screens_xint" title="Failure to Return Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_layoff_return_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the reason that you did not return from the temporary lay off.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_return_date_known" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you know the date you were to return from the temporary lay off?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_layoff_return_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the date you were to return?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_layoff_return_aware_by" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the employer make you aware of the recall date?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_layoff_return_target_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the employer notify you of recall date?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s105@Interviews_Screens_xint" title="Other Work Related Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_other_work_related_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the working condition or final incident that caused you to leave the employment.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_other_work_related_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the final incident impact your ability to perform the work?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_other_work_related_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the final incident occur?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_other_work_related_conditions" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the conditions of work or contract of hire change since your date of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_other_work_related_management" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the company change ownership or management since your hire date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s114@Interviews_Screens_xint" title="Quit Details (Accepted Offer)  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated you quit this employment because you accepted an offer of work.&lt;p&gt;&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_reason_for_accepting" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason for leaving&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="To search for new employment" default-visibility="true">To search for new employment</option>
          <option text="To accept a new offer of employment" default-visibility="true">To accept a new offer of employment</option>
          <option text="To remain employed with another employer" default-visibility="true">To remain employed with another employer</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s115@Interviews_Screens_xint" title="Prospect of Work Details  for %fpr_emt_visible_name%" entity="fpr_employment">
      <input-control type="Statement" attr="emt_left_for_temporary_part_2" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment to accept temporary or less than full-time employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_left_for_miles" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave this employment which is one hundred (100) road miles or more from your home 
to accept work that is less than one hundred (100) road miles?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_was_continuing" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you accept an offer of new employment prior to leaving this employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s116@Interviews_Screens_xint" title="Prospect of Work Details Accepted Offer  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_offer_business" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the business that extended the new job offer?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_offer_person" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the name of the person who offered the job?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_offer_address" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the address of the business?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="scr_offer_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the phone number of the business?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_offer_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was the new job offered?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_offer_begin_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was the new job to begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_offer_work_type" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the schedule of the new job?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Full-time Permanent" default-visibility="true">Full-time Permanent</option>
          <option text="Full-time Temporary" default-visibility="true">Full-time Temporary</option>
          <option text="Part-time Permanent" default-visibility="true">Part-time Permanent</option>
          <option text="Part-time Temporary" default-visibility="true">Part-time Temporary</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_offer_began" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you begin working at the new job?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_offer_why_not" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Why have you not started yet?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s118@Interviews_Screens_xint" title="Suspended" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../../images/construction.jpg" class="center" /&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s120@Interviews_Screens_xint" title="Laid Off Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_laid_off_from_employment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you told by your employer that you were laid off?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s121@Interviews_Screens_xint" title="Labor Dispute Details  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Currency" attr="scr_dispute_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the labor dispute begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_dispute_start_status" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was your employment status on the date the labor dispute began?&lt;/p&gt;</caption>
        <list>
          <option text="On leave of absence" default-visibility="true">On leave of absence</option>
          <option text="On lay off" default-visibility="true">On lay off</option>
          <option text="On Suspension" default-visibility="true">On Suspension</option>
          <option text="Working" default-visibility="true">Working</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_bona_fide_labor_dispute" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is the labor dispute active and in progress?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s123@Interviews_Screens_xint" title="Discharge  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_discuntinued_reason" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason the employer gave you for discharging (terminating) your employment&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Unsatisfactory Attendance/Tardiness" default-visibility="true">Unsatisfactory Attendance/Tardiness</option>
          <option text="Violation of Rule or Policy" default-visibility="true">Violation of Rule or Policy</option>
          <option text="Unsatisfactory Work or Performance" default-visibility="true">Unsatisfactory Work or Performance</option>
          <option text="Inappropriate Conduct, Behavior, or Attitude" default-visibility="true">Inappropriate Conduct, Behavior, or Attitude</option>
          <option text="Dishonesty" default-visibility="true">Dishonesty</option>
          <option text="Falsification of Application for Employment" default-visibility="true">Falsification of Application for Employment</option>
          <option text="Refusal to Obey an Instruction" default-visibility="true">Refusal to Obey an Instruction</option>
          <option text="Loss of Drivers' License" default-visibility="true">Loss of Drivers' License</option>
          <option text="Uninsurable Driver" default-visibility="true">Uninsurable Driver</option>
          <option text="Drugs and/or Alcohol" default-visibility="true">Drugs and/or Alcohol</option>
          <option text="Incarceration" default-visibility="true">Incarceration</option>
          <option text="Damaging Employer Property" default-visibility="true">Damaging Employer Property</option>
          <option text="Union Activity" default-visibility="true">Union Activity</option>
          <option text="Mandatory Retirement" default-visibility="true">Mandatory Retirement</option>
          <option text="Employer Requested Resignation" default-visibility="true">Employer Requested Resignation</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_discharge_control" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Other, please explain&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_discharge_person_name" input-type="default">
        <default default="Charlie Fotzapple" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the person who discharged you?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_former_supervisor_name" input-type="default">
        <default default="Charlie Fotzapple" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of your former supervisor?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_discharge_date_memory" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know the date you were discharged?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_discharge_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What is the date you were discharged?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s128@Interviews_Screens_xint" title="Discharge Details  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_discharge_aware" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware that your job was in jeopardy prior to the discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_discharge_handbook" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you provided an employee handbook or copy of the employer’s policies (including a website or posted rules)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_discharge_duties" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of your duties and expectations during this employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_discharge_progressively" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the employer have a progressive disciplinary policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_follow_prog_att_policy" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Did the employer follow the progressive disciplinary policy, concerning your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s130@Interviews_Screens_xint" title="Unsatisfactory Attendance/Tardiness Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_attendance_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer have an attendance policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_attendance_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Were you aware of this policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_needed_tardy_excuse" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp  &amp;nbsp  &amp;nbsp Were you required to provide supporting documentation for your absence/tardiness?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_method_tardy" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp How were you required to report your absences/tardiness?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_has_excuse_for_attendance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you have good cause for the majority of attendance incidents during the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_tardy_verbal" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you given any warning (verbal or written) regarding attendance/tardiness prior to your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_tardy_person_name" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What is the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_tardy_person_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What is the title of the person?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_tardy_given_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you receive the warning?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s131@Interviews_Screens_xint" title="Violation of Rule/Policy Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_policy_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe which rule/policy the employer alleges that you violated (whether or not you agree).&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rule_was_violated" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you violate the rule/policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rule_awareness" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of the employer’s rule/policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rules_enforced_fairly" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the policy uniformly enforced?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If No:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_not_followed_fairly" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Please provide examples&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rule_warning_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you given any warning (verbal or written) regarding rule/policy violation prior to the discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Number" attr="scr_rule_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What is the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rule_person_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What is the title of the person?&lt;/p&gt;
	</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rule_warning_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp On what date did you receive the warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rule_reason_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide an explanation to the employer as to why the policy was violated?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rule_expanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was your explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If No:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_no_reason_given" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Why not?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s134@Interviews_Screens_xint" title="Effort to Correct Behavior Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_bad_gone_good" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pb"&gt;Please describe what action you took to correct your behavior or maintain your employment&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s137@Interviews_Screens_xint" title="Unsatisfactory Work or Performance Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that led to your discharge.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_aware_of_responsibility" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you made aware of your job responsibilities?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_received_training" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive training or instruction on how to perform your duties?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_work_within_ability" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you previously done this type of work/duties?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_unsatisfactory_performance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;During your employment, had you received positive evaluations, positive feedback, 
or commendations regarding your performance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_was_warned_before" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you given any warning (verbal or written) regarding your performance prior to the discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp  What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_poor_work_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;  &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_poor_work_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you receive the warning?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_poor_work_changed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Had your job duties or customary workload changed since your date of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_change_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe the change&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_poor_work_excuse" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide the employer with an explanation for your unsatisfactory performance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_excuse_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was your explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_no_excuse" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Why not?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s138@Interviews_Screens_xint" title="Inappropriate Conduct or Behavior Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_poor_work_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident or behavior that led to your discharge.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_conduct_danger" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your actions/behavior/conduct endanger yourself or others?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_conduct_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware that this behavior was inappropriate or unacceptable?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_conduct_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive warning (verbal or written) regarding your conduct/behavior prior to your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_conduct_name" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_conduct_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_conduct_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp On what date did you receive the warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_conduct_explanation_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide the employer with an explanation for your behavior or conduct?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_conduct_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was your explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_conduct_no_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Why not?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s139@Interviews_Screens_xint" title="Dishonesty Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dishonest_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe in what way the employer alleges you were dishonest (whether or not you agree).&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_dishonest_final_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that led to your discharge?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_dishonest_agree" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you dishonest as the employer alleged?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_conduct_explanation_given" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide the employer with an explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dishonest_honest_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was your explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_dishonest_explanation_not_given" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Why not?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s140@Interviews_Screens_xint" title="Falsification of Application Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_false_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe in what way the employer alleges that you falsified your 
employment application (whether or not you agree)?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_falsified_application" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you falsify an application for the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_false_provided" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide the employer with an explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_false_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp What was your explanation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_false_no_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Why not?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s141@Interviews_Screens_xint" title="Insubordination Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_obey_instruction_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the instruction the employer alleges that you refused to obey (whether or not you agree).&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_obey_person" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of person who gave you this instruction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="the_obey_title" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the title of person who gave you this instruction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_refused_an_instruction" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you refuse to obey the instruction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_obey_why" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Why?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_obey_previously" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Had you been given the same instruction previously?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_obey_complied" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Had you complied with this instruction prior to the final incident?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_obey_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive warning (verbal or written) regarding refusal of instruction prior to your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_obey_warning_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_obey_warning_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_obey_warning_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp On what date did you receive the warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s142@Interviews_Screens_xint" title="Loss of Driver’s License Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_driver_loss_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident which led to the loss of driver’s license.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_required_motor_operation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your job duties require you to operate a motor vehicle?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_driver_loss_law" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you lose your driver’s license due to violations of motor vehicle law?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_driver_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of your responsibility to maintain a driver’s license at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_driver_must_maintain" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you responsible to maintain a driver’s license as a requirement for continued employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s143@Interviews_Screens_xint" title="Uninsurable Driver Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="src_insure_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident which led you to become an uninsurable driver.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_required_insurance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your job duties require you to operate a motor vehicle or to be insured as a driver?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_insure_law" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you become uninsurable due to violations of motor vehicle law?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_insure_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were aware of your responsibility to remain insurable as a requirement for employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s144@Interviews_Screens_xint" title="Drug/Alcohol Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb&gt;You have indicated the primary you were discharged from this employment is related to drugs and/or alcohol.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drug_flow_control" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the reason for termination&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Refusal to submit to a drug/alcohol test" default-visibility="true">Refusal to submit to a drug/alcohol test</option>
          <option text="Consuming drugs and/or alcohol on the employer’s property" default-visibility="true">Consuming drugs and/or alcohol on the employer’s property</option>
          <option text="Reporting to work under the influence of drugs and/or alcohol" default-visibility="true">Reporting to work under the influence of drugs and/or alcohol</option>
          <option text="Positive drug and/or alcohol test" default-visibility="true">Positive drug and/or alcohol test</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drug_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that led to your discharge from employment&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_drug_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the date of the final incident?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_drug_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive warning (verbal or written) regarding violations of employer’s alcohol /drug policy prior to your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drug_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_drug_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_drug_warning_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp On what date did you receive the warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s145@Interviews_Screens_xint" title="Refusal to Submit to Testing Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_alcohol_test_reason" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the reason for the drug and/or alcohol test?&lt;/p&gt;

</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Random" default-visibility="true">Random</option>
          <option text="Post accident" default-visibility="true">Post accident</option>
          <option text="Pre-employment" default-visibility="true">Pre-employment</option>
          <option text="Reasonable suspicion" default-visibility="true">Reasonable suspicion</option>
          <option text="Follow-up testing" default-visibility="true">Follow-up testing</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_alcohol_refusal_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your reason for refusing to submit to (or complete) the employer’s drug and/or alcohol test?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_alcohol_test_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was the test to be conducted?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_alcohol_test_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the employer have a policy concerning drug and/or alcohol testing?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="reported_under_the_influence" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you report to work under the influence of drugs and/or alcohol?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_alcohol_type" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What substance(s)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s153@Interviews_Screens_xint" title="Consumption or Reporting Under Influence Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_consumed_drugs_on_site" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you consume drugs and/or alcohol on the employer’s property?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_onsite_substance" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What substance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_consuming_during_work_hours" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you consume drugs and/or alcohol during working hours?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_onsite_work_hours_substance" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What substance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="reported_under_the_influence" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you report to work under the influence of drugs and/or alcohol?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_onsite_report_substance" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What substance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_onsite_final_test" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you submit to a drug and/or alcohol test on the day of the final incident as required by the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp What type of test? (check the ones that apply)</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_onsite_final_alcohol" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp  &amp;nbsp  &amp;nbsp Alcohol test&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_onsite_final_drug" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp   &amp;nbsp &amp;nbsp Drug test&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If No:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_onsite_refusal_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp Why did you refuse?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s154@Interviews_Screens_xint" title="Positive Drug Test Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_positive_test" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;For what substance did you test positive?&lt;/p&gt;
</caption>
        <list>
          <option text="Drugs" default-visibility="true">Drugs</option>
          <option text="Alcohol" default-visibility="true">Alcohol</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_tested_positive_prescription" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you provide the employer or testing facility with your current valid prescription 
for the substance for which you tested positive?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_tested_positive_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason for the positive test?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s155@Interviews_Screens_xint" title="Alcohol Test Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_alcohol_administered" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How was the test conducted?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Blood" default-visibility="true">Blood</option>
          <option text="Urine" default-visibility="true">Urine</option>
          <option text="Breath" default-visibility="true">Breath</option>
          <option text="Saliva" default-visibility="true">Saliva</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_alcohol_administered_result" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the result of the alcohol test?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s156@Interviews_Screens_xint" title="Drug Test Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_drug_administered_result" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the result of the drug test?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Positive" default-visibility="true">Positive</option>
          <option text="Negative" default-visibility="true">Negative</option>
          <option text="Inconclusive" default-visibility="true">Inconclusive</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s158@Interviews_Screens_xint" title="Incarceration Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_jail_caused_discharge" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you discharge by the employer for being incarcerated (in jail)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_jail_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the beginning date of your incarceration?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_jail_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the end date of your incarceration?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_jail_during_employment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you incarcerated following a conviction (misdemeanor or felony)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_jail_for_five" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the incarceration result in you missing at least five (5) days work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_jail_reported" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you properly report to your employer each day that you missed work due to incarceration?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s159@Interviews_Screens_xint" title="Damaging Employer Property Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_damage_action_caused" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you damage the employer’s property?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_gross_negligence" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the property damage a result of your failure to follow a policy or procedure?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_damage_items" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What item(s) of property does the employer allege that you damaged?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_damage_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the incident that led to the employer’s property becoming damaged&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_damage_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive warning (verbal or written) regarding negligence or property damage prior to your discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pb"&gt;If Yes:&lt;p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_damage_warning_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_damage_warning_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_damage_warning_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;  &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you receive the warning?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s160@Interviews_Screens_xint" title="Union Activity Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_union_activity_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident which led to your termination&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_union_discharge" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you discharged due to your participation in a labor union?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_union_company" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you required to join a company union?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_union_company_joined" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you join the company union?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s161@Interviews_Screens_xint" title="Mandatory Retirement Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_mandatory_retirement_terminated" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer end your employment by requiring you to retire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_mandatory_retirement_continue" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you have been allowed to continue working for this employer if you had not retired?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_mandatory_retirement_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your employer have a mandatory retirement policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_mandatory_retirement_agreement" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Did you agree to the mandatory retirement policy at the time of your hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_mandatory_retirement_agreed" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Did you agree to the mandatory retirement as a condition of continued employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s162@Interviews_Screens_xint" title="Employer Requested Resignation Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_resignation_or_termination" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you have been terminated if you had not resigned?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_resignation_request_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason that your employer requested your resignation?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s163@Interviews_Screens_xint" title="Other Discharge Details" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_other_reason_incident_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the final incident occur?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_other_reason_explanation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the reason the employer gave for your discharge (whether or not you agree)&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_other_reason_incident" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the final incident that led to your discharge?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_other_reason_policy_violation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you violate the employer’s policy or rule?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_other_reason_policy_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of the policy or rule?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_other_reason_uniformly" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Was the policy or rule uniformly enforced?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If No:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_other_reason_not_uniform" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;  &amp;nbsp  &amp;nbsp  &amp;nbsp Please provide examples&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_other_reason_warned" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive warning (verbal or written) regarding the reason for your discharge prior to the end of the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_other_reason_warn_person" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the name of the person who gave you a warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_other_reason_warn_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_other_reason_warn_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you receive the warning?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s92@Interviews_Screens_xint" title="Pay Practices Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated that the employer’s pay practice changed from what was agreed upon at the time of hire.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pay_practice_universal" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the change applied to all employees?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_pay_practice_desc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the change&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s9@Interviews_Screens_xint" title="Existing Claim and Work Locations" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_worked_in_kentucky" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you work in Kentucky at any point between %g01_base_period_start_date% and %g01_base_period_end_date% ?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_work_outside_kentucky" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you work in a state other than Kentucky between %g01_base_period_start_date% and %g01_base_period_end_date% ?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_applied_for_ui_other_state" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you applied for, or are you receiving, unemployment benefits in a state other than Kentucky within the last 12 months?&lt;/P&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s165@Interviews_Screens_xint" title="Commission Work Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_commission_hours" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to commission work?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_will_quit_commission" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you be willing to quit commission work if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_commission_prevents_search" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your commission work prevent you from looking for work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_commision_prevents_accept" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would your commission work prevent you from accepting an offer of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s166@Interviews_Screens_xint" title="List  Each Period of Employment for %g01_fpr_employer_instance_id%  Between %visible_investigation_period_text% " entity="fpr_employer">
      <container-control type="Entity" entity="fpr_employment" rel="fpr_emr_c_emt">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string">Add Period</property>
          <property name="remove-instance-text" type="string">Remove Period</property>
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Portrait</property>
        </internal-properties>
        <custom-properties />
        <control type="Label">
          <visibility default="true" />
          <caption>&lt;br&gt;</caption>
          <internal-properties>
            <property name="text-style" type="string">Normal</property>
            <property name="IsHTML" type="boolean">true</property>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </control>
        <input-control type="Date" attr="g01_first_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>&lt;p&gt;When was the first day you worked for %g01_fpr_employer_instance_id%? &lt;/p&gt;</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Date" attr="g01_last_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>&lt;p&gt;When was the last day you worked for %g01_fpr_employer_instance_id%? &lt;/p&gt;</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s167@Interviews_Screens_xint" title="You worked for %g01_fpr_employer_instance_id%  in the period between %visible_investigation_period_text%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;A total of %fpr_emt_discrete_weeks_worked% weeks employment occurred &lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br/&gt;
&lt;p&gt;In this question a "separate working week" means you performed at least one hours work during that week.&lt;/p&gt;
&lt;p&gt;The ten weeks may have occurred separately, they need not be consecutive.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_ten_week_per_claimant" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Of the %fpr_emt_discrete_weeks_worked% weeks you worked for %g01_fpr_employer_instance_id%, &lt;b&gt;did you actually work during at least ten separate working weeks?&lt;/b&gt;&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s168@Interviews_Screens_xint" title="List each of your Employer's, From: %visible_investigation_period_text% " entity="global">
      <container-control type="Entity" entity="fpr_employer" rel="fpr_global_c_emr">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string">Add Employer</property>
          <property name="remove-instance-text" type="string">Remove Employer</property>
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Portrait</property>
        </internal-properties>
        <custom-properties />
        <control type="Label">
          <visibility default="true" />
          <caption>&lt;br&gt;</caption>
          <internal-properties>
            <property name="text-style" type="string">Normal</property>
            <property name="IsHTML" type="boolean">true</property>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </control>
        <input-control type="Text" attr="g01_fpr_employer_instance_id" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Employer's Name:&lt;/p&gt;</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
            <property name="lines" type="integer">1</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Text" attr="g01_emp_categorization_code" input-type="Dropdown">
          <default default="Other" />
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Employer type:&lt;/p&gt;</caption>
          <list>
            <option text="Other" default-visibility="true">Other</option>
            <option text="USPS" default-visibility="true">USPS</option>
            <option text="US Military" default-visibility="true">US Military</option>
            <option text="Government" default-visibility="true">Government</option>
          </list>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Statement" attr="emr_receiving_pension" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Are you receiving a pension from this employer?&lt;/p&gt;</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <control type="Label">
          <visibility default="true" />
          <caption>&lt;hr&gt;</caption>
          <internal-properties>
            <property name="text-style" type="string">Normal</property>
            <property name="IsHTML" type="boolean">true</property>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s169@Interviews_Screens_xint" title="Leave of Absence Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_leave_of_absence_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the date your leave of absence started?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_is_working_for_employment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you currently performing any work for this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_is_connected" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does this employer still consider you employed with them?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_approved_loa" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you and your employer both agree that you are on a leave of absence?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="emt_leave_is_temporary" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you intend to return to your position with this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s170@Interviews_Screens_xint" title="Leave of Absence Return to Work Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_leave_of_absence_return" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a return to work date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_leave_retrurn_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Please provide your return to work date&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s171@Interviews_Screens_xint" title="Leave of Absence Reason Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_leave_reason" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason for your leave of absence?&lt;/p&gt;

</caption>
        <list>
          <option text="Medical Leave" default-visibility="true">Medical Leave</option>
          <option text="Personal Leave (other than medical)" default-visibility="true">Personal Leave (other than medical)</option>
          <option text="Other" default-visibility="true">Other</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_other_leave_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbspPlease explain&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_has_leave_documentation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have documentation to substantiate this leave?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fpr_leave_documentation" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp &amp;nbsp Please describe&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s172@Interviews_Screens_xint" title="Retired Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_mandatory_retirement_subject" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer require you to retire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s173@Interviews_Screens_xint" title="Currently Employed  for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="tb"&gt;Full-Time&lt;/p&gt;
&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Considered Full-Time by the employer&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="tb"&gt;Part-Time&lt;/p&gt;
&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Considered less than Full-Time by the employer&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="tb"&gt;As-Needed&lt;/p&gt;
&lt;p&gt;&amp;nbsp &amp;nbsp &amp;nbsp Working on an “as needed” basis per the employer’s staffing needs, for example: Substitute Teacher, On-Call Nurse, etc&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_current_employment_status" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the current status of your employment?&lt;/p&gt;</caption>
        <list>
          <option text="Full-Time" default-visibility="true">Full-Time</option>
          <option text="Part-Time" default-visibility="true">Part-Time</option>
          <option text="As-Needed" default-visibility="true">As-Needed</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s174@Interviews_Screens_xint" title="Full-Time Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_hours_worked_per_week" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours do you work per week, on average?&lt;/p&gt;
</caption>
        <list>
          <option text="" default-visibility="true" />
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_receives_benefits" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you receive employee benefits from this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_why_filing_full_time" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason that you are filing a claim for unemployment insurance benefits if you are employed full-time?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s175@Interviews_Screens_xint" title="Employment Status Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_employment_status_change" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has the status of your employment changed since the date of hire?&lt;/p&gt;
&lt;p&gt;(e.g. hours reduced from Full-Time to Part-Time)&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s176@Interviews_Screens_xint" title="Employment Status Change Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_reduced_from_full_to_part" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you reduced from full-time to less than full time employment (including part-time or as-needed)&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s177@Interviews_Screens_xint" title="Employment Status Non-Reduction Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_always_less_than_full_time" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you always been employed less than full-time by this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s178@Interviews_Screens_xint" title="Employment Status Always Less than Full-Time Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_full_time_option" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;At the time of hire, did you have the option to work full-time for this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_chose_part_time_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp If full-time hours were available to you, why did you choose to work part-time?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s179@Interviews_Screens_xint" title="Demo Support Screen" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;This is a Test and Demonstration support screen only: not to be present/deployed in the actual system.&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fpr_test_flow" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Select secondary test flow?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="fpr_asserted_byed" input-type="default">
        <default default="2012-06-01" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the (Siebel) asserted most recent benefit year end date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="g01_asserted_override_date" input-type="default">
        <default default="2013-03-03" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Enter any assertion of a test-case specific processing override date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s180@Interviews_Screens_xint" title="Laid Off Notification Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_layoff_informant" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;P&gt;What is the name of the person who told you that you were laid-off?&lt;/P&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_layoff_title" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;P&gt;What was the title of the person who told you that you were laid-off?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_layoff_notice_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date were you notified about the lay-off?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_layoff_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date were you laid-off?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s181@Interviews_Screens_xint" title="Laid Off Lack of Notification Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_layoff_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If the employer did not tell you that you were laid-off,&lt;br&gt;
why do you believe that you have been laid off from this employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Had you received previous warnings to alert you that your job was in jeopardy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s182@Interviews_Screens_xint" title="Layoff Timeframe Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_is_temporary" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is the lay off temporary?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_return" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you given a definite return to work date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_layoff_recall_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What is your date of recall?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_layoff_recall_notification" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp How were you made aware of the recall date?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s183@Interviews_Screens_xint" title="Layoff Incentive Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_reduction_package" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you accept a reduction in workforce package?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_layoff_volunteer" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you volunteer to be laid off?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_layoff_early_retirement" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you accept an early retirement?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s184@Interviews_Screens_xint" title="Layoff Reduction in Workforce Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_layoff_package_offered" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer offer you an incentive package/buyout for voluntarily accepting the reduction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_layoff_buyout_not_mandatory" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Could you have continued work for this employment if you had not accepted the reduction if workforce package/buyout?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s185@Interviews_Screens_xint" title="Layoff Reason Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_layoff_employer_reason" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason that the employer gave you for the lay-off?&lt;/p&gt;
</caption>
        <list>
          <option text="Scheduled Shut-Down" default-visibility="true">Scheduled Shut-Down</option>
          <option text="Position Eliminated Due to Business Need" default-visibility="true">Position Eliminated Due to Business Need</option>
          <option text="Business Slow-Down" default-visibility="true">Business Slow-Down</option>
          <option text="Company Restructure" default-visibility="true">Company Restructure</option>
          <option text="Employer Closed the Business" default-visibility="true">Employer Closed the Business</option>
          <option text="Temporary Assignment Ended (for reasons other than being fired or quitting)" default-visibility="true">Temporary Assignment Ended (for reasons other than being fired or quitting)</option>
          <option text="Other" default-visibility="true">Other</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_layoff_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Other, please explain&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s186@Interviews_Screens_xint" title="Active Labor Dispute Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_ld_result" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please choose the option that best explains the result of the labor dispute?&lt;/p&gt;
</caption>
        <list>
          <option text="Strike" default-visibility="true">Strike</option>
          <option text="Lock Out" default-visibility="true">Lock Out</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_ld_groups" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What groups are involved in the labor dispute? (Example: Employer, Union, Other Relevant Parties)&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_ld_participating" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you actively participating and/or financing the labor dispute?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_ld_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please explain the reason for the labor dispute&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_ld_location" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the location of the labor dispute?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_ld_empl_address" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the address of your employment location (i.e. the physical location where you work)?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s187@Interviews_Screens_xint" title="Ended Labor Dispute Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_ld_end_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the dispute end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_ld_ended_company_closed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the dispute end because the company permanently closed?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s188@Interviews_Screens_xint" title="No Return to Work After Labor Dispute Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_ld_noshow" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Why didn’t you go back to work after the labor dispute ended?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s189@Interviews_Screens_xint" title="Required Retirement Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pursuant_to_plan" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your employer have a mandatory retirement policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_plan_includes_benefits" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer's mandatory policy include retirement benefits?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_mandatory_retirement_continue" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Would you have been allowed to continue working for this employer if you had not retired?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_agreed_to_retirement_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you agree to the mandatory retirement policy at the time of your hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If No:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_mandatory_retirement_agreed" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Did you agree to the mandatory retirement as a condition of continued employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s190@Interviews_Screens_xint" title="Retirement Reason Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_retirement_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the reason that you retired from the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s191@Interviews_Screens_xint" title="Employment Status Reduced Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="emt_requested_reduction" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you request that your working hours be reduced?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s192@Interviews_Screens_xint" title="Employee Requested Reduction Details for %fpr_emt_visible_name% " entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_is_temporary" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is the reduction temporary?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_request_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did you request a reduction in your hours of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_request_person" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the name of the person to whom you requested a reduction in your hours of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_title" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the title of the person to whom you requested a reduction in your hours of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;
&lt;ul&gt;
    &lt;li class="tblue"&gt;Personal Reasons&lt;/li&gt;
        &lt;ul&gt;
	        &lt;li class="ns"&gt;Examples of Personal Reasons include but are not limited to:&lt;/li&gt;
	        &lt;li class="ns"&gt;non work-related injury or health condition&lt;/li&gt; 
	        &lt;li class="ns"&gt;domestic circumstances, attending school&lt;/li&gt;
	        &lt;li class="ns"&gt;relocation, military reassignment, etc&lt;/li&gt;
	     &lt;/ul&gt;
    &lt;li class="tblue"&gt;Work-Related&lt;/li&gt;
        &lt;ul&gt;
	        &lt;li class="ns"&gt;Examples of Work-Related Reasons include but are not limited to:&lt;/li&gt; 
	        &lt;li class="ns"&gt;working conditions, hurt on the job&lt;/li&gt;
	        &lt;li class="ns"&gt;lack of training, safety concerns&lt;/li&gt;
	        &lt;li class="ns"&gt;dispute in the workplace, employer breach of contract&lt;/li&gt;
	        &lt;li class="ns"&gt;harassment, etc.&lt;/li&gt;
	     &lt;/ul&gt;
    &lt;li class="tblue"&gt;Accepted an Offer of Work&lt;/li&gt;
        &lt;ul&gt;
            &lt;li class="ns"&gt;Quit to go to a new job&lt;/li&gt;
		    &lt;li class="ns"&gt;quit while maintaining other employment&lt;/li&gt;
        &lt;/ul&gt;
&lt;/ul&gt;
&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_reduction_circumstance" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the circumstances that most closely reflect the reason you requested a reduction in your hours.&lt;/p&gt;</caption>
        <list>
          <option text="Personal Reasons" default-visibility="true">SDC01</option>
          <option text="Work-Related" default-visibility="true">SDC02</option>
          <option text="Accepted an Offer of Work" default-visibility="true">SDC03</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s204@Interviews_Screens_xint" title="Work Alternatives Reduction of Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <input-control type="Statement" attr="scr_reduction_concerns_expressed" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you express your concerns regarding your reason for requesting a reduction in hours with this employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;if Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="emt_concerns_expressed_with" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp  What was the name of the person with whom you discussed your concerns?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="emt_concerns_expressed_title" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What was the title of the person?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="emt_concerns_expressed_date" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp On what date did you discuss your concerns?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_action_employer_took" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp What specific actions did the employer take to address or correct the issue(s)?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_pursued_prior" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you pursue alternatives to requesting a reduction?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;if Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_alternatives_prior_reduction" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe all alternatives that were pursued before requesting a reduction in hours&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Not:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_not_pursued_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Why were alternatives not pursued?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s203@Interviews_Screens_xint" title="Personal Reasons Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class= "pb"&gt;You have indicated you requested a reduction in hours for personal reasons.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_primary_reason_reduction" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason for your request for reduction in hours&lt;/p&gt;
</caption>
        <list>
          <option text="Attend school or a training program" default-visibility="true">PR01</option>
          <option text="To move or relocate" default-visibility="true">PR02</option>
          <option text="Responsibility for the care for family member(s) (i.e. dependent care)" default-visibility="true">PR03</option>
          <option text="Lack of transportation" default-visibility="true">PR04</option>
          <option text="Domestic circumstances" default-visibility="true">PR05</option>
          <option text="Medical condition or injury (not caused by the work)" default-visibility="true">PR06</option>
          <option text="Other" default-visibility="true">PR07</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please explain&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s205@Interviews_Screens_xint" title="Work-Related Reasons Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;You have indicated you requested a reduction in hours for work-related reasons.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_primary_reduction_reason" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please select the primary reason for requesting a work reduction&lt;/p&gt;
</caption>
        <list>
          <option text="Disciplinary action imposed by the employer" default-visibility="true">RH01</option>
          <option text="Dispute in the workplace" default-visibility="true">RH02</option>
          <option text="Drug or alcohol test required by the employer" default-visibility="true">RH03</option>
          <option text="Equipment problems" default-visibility="true">RH04</option>
          <option text="Work-related injury or health condition" default-visibility="true">RH05</option>
          <option text="Harassment" default-visibility="true">RH06</option>
          <option text="Lack of training or experience" default-visibility="true">RH07</option>
          <option text="Religious beliefs" default-visibility="true">RH08</option>
          <option text="Pay practices or rate of pay" default-visibility="true">RH09</option>
          <option text="Distance to work" default-visibility="true">RH10</option>
          <option text="Work hours required by the employer" default-visibility="true">RH11</option>
          <option text="Reduction in workforce initiative by the employer (i.e. accepting a buyout)" default-visibility="true">RH12</option>
          <option text="Failed to uphold your conditions of hire (i.e. failing to maintain a certification)" default-visibility="true">RH13</option>
          <option text="Other" default-visibility="true">RH14</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_reduction_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please Explain&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s206@Interviews_Screens_xint" title="Employer Requested Reduction Details for %fpr_emt_visible_name% " entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rhe_reduction_temporary" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is the reduction temporary?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rhe_reduction_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did the employer reduce your hours of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rhe_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the name of the person who informed you that your hours of work were reduced?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rhe_title" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the title of the person who informed you that your hours of work were reduced?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rhe_reduction_reason" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Why did the employer reduce your hours of work?&lt;/p&gt;</caption>
        <list>
          <option text="Business Slow-down" default-visibility="true">Business Slow-down</option>
          <option text="Disciplinary Action" default-visibility="true">Disciplinary Action</option>
          <option text="Other" default-visibility="true">Other</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rhe_reduction_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please Explain&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s207@Interviews_Screens_xint" title="Effort to Correct Behavior Reduction in Hours Details for %fpr_emt_visible_name% " entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_prevent_reduction_action" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe what action you took to correct your behavior or prevent your reduction in hours&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s208@Interviews_Screens_xint" title="Disciplinary Action Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_employer_action" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What disciplinary action did the employer impose that caused you to request a reduction in hours?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_disciplinary_action_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was this disciplinary action imposed?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_action_in_accordance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this disciplinary action administered in accordance with the employee handbook or employer policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_disciplinary_warning" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Had you previously received warnings or disciplinary action during this employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s209@Interviews_Screens_xint" title="Dispute in the Workplace Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_dispute_circumstance" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What circumstances surrounding the dispute led you to request a reduction in hours?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_dispute_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the dispute in the workplace impact your employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_dispute_person" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;With whom did the dispute take place?&lt;/p&gt;</caption>
        <list>
          <option text="Management" default-visibility="true">Management</option>
          <option text="Supervisor" default-visibility="true">Supervisor</option>
          <option text="Co-Worker" default-visibility="true">Co-Worker</option>
          <option text="Customer" default-visibility="true">Customer</option>
          <option text="Other" default-visibility="true">Other</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_dispute_other" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please Describe&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Date" attr="scr_rh_final_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s214@Interviews_Screens_xint" title="Drug or Alcohol Test Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_submit_alcohol" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Why did you request a reduction in hours rather than submit to (or complete) the employer’s drug and/or alcohol test?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_drug_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date was the test to be conducted?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_drug_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the employer have a policy concerning drug and/or alcohol testing?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_drug_reason" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the reason for the drug and/or alcohol test?&lt;/p&gt;
</caption>
        <list>
          <option text="Random" default-visibility="true">Random</option>
          <option text="Post Accident" default-visibility="true">Post Accident</option>
          <option text="Pre-Employment" default-visibility="true">Pre-Employment</option>
          <option text="Reasonable Suspicion" default-visibility="true">Reasonable Suspicion</option>
          <option text="Follow-up Testing" default-visibility="true">Follow-up Testing</option>
          <option text="Other" default-visibility="true">Other</option>
          <option text="" default-visibility="true" />
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Other:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_other_drug_reason" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please Describe&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s218@Interviews_Screens_xint" title="Equipment Problems Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_equipment_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final equipment problem(s) that caused you to request a reduction in hours.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_equipment_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_equipment_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the equipment problem(s) impact your employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_one_time_incident" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the problem(s) with the equipment a one-time incident?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_equipment_service" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the equipment serviced/repaired in accordance with industry standards?	&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_trained" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you trained or authorized to use the equipment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_employment_aware" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the employer made aware of the equipment problem(s) prior to the request of a reduction in hours?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_employment_aware_method" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp &amp;nbsp  &amp;nbsp  How was the employer made aware?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s220@Interviews_Screens_xint" title="Work-Related Injury or Health Condition Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_injury_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What type of injury or medical condition caused you to request a reduction in hours?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_start_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the injury occur or when did the medical condition begin?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_condition_caused" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this injury or medical condition caused by the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_medical_documentation" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation to show that the condition was caused by the work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_workers_comp_approved" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you approved for Workers Compensation due to this injury or medical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_exhausted_leave_time" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you exhaust all available leave time (including short term disability, FMLA, etc.) prior to requesting a reduction in hours?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_restrictive_reasons" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has your doctor provided you with any restrictions for returning to this position?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_restrictions_accomodated" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Is the employer able to accommodate these restrictions?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s223@Interviews_Screens_xint" title="Harassment Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_harassment_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe final incident of harassment that caused you to request a reduction in hours&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_incident_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_employment_impact" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How did the incident(s) of harassment impact your employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_repeated_harassment" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were there repeated occurrences of this harassment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_policy" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the employer have a harassment policy?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_reporting_procedures" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you follow the proper procedures to report the alleged harassment (such as filing a formal complaint, 
addressing your concerns with the employer)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s225@Interviews_Screens_xint" title="Lack of Training/Experience Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_training_lack" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your lack of training or experience negatively impact your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_lack_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_prior_experience" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have prior experience doing this type of work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_training_provided" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer provide you with training in order to perform your employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_warnings" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive any type of warning regarding your work performance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s228@Interviews_Screens_xint" title="Religious Beliefs Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_religious_description" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that caused you to request a reduction in hours.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_event_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="scr_rh_conflict_details" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How, specifically, did this incident conflict with your religious beliefs?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_recurring" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is this conflict with your religious beliefs a recurring issue?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_conflict_prior_to_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you aware of any possible conflict between your job duties and your religious beliefs prior to the start of the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="scr_rh_changed_conflict" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the conditions of work change after you accepted the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;If Yes:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_conflict_change_description" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt; &amp;nbsp  &amp;nbsp  &amp;nbsp Please describe these changes&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s229@Interviews_Screens_xint" title="Rate of Pay/Pay Practices Reduction in Hours Details for %fpr_emt_visible_name%" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="scr_rh_paydescription" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe the final incident that caused you to request a reduction in hours.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="scr_rh_pay_incident_date" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the final incident take place?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_rate_change" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the rate of pay change from the rate agreed upon at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="scr_rh_pay_practice" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did the employer’s pay practice (e.g. pay dates, etc.) change from what was agreed upon at the time of hire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <folder>
          <caption>TestScreens</caption>
          <items>
            <screen ref="s179@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Preamble</caption>
          <items>
            <screen ref="s7@Interviews_Screens_xint" />
            <screen ref="s8@Interviews_Screens_xint" />
            <screen ref="s9@Interviews_Screens_xint" />
            <screen ref="s10@Interviews_Screens_xint" />
            <screen ref="s11@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Personal Information</caption>
          <items>
            <screen ref="s12@Interviews_Screens_xint" />
            <screen ref="s13@Interviews_Screens_xint" />
            <screen ref="s14@Interviews_Screens_xint" />
            <screen ref="s22@Interviews_Screens_xint" />
            <screen ref="s15@Interviews_Screens_xint" />
            <screen ref="s16@Interviews_Screens_xint" />
            <screen ref="s17@Interviews_Screens_xint" />
            <screen ref="s18@Interviews_Screens_xint" />
            <screen ref="s19@Interviews_Screens_xint" />
            <screen ref="s20@Interviews_Screens_xint" />
            <screen ref="s21@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Employer</caption>
          <items>
            <screen ref="s168@Interviews_Screens_xint" />
            <for-each relationship="fpr_global_c_emr">
              <items>
                <folder>
                  <caption>Employer-Information</caption>
                  <items>
                    <screen ref="s71@Interviews_Screens_xint" />
                    <screen ref="s72@Interviews_Screens_xint" />
                    <screen ref="s73@Interviews_Screens_xint" />
                    <screen ref="s74@Interviews_Screens_xint" />
                    <screen ref="s75@Interviews_Screens_xint" />
                    <screen ref="s76@Interviews_Screens_xint" />
                    <screen ref="s77@Interviews_Screens_xint" />
                  </items>
                </folder>
              </items>
            </for-each>
          </items>
        </folder>
        <for-each relationship="fpr_global_c_emr">
          <items>
            <folder>
              <caption>Employment</caption>
              <items>
                <screen ref="s166@Interviews_Screens_xint" />
                <for-each relationship="fpr_emr_c_emt">
                  <items>
                    <folder>
                      <caption>Employment_Information</caption>
                      <items>
                        <screen ref="s167@Interviews_Screens_xint" />
                      </items>
                    </folder>
                  </items>
                </for-each>
                <for-each relationship="fpr_emr_c_emt">
                  <items>
                    <folder>
                      <caption>Separation</caption>
                      <items>
                        <screen ref="xrulz_screen_15" />
                        <folder>
                          <caption>Quit Screens</caption>
                          <items>
                            <screen ref="s5@Interviews_Screens_xint" />
                            <screen ref="s67@Interviews_Screens_xint" />
                            <screen ref="s70@Interviews_Screens_xint" />
                            <folder>
                              <caption>Quit Details (Personal)</caption>
                              <items>
                                <screen ref="s78@Interviews_Screens_xint" />
                                <screen ref="s79@Interviews_Screens_xint" />
                              </items>
                            </folder>
                            <screen ref="s80@Interviews_Screens_xint" />
                            <folder>
                              <caption>Quit Details (Work Related)</caption>
                              <items>
                                <screen ref="s81@Interviews_Screens_xint" />
                                <screen ref="s82@Interviews_Screens_xint" />
                                <screen ref="s83@Interviews_Screens_xint" />
                                <screen ref="s84@Interviews_Screens_xint" />
                                <screen ref="s85@Interviews_Screens_xint" />
                                <screen ref="s86@Interviews_Screens_xint" />
                                <screen ref="s88@Interviews_Screens_xint" />
                                <screen ref="s87@Interviews_Screens_xint" />
                                <screen ref="s89@Interviews_Screens_xint" />
                                <screen ref="s90@Interviews_Screens_xint" />
                                <screen ref="s91@Interviews_Screens_xint" />
                                <screen ref="s92@Interviews_Screens_xint" />
                                <screen ref="s93@Interviews_Screens_xint" />
                                <screen ref="s94@Interviews_Screens_xint" />
                                <screen ref="s95@Interviews_Screens_xint" />
                                <screen ref="s96@Interviews_Screens_xint" />
                                <screen ref="s97@Interviews_Screens_xint" />
                                <screen ref="s98@Interviews_Screens_xint" />
                                <screen ref="s103@Interviews_Screens_xint" />
                                <screen ref="s105@Interviews_Screens_xint" />
                              </items>
                            </folder>
                            <folder>
                              <caption>Quit Details (Accepted Offer)</caption>
                              <items>
                                <screen ref="s114@Interviews_Screens_xint" />
                                <screen ref="s115@Interviews_Screens_xint" />
                                <screen ref="s116@Interviews_Screens_xint" />
                              </items>
                            </folder>
                          </items>
                        </folder>
                        <folder>
                          <caption>Discharge Screens</caption>
                          <items>
                            <screen ref="s123@Interviews_Screens_xint" />
                            <screen ref="s128@Interviews_Screens_xint" />
                            <screen ref="s130@Interviews_Screens_xint" />
                            <screen ref="s131@Interviews_Screens_xint" />
                            <screen ref="s134@Interviews_Screens_xint" />
                            <screen ref="s137@Interviews_Screens_xint" />
                            <screen ref="s138@Interviews_Screens_xint" />
                            <screen ref="s139@Interviews_Screens_xint" />
                            <screen ref="s140@Interviews_Screens_xint" />
                            <screen ref="s141@Interviews_Screens_xint" />
                            <screen ref="s142@Interviews_Screens_xint" />
                            <screen ref="s143@Interviews_Screens_xint" />
                            <screen ref="s144@Interviews_Screens_xint" />
                            <screen ref="s145@Interviews_Screens_xint" />
                            <screen ref="s153@Interviews_Screens_xint" />
                            <screen ref="s154@Interviews_Screens_xint" />
                            <screen ref="s155@Interviews_Screens_xint" />
                            <screen ref="s156@Interviews_Screens_xint" />
                            <screen ref="s158@Interviews_Screens_xint" />
                            <screen ref="s159@Interviews_Screens_xint" />
                            <screen ref="s160@Interviews_Screens_xint" />
                            <screen ref="s161@Interviews_Screens_xint" />
                            <screen ref="s162@Interviews_Screens_xint" />
                            <screen ref="s163@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Currently Employed Screens</caption>
                          <items>
                            <screen ref="s173@Interviews_Screens_xint" />
                            <screen ref="s174@Interviews_Screens_xint" />
                            <screen ref="s175@Interviews_Screens_xint" />
                            <screen ref="s176@Interviews_Screens_xint" />
                            <screen ref="s177@Interviews_Screens_xint" />
                            <screen ref="s178@Interviews_Screens_xint" />
                            <screen ref="s191@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Leave of Absence Screens</caption>
                          <items>
                            <screen ref="s169@Interviews_Screens_xint" />
                            <screen ref="s170@Interviews_Screens_xint" />
                            <screen ref="s171@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Suspended Screens</caption>
                          <items>
                            <screen ref="s118@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Retired Screens</caption>
                          <items>
                            <screen ref="s172@Interviews_Screens_xint" />
                            <screen ref="s189@Interviews_Screens_xint" />
                            <screen ref="s190@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Laid Off Screens</caption>
                          <items>
                            <screen ref="s120@Interviews_Screens_xint" />
                            <screen ref="s180@Interviews_Screens_xint" />
                            <screen ref="s181@Interviews_Screens_xint" />
                            <screen ref="s182@Interviews_Screens_xint" />
                            <screen ref="s183@Interviews_Screens_xint" />
                            <screen ref="s184@Interviews_Screens_xint" />
                            <screen ref="s185@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Labor Dispute Screens</caption>
                          <items>
                            <screen ref="s121@Interviews_Screens_xint" />
                            <screen ref="s186@Interviews_Screens_xint" />
                            <screen ref="s187@Interviews_Screens_xint" />
                            <screen ref="s188@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Reduction in Hours (Employee)</caption>
                          <items>
                            <screen ref="s192@Interviews_Screens_xint" />
                            <folder>
                              <caption>Personal Reasons</caption>
                              <items>
                                <screen ref="s203@Interviews_Screens_xint" />
                              </items>
                            </folder>
                            <folder>
                              <caption>Work Related</caption>
                              <items>
                                <screen ref="s205@Interviews_Screens_xint" />
                                <screen ref="s208@Interviews_Screens_xint" />
                                <screen ref="s209@Interviews_Screens_xint" />
                                <screen ref="s214@Interviews_Screens_xint" />
                                <screen ref="s218@Interviews_Screens_xint" />
                                <screen ref="s220@Interviews_Screens_xint" />
                                <screen ref="s223@Interviews_Screens_xint" />
                                <screen ref="s225@Interviews_Screens_xint" />
                                <screen ref="s228@Interviews_Screens_xint" />
                                <screen ref="s229@Interviews_Screens_xint" />
                              </items>
                            </folder>
                            <screen ref="s204@Interviews_Screens_xint" />
                          </items>
                        </folder>
                        <folder>
                          <caption>Reduction in Hours (Employer)</caption>
                          <items>
                            <screen ref="s206@Interviews_Screens_xint" />
                            <screen ref="s207@Interviews_Screens_xint" />
                          </items>
                        </folder>
                      </items>
                    </folder>
                  </items>
                </for-each>
              </items>
            </folder>
          </items>
        </for-each>
        <folder>
          <caption>Able and Available</caption>
          <items>
            <screen ref="s26@Interviews_Screens_xint" />
            <screen ref="s27@Interviews_Screens_xint" />
            <screen ref="s28@Interviews_Screens_xint" />
            <screen ref="s29@Interviews_Screens_xint" />
            <screen ref="s30@Interviews_Screens_xint" />
            <screen ref="s31@Interviews_Screens_xint" />
            <screen ref="s32@Interviews_Screens_xint" />
            <screen ref="s33@Interviews_Screens_xint" />
            <screen ref="s34@Interviews_Screens_xint" />
            <screen ref="s36@Interviews_Screens_xint" />
            <screen ref="s37@Interviews_Screens_xint" />
            <screen ref="s38@Interviews_Screens_xint" />
            <screen ref="s39@Interviews_Screens_xint" />
            <screen ref="s165@Interviews_Screens_xint" />
            <screen ref="s40@Interviews_Screens_xint" />
            <screen ref="s41@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Ability to Work</caption>
          <items>
            <screen ref="s42@Interviews_Screens_xint" />
            <screen ref="s43@Interviews_Screens_xint" />
            <screen ref="s44@Interviews_Screens_xint" />
            <screen ref="s45@Interviews_Screens_xint" />
            <screen ref="s46@Interviews_Screens_xint" />
            <screen ref="s47@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Final</caption>
          <items>
            <screen ref="s65@Interviews_Screens_xint" />
          </items>
        </folder>
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>