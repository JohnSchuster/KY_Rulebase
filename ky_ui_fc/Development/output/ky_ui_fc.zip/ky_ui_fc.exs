<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Assessment Summary" entity="global">
      <goal-control type="Goal" flow="f3@Interviews_Screens_xint">
        <visibility default="enabled" />
        <caption>Main Flow</caption>
        <internal-properties>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </goal-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s2@Interviews_Screens_xint" title="Main PoC Booleans" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>This is a Test screen to Display Initial Values</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 2</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s3@Interviews_Screens_xint" title="Employer Instances" entity="global">
      <container-control type="Entity" entity="fpr_employer" rel="global_cont_employer">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string" />
          <property name="remove-instance-text" type="string" />
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Tabular</property>
        </internal-properties>
        <custom-properties />
        <input-control type="Text" attr="g01_fpr_employer_instance_id" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Employer's Company Name:</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
            <property name="lines" type="integer">1</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Statement" attr="g01_emp_current_employer" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Do you currently work for this employer?</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Text" attr="g01_emp_categorization_code" input-type="Dropdown">
          <default default="Any Other Type" />
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <list>
            <option text="..." default-visibility="true">...</option>
            <option text="USPS" default-visibility="true">USPS</option>
            <option text="US Military" default-visibility="true">US Military</option>
            <option text="Government" default-visibility="true">Government</option>
          </list>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
            <property name="__list-name" type="string" />
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s4@Interviews_Screens_xint" title="List each period of Employment with %g01_fpr_employer_instance_id%  " entity="fpr_employer">
      <container-control type="Entity" entity="fpr_employment" rel="employer_cont_employment">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string" />
          <property name="remove-instance-text" type="string" />
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Tabular</property>
        </internal-properties>
        <custom-properties />
        <input-control type="Date" attr="g01_first_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>First Day Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Date" attr="g01_last_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Last Day Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Number" attr="g01_empt_weeks_not_worked" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Weeks Not Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s5@Interviews_Screens_xint" title="Separation From %g01_fpr_employer_instance_id% Sample Question Screen #1" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>Sample Separation Screen label</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 3</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s6@Interviews_Screens_xint" title="Sample Employment Details Screen" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>These type of screens gather additional information about each employment</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 3</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <folder>
          <caption>Employer</caption>
          <items>
            <screen ref="s3@Interviews_Screens_xint" />
            <folder>
              <caption>Employer-Information</caption>
              <items />
            </folder>
          </items>
        </folder>
        <for-each relationship="global_cont_employer">
          <items>
            <folder>
              <caption>Employment</caption>
              <items>
                <screen ref="s4@Interviews_Screens_xint" />
                <for-each relationship="employer_cont_employment">
                  <items>
                    <folder>
                      <caption>Employment-Information</caption>
                      <items>
                        <screen ref="s6@Interviews_Screens_xint" />
                      </items>
                    </folder>
                  </items>
                </for-each>
                <for-each relationship="employer_cont_employment">
                  <items>
                    <folder>
                      <caption>Separation</caption>
                      <items>
                        <screen ref="s5@Interviews_Screens_xint" />
                      </items>
                    </folder>
                  </items>
                </for-each>
              </items>
            </folder>
          </items>
        </for-each>
        <screen ref="s2@Interviews_Screens_xint" />
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>