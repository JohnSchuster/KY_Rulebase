<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Assessment Summary" entity="global">
      <goal-control type="Goal" flow="f3@Interviews_Screens_xint">
        <visibility default="enabled" />
        <caption>&lt;img src="../../../images/start.png"</caption>
        <internal-properties>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </goal-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../images/watermark.png" class="center" &gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s3@Interviews_Screens_xint" title="Employer Instances" entity="global">
      <container-control type="Entity" entity="fpr_employer" rel="global_cont_employer">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string">Add Row</property>
          <property name="remove-instance-text" type="string">Remove Checked</property>
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Tabular</property>
        </internal-properties>
        <custom-properties />
        <input-control type="Text" attr="g01_fpr_employer_instance_id" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Employer's Name:</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
            <property name="lines" type="integer">1</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Statement" attr="g01_emp_current_employer" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Are you currently working&lt;br&gt; for this employer</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Text" attr="g01_emp_categorization_code" input-type="Dropdown">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Employer type</caption>
          <list>
            <option text="..." default-visibility="true">...</option>
            <option text="USPS" default-visibility="true">USPS</option>
            <option text="US Military" default-visibility="true">US Military</option>
            <option text="Government" default-visibility="true">Government</option>
          </list>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Statement" attr="emp_non_deduct_pension" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Do you receive a  pension&lt;br&gt; from this employer?</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s4@Interviews_Screens_xint" title="List each period of Employment with %g01_fpr_employer_instance_id%  " entity="fpr_employer">
      <container-control type="Entity" entity="fpr_employment" rel="employer_cont_employment">
        <internal-properties>
          <property name="defining-attr-prefix" type="string">#</property>
          <property name="add-instance-text" type="string" />
          <property name="remove-instance-text" type="string" />
          <property name="want-default-entity" type="boolean">true</property>
          <property name="display-style" type="string">Tabular</property>
        </internal-properties>
        <custom-properties />
        <input-control type="Date" attr="g01_first_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>First Day Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Date" attr="g01_last_day_worked_date" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Last Day&lt;br&gt; Performed Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
        <input-control type="Number" attr="g01_empt_weeks_not_worked" input-type="default">
          <visibility default="true" />
          <mandatory default="true" />
          <read-only default="false" />
          <caption>Total Weeks&lt;br&gt; Not Worked</caption>
          <internal-properties>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
            <property name="IsHTML" type="boolean">true</property>
          </internal-properties>
          <custom-properties />
        </input-control>
      </container-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s5@Interviews_Screens_xint" title="Separation From %g01_fpr_employer_instance_id% Sample Question Screen #1" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>Sample Separation Screen label</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 3</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s6@Interviews_Screens_xint" title="Sample Employment Details Screen" entity="fpr_employment">
      <control type="Label">
        <visibility default="true" />
        <caption>New Label</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s7@Interviews_Screens_xint" title="Claim Filing Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="tcr"&gt;This is an application for Unemployment Insurance. Intentionally submitting false information to obtain benefits is a criminal act.&lt;br&gt;
Any violation will result in prosecution under KRS.331.370(2).&lt;/p&gt;&lt;br&gt;
&lt;p class="tcu"&gt;YOU ARE RESPONSIBLE FOR THE ACCURACY OF ALL OF YOUR ANSWERS&lt;/p&gt;
&lt;br&gt;
&lt;h2&gt;To file your Kentucky Unemployment claim, you will need:&lt;/h2&gt;
&lt;p class="pb"&gt;Persoinal information&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;Date of birth&lt;/li&gt;
  &lt;li&gt;Complete mailing address&lt;/li&gt;
  &lt;li&gt;Phone number&lt;/li&gt;
  &lt;li&gt;Alien registration number If not a US Citizen&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;Employment information for last 18 months&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;Employer name&lt;/li&gt;
  &lt;li&gt;Employer address&lt;/li&gt;
  &lt;li&gt;Employer phone number&lt;/li&gt;
  &lt;li&gt;Start and end dates&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;Other information&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;List of state(s) you worked in other than Kentucky in the past 18 months&lt;/li&gt;
  &lt;li&gt;Standard Form 8 and/or 50 if worked for Federal Government in the past 18 months&lt;/li&gt;
  &lt;li&gt;DD214 member 4 if served in US Military in the past 18 months&lt;/li&gt;
&lt;/ul&gt;
&lt;p class="pb"&gt;If you do not have this information, exit the system, gather required information and return to this site and continue the claim filing process.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s8@Interviews_Screens_xint" title="Benefit Period Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;
&lt;h2 class="tc"&gt;Important Dates!&lt;/h2&gt;
&lt;br&gt;
&lt;p&gt;There are two important time periods when filing a claim:&lt;b&gt; Base Period&lt;/b&gt; and &lt;b&gt;Benefit Year&lt;/b&gt;&lt;/p&gt;&lt;br&gt;
&lt;p&gt;Based on today's date, your dates are as foillows:
&lt;br&gt;
&lt;br&gt;
&lt;table class="nxtable"&gt;
  &lt;tr&gt;
    &lt;th class="nxth"&gt;Base Period&lt;/th&gt;
    &lt;th class="nxth"&gt;Date&lt;/th&gt;
	&lt;th class="nxth"&gt;Benefit Year&lt;/th&gt;
	&lt;th class="nxth"&gt;Date&lt;/th&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td class="nxtd"&gt;Start Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_base_period_start_date%&lt;/td&gt;
	&lt;td class="nxtd"&gt;Effective Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_effective_date%&lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td class="nxtd"&gt;End Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%g01_base_period_end_date% &lt;/td&gt;
    &lt;td class="nxtd"&gt;End Date&lt;/td&gt;
    &lt;td class="nxtd"&gt;%mr_byed%&lt;/td&gt;
  &lt;/tr&gt;
  &lt;/table&gt;
&lt;br&gt;&lt;br&gt;
&lt;p&gt;Your wages/earnings in the &lt;b&gt;Base Period&lt;/b&gt; determine your weekly benefit amount.
&lt;br&gt;Your Base Period is the first four of the last five calendar quarters immediately prior to the quarter in which you file your claim.
&lt;br&gt;If you do not have sufficient earnings in your Base Period, you may not qualify for benefits.&lt;/p&gt;
&lt;br&gt;&lt;br&gt;
&lt;p&gt;The &lt;b&gt;Benefit Year&lt;/b&gt; Effective Date is the Sunday of the week in which you complete your claim.  
&lt;br&gt;The Benefit Year End Date (or BYE) is approximately 1 year after the Effective Date.  
&lt;br&gt;Should you qualify for benefits, you will be mailed your weekly benefit amount, which is valid until your BYE.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s9@Interviews_Screens_xint" title="Existing Claim and Work Locations" entity="global">
      <input-control type="Statement" attr="proxy_s003_01" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you work in Kentucky at any point between %g01_base_period_start_date% and %g01_base_period_end_date% ?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s003_02" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you work in a state other than Kentucky between %g01_base_period_start_date% and %g01_base_period_end_date% ?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s003_03" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you applied for or are you receiving unemployment benefits in a state other than Kentucky in the last 12 months?&lt;/P&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s10@Interviews_Screens_xint" title="Military Experience" entity="global">
      <input-control type="Statement" attr="proxy_s004_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;P&gt;Did you serve in the military between %g01_base_period_start_date% and %g01_effective_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s11@Interviews_Screens_xint" title="Unemployment Benefits from state other than Kentucky" entity="global">
      <input-control type="Statement" attr="proxy_s005_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you still have a balance in another state, whether or not you were found eligible?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s12@Interviews_Screens_xint" title="Personal Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please provide the following information in order to help us in the event we need to contact you.&lt;/p&gt;
&lt;hr&gt;

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="proxy_s007_01" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a United States citizen?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s007_02" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please list other names under which you have worked (maiden name, married name, etc.):&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s007_03" input-type="default">
        <default default="1959-12-31" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Birth Date:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_007_04" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Primary phone number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_s007_04" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Alternate phone number&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s007_05" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Email address:&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s007_06" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Should we need to contact you, is an interpreter needed?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_007_07" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Prefered language?&lt;/p&gt;</caption>
        <list>
          <option text="Spanish" default-visibility="true">Spanish</option>
          <option text="Portuguese" default-visibility="true">Portuguese</option>
          <option text="Chinese" default-visibility="true">Chinese</option>
          <option text="Tagalog" default-visibility="true">Tagalog</option>
          <option text="French" default-visibility="true">French</option>
          <option text="Vietnamese" default-visibility="true">Vietnamese</option>
          <option text="English" default-visibility="true">English</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;The following questions are optional and are for statistical purposes only&lt;/p&gt;
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="proxy_s007_07" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Gender:&lt;/p&gt;</caption>
        <list>
          <option text="Male" default-visibility="true">Male</option>
          <option text="Female" default-visibility="true">Female</option>
          <option text="No Answer" default-visibility="true">No Answer</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s007_08" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Ethnic group:&lt;/p&gt;</caption>
        <list>
          <option text="Hispanic or Latino" default-visibility="true">Hispanic or Latino</option>
          <option text="Not Hispanic or Latino" default-visibility="true">Not Hispanic or Latino</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s007_09" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Race:&lt;/p&gt;</caption>
        <list>
          <option text="White" default-visibility="true">White</option>
          <option text="Black or African American" default-visibility="true">Black or African American</option>
          <option text="Asian" default-visibility="true">Asian</option>
          <option text="American Indian or Alaskan Native" default-visibility="true">American Indian or Alaskan Native</option>
          <option text="Native Hawaiian or Other Pacific Islander" default-visibility="true">Native Hawaiian or Other Pacific Islander</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s007_10" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a disability&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s13@Interviews_Screens_xint" title="Mailing Address" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please verify the information below and update if needed.&lt;/p&gt;
&lt;hr&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="proxy_s008_01" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Street address:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s008_02" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Suite or Apt. Number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s008_03" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s008_04" input-type="Dropdown">
        <default default="KY" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;State:&lt;/p&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s008_05" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;County:&lt;/p&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string">Body_body</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_s008_06" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Zip code:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s008_07" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the address contain a post office box number?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s14@Interviews_Screens_xint" title="Physical Address" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pb"&gt;Please enter the physical address at which you reside.&lt;/p&gt;
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="proxy_s009_01" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Street address:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s009_02" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Suite or Apt Number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s009_03" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s009_04" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;State:&lt;/p&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_s009_05" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Zip code:&lt;/p&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s009_06" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;County:&lt;/p&gt;</caption>
        <list>
          <option text="Adair" default-visibility="true">Adair</option>
          <option text="Allen" default-visibility="true">Allen</option>
          <option text="Anderson" default-visibility="true">Anderson</option>
          <option text="Ballard" default-visibility="true">Ballard</option>
          <option text="Barren" default-visibility="true">Barren</option>
          <option text="Bath" default-visibility="true">Bath</option>
          <option text="Bell" default-visibility="true">Bell</option>
          <option text="Boone" default-visibility="true">Boone</option>
          <option text="Bourbon" default-visibility="true">Bourbon</option>
          <option text="Boyd" default-visibility="true">Boyd</option>
          <option text="Boyle" default-visibility="true">Boyle</option>
          <option text="Bracken" default-visibility="true">Bracken</option>
          <option text="Breathitt" default-visibility="true">Breathitt</option>
          <option text="Breckinridge" default-visibility="true">Breckinridge</option>
          <option text="Bullitt" default-visibility="true">Bullitt</option>
          <option text="Butler" default-visibility="true">Butler</option>
          <option text="Caldwell" default-visibility="true">Caldwell</option>
          <option text="Calloway" default-visibility="true">Calloway</option>
          <option text="Campbell" default-visibility="true">Campbell</option>
          <option text="Carlisle" default-visibility="true">Carlisle</option>
          <option text="Carroll" default-visibility="true">Carroll</option>
          <option text="Carter" default-visibility="true">Carter</option>
          <option text="Casey" default-visibility="true">Casey</option>
          <option text="Christian" default-visibility="true">Christian</option>
          <option text="Clark" default-visibility="true">Clark</option>
          <option text="Clay" default-visibility="true">Clay</option>
          <option text="Clinton" default-visibility="true">Clinton</option>
          <option text="Crittenden" default-visibility="true">Crittenden</option>
          <option text="Cumberland" default-visibility="true">Cumberland</option>
          <option text="Daviess" default-visibility="true">Daviess</option>
          <option text="Edmonson" default-visibility="true">Edmonson</option>
          <option text="Elliott" default-visibility="true">Elliott</option>
          <option text="Estill" default-visibility="true">Estill</option>
          <option text="Fayette" default-visibility="true">Fayette</option>
          <option text="Fleming" default-visibility="true">Fleming</option>
          <option text="Floyd" default-visibility="true">Floyd</option>
          <option text="Franklin" default-visibility="true">Franklin</option>
          <option text="Fulton" default-visibility="true">Fulton</option>
          <option text="Gallatin" default-visibility="true">Gallatin</option>
          <option text="Garrard" default-visibility="true">Garrard</option>
          <option text="Grant" default-visibility="true">Grant</option>
          <option text="Graves" default-visibility="true">Graves</option>
          <option text="Grayson" default-visibility="true">Grayson</option>
          <option text="Green" default-visibility="true">Green</option>
          <option text="Greenup" default-visibility="true">Greenup</option>
          <option text="Hancock" default-visibility="true">Hancock</option>
          <option text="Hansock" default-visibility="true">Hansock</option>
          <option text="Hardin" default-visibility="true">Hardin</option>
          <option text="Harlan" default-visibility="true">Harlan</option>
          <option text="Harrison" default-visibility="true">Harrison</option>
          <option text="Hart" default-visibility="true">Hart</option>
          <option text="Henderson" default-visibility="true">Henderson</option>
          <option text="Henry" default-visibility="true">Henry</option>
          <option text="Hickman" default-visibility="true">Hickman</option>
          <option text="Hopkins" default-visibility="true">Hopkins</option>
          <option text="Jackson" default-visibility="true">Jackson</option>
          <option text="Jefferson" default-visibility="true">Jefferson</option>
          <option text="Jessamine" default-visibility="true">Jessamine</option>
          <option text="Johnson" default-visibility="true">Johnson</option>
          <option text="Kenton" default-visibility="true">Kenton</option>
          <option text="Knott" default-visibility="true">Knott</option>
          <option text="Knox" default-visibility="true">Knox</option>
          <option text="Larue" default-visibility="true">Larue</option>
          <option text="Laurel" default-visibility="true">Laurel</option>
          <option text="Lawrence" default-visibility="true">Lawrence</option>
          <option text="Lee" default-visibility="true">Lee</option>
          <option text="Leslie" default-visibility="true">Leslie</option>
          <option text="Letcher" default-visibility="true">Letcher</option>
          <option text="Lewis" default-visibility="true">Lewis</option>
          <option text="Lincoln" default-visibility="true">Lincoln</option>
          <option text="Livingston" default-visibility="true">Livingston</option>
          <option text="Logan" default-visibility="true">Logan</option>
          <option text="Lyon" default-visibility="true">Lyon</option>
          <option text="Madison" default-visibility="true">Madison</option>
          <option text="Magoffin" default-visibility="true">Magoffin</option>
          <option text="Marion" default-visibility="true">Marion</option>
          <option text="Marshall" default-visibility="true">Marshall</option>
          <option text="Martin" default-visibility="true">Martin</option>
          <option text="Mason" default-visibility="true">Mason</option>
          <option text="McCracken" default-visibility="true">McCracken</option>
          <option text="McCreary" default-visibility="true">McCreary</option>
          <option text="McLean" default-visibility="true">McLean</option>
          <option text="Meade" default-visibility="true">Meade</option>
          <option text="Menifee" default-visibility="true">Menifee</option>
          <option text="Mercer" default-visibility="true">Mercer</option>
          <option text="Metcalfe" default-visibility="true">Metcalfe</option>
          <option text="Monroe" default-visibility="true">Monroe</option>
          <option text="Montgomery" default-visibility="true">Montgomery</option>
          <option text="Morgan" default-visibility="true">Morgan</option>
          <option text="Muhlenberg" default-visibility="true">Muhlenberg</option>
          <option text="Nelson" default-visibility="true">Nelson</option>
          <option text="Nicholas" default-visibility="true">Nicholas</option>
          <option text="Ohio" default-visibility="true">Ohio</option>
          <option text="Oldham" default-visibility="true">Oldham</option>
          <option text="Owen" default-visibility="true">Owen</option>
          <option text="Owsley" default-visibility="true">Owsley</option>
          <option text="Pendleton" default-visibility="true">Pendleton</option>
          <option text="Perry" default-visibility="true">Perry</option>
          <option text="Pike" default-visibility="true">Pike</option>
          <option text="Powell" default-visibility="true">Powell</option>
          <option text="Pulaski" default-visibility="true">Pulaski</option>
          <option text="Robertson" default-visibility="true">Robertson</option>
          <option text="Rockcastle" default-visibility="true">Rockcastle</option>
          <option text="Rowan" default-visibility="true">Rowan</option>
          <option text="Russell" default-visibility="true">Russell</option>
          <option text="Scott" default-visibility="true">Scott</option>
          <option text="Shelby" default-visibility="true">Shelby</option>
          <option text="Simpson" default-visibility="true">Simpson</option>
          <option text="Spencer" default-visibility="true">Spencer</option>
          <option text="Taylor" default-visibility="true">Taylor</option>
          <option text="Todd" default-visibility="true">Todd</option>
          <option text="Trigg" default-visibility="true">Trigg</option>
          <option text="Trimble" default-visibility="true">Trimble</option>
          <option text="Union" default-visibility="true">Union</option>
          <option text="Warren" default-visibility="true">Warren</option>
          <option text="Washington" default-visibility="true">Washington</option>
          <option text="Wayne" default-visibility="true">Wayne</option>
          <option text="Webster" default-visibility="true">Webster</option>
          <option text="Whitley" default-visibility="true">Whitley</option>
          <option text="Wolfe" default-visibility="true">Wolfe</option>
          <option text="Woodford" default-visibility="true">Woodford</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s15@Interviews_Screens_xint" title="Alien Status" entity="global">
      <input-control type="Number" attr="proxy_s010_01" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your alien registration number?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s16@Interviews_Screens_xint" title="Payment Method" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;
&lt;p class="pbr"&gt;If you are found payable, you should receive payment within 3-4 business days after requesting your benefits.&lt;br&gt;
You must make your request for benefits on the date you are given at the completion of filing your claim and every 2 weeks thereafter.&lt;/p&gt;
&lt;br&gt;&lt;br&gt;
&lt;p class="pb"&gt;Information about direct deposit:&lt;/p&gt;
&lt;ul&gt;
  &lt;li&gt;You can confirm deposit of your unemployment insurance benefits by contacting your bank&lt;/li&gt;
  &lt;li&gt;New or changed direct deposits will result in one paper check for the first 2 week period after submission&lt;/li&gt;
  &lt;li&gt;Should the bank not be able to process the deposited funds into the specified account, the claimant is responsible for any resulting bank fees&lt;/li&gt;
  &lt;li&gt;The authorization to deposit funds into the provided account will remain in effect until the claimant initiates a change&lt;/li&gt;
 &lt;/ul&gt;
&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="proxy_s011_01" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pb"&gt;What is your preferred method of receiving unemployment benefits payment?&lt;/p&gt;</caption>
        <list>
          <option text="Check" default-visibility="true">Check</option>
          <option text="Direct  Deposit" default-visibility="true">Direct  Deposit</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s17@Interviews_Screens_xint" title="Direct Deposit" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;img src="../../../../images/directDepositHelp.gif" class="center" /&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br&gt;&lt;p class="note"&gt;You have elected to use Direct Deposit as your method of receiving payment.
You are responsible for the accuracy of the following information.&lt;/p&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="proxy_s006_01" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Account holders name:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s006_02" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Bank name:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_s006_03" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p class="pr"&gt;Routing number:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="proxy_s006_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p class="pg"&gt;Account number&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s006_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Account type&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s18@Interviews_Screens_xint" title="Benefit Withholdings" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pbr"&gt;If you are found payable, your benefits are taxable&lt;/p&gt;&lt;br&gt;
&lt;p class="pbb"&gt;Unemployment insurance benefits are taxable and must be reported 
on your income tax return.&lt;br&gt;OET will report the total amount of your benefits 
to the Internal Revenue Service and will provide&lt;br&gt;you with an annual 
statement (Form 1099G), no later than January 31st of each year.&lt;/p&gt;&lt;br&gt;&lt;br&gt;&lt;p&gt;
You may elect to have 10 percent of your benefits withheld for federal taxes 
and 4 percent withheld for state taxes.&lt;br&gt;This is optional and may be changed once 
during your benefit year.&lt;/p&gt; 
&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="proxy_s012_01" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do You want 10 percent of your benefit check withheld for Federal Taxes?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s011_02" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do You want 4 percent of your benefit check withheld for State Taxes?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s19@Interviews_Screens_xint" title="Workers Compensation" entity="global">
      <input-control type="Statement" attr="proxy_012_01" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you receive workers compensation benefits between %g01_base_period_start_date% and %g01_base_period_end_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s012_02" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Were you eligible to receive workers compensation benefits between %g01_base_period_start_date% and %g01_base_period_end_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s20@Interviews_Screens_xint" title="Workers Compensation Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;If you did receive or were eligible to receive Worker's Compensation between 
these dates you will need to provide documentation&lt;br&gt;(ie. paystubs or letter) 
showing the dates of eligibility.  You should be able to obtain this from your employer’s 
insurance carrier or Worker’s Compensation.&lt;br&gt;  
You will need to provide proof of Worker’s Compensation benefits or notify your 
nearest Kentucky Career Center Office that you are in the process of obtaining this information.
&lt;br&gt;&lt;br&gt;
You will need to provide proof of this information to your nearest Kentucky Career Center Office. 
If you live outside of Kentucky, please contact the Interstate Office.&lt;/p&gt;
&lt;br&gt;
&lt;p class="pr"&gt;Failure to report within 10 days of the mail date of this letter may delay 
the processing of your claim or result in the denial of benefits.&lt;br&gt; 
Thank you for your cooperation.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s21@Interviews_Screens_xint" title="Natural Disaster Information" entity="global">
      <input-control type="Statement" attr="proxy_s013_01" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you unemployed as a result of a natural disaster?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s22@Interviews_Screens_xint" title="Distance to Kentucky" entity="global">
      <input-control type="Statement" attr="proxy_s014_01" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you within commuting distance to Kentucky?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s26@Interviews_Screens_xint" title="Trade Union" entity="global">
      <input-control type="Statement" attr="proxy_s016_01" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a member in good standing of a sanctioned labor union?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s27@Interviews_Screens_xint" title="Trade Union Work Search" entity="global">
      <input-control type="Statement" attr="proxy_s017_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the trade union find work for you?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s28@Interviews_Screens_xint" title="Work Profile Information" entity="global">
      <input-control type="Text" attr="proxy_s018_01" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your field of expertise or industry?&lt;/p&gt;</caption>
        <list>
          <option text="Accommodation and Food Services" default-visibility="true">Accommodation and Food Services</option>
          <option text="Administrative and Support Services" default-visibility="true">Administrative and Support Services</option>
          <option text="Agriculture, Forestry, Fishing and Hunting" default-visibility="true">Agriculture, Forestry, Fishing and Hunting</option>
          <option text="Air Transportation" default-visibility="true">Air Transportation</option>
          <option text="Arts, Entertainment, and Recreation" default-visibility="true">Arts, Entertainment, and Recreation</option>
          <option text="Construction" default-visibility="true">Construction</option>
          <option text="Educational Services" default-visibility="true">Educational Services</option>
          <option text="Finance and Insurance" default-visibility="true">Finance and Insurance</option>
          <option text="Health Care and Social Assistance" default-visibility="true">Health Care and Social Assistance</option>
          <option text="Information" default-visibility="true">Information</option>
          <option text="Manufacturing" default-visibility="true">Manufacturing</option>
          <option text="Management of Companies and Enterprises" default-visibility="true">Management of Companies and Enterprises</option>
          <option text="Mining, Quarrying, and Oil and Gas Extraction" default-visibility="true">Mining, Quarrying, and Oil and Gas Extraction</option>
          <option text="Other Services (except Public Administration)" default-visibility="true">Other Services (except Public Administration)</option>
          <option text="Paper Manufacturing" default-visibility="true">Paper Manufacturing</option>
          <option text="Professional, Scientific, and Technical Services" default-visibility="true">Professional, Scientific, and Technical Services</option>
          <option text="Public Administration" default-visibility="true">Public Administration</option>
          <option text="Real Estate and Rental and Leasing" default-visibility="true">Real Estate and Rental and Leasing</option>
          <option text="Retail Trade" default-visibility="true">Retail Trade</option>
          <option text="Transportation and Warehousing" default-visibility="true">Transportation and Warehousing</option>
          <option text="Utilities" default-visibility="true">Utilities</option>
          <option text="Waste Management and Remediation Services" default-visibility="true">Waste Management and Remediation Services</option>
          <option text="Wholesale Trade" default-visibility="true">Wholesale Trade</option>
          <option text="Wholesale Electronic Markets and Agents and Brokers" default-visibility="true">Wholesale Electronic Markets and Agents and Brokers</option>
          <option text="Wood Product Manufacturing" default-visibility="true">Wood Product Manufacturing</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s018_02" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your job require advanced education or a certification?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s018_03" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you refused an offer of suitable work since %g01_filing_date%?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s29@Interviews_Screens_xint" title="Work Availability Information" entity="global">
      <input-control type="Statement" attr="proxy_s000_01" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have reliable transportation (personal vehicle, public transportation, etc.) to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_is_in_school" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you enrolled in a school or training program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_care_no_work" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the care of others (child care, elder care, care of family member, etc.)limit your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_is_self_employed" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you self-employed or working on a commission basis?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_is_closely_held" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you a corporate officer in a closely-held corporation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fpr_claimant_in_jail" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you incarcerated or scheduled to report for incarceration (imprisoned, jailed, house arrest, work release, etc.)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s30@Interviews_Screens_xint" title="Transportation Detail" entity="global">
      <input-control type="Date" attr="proxy_s019_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the restriction on your transportation begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s019_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when the restriction on your transportation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s019_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have any possible alternate means of transportation?&lt;/p&gt; </caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s31@Interviews_Screens_xint" title="Transportation Restriction" entity="global">
      <input-control type="Date" attr="proxy_s020_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect the restriction on your transportation to end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s32@Interviews_Screens_xint" title="Alternative Transportation" entity="global">
      <input-control type="Text" attr="proxy_s021_01" input-type="default">
        <default default="My wifes broom" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe your alternate means of transportation.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">6</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s33@Interviews_Screens_xint" title="School or Training Program Information" entity="global">
      <input-control type="Statement" attr="proxy_s022_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you in a trade union apprentice program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s022_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has your enrollment in school or training program been approved by the Division of Unemployment Insurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s022_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the school, training program, educational institution?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s022_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did you begin school or training program?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s022_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect to complete your school or training program?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s022_06" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you attend class(es) for your school or training program?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s022_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does the time dedicated to your school or training program limit your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s34@Interviews_Screens_xint" title="Approved School or Training Program Information" entity="global">
      <input-control type="Text" attr="proxy_s023_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s023_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Has there been a change to the program or schedule since you were approved?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s023_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the begin date for the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s023_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was the end date for the program of study for which you were approved?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s35@Interviews_Screens_xint" title="Additional School or Training Program Information" entity="global">
      <input-control type="Statement" attr="proxy_s024_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are your classes available online?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s024_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you willing to change your class schedule if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s024_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you willing to quit school or training program if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s024_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you previously requested approval for your program of study?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s36@Interviews_Screens_xint" title="Care of Others Information" entity="global">
      <input-control type="Statement" attr="proxy_s025_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have any alternate means of care (daycare, babysitter, eldercare, family member, etc.)?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s025_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the limitation due to the care of others begin?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s025_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when the limitation due to the care of others will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s025_04" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to the care of others?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s37@Interviews_Screens_xint" title="Care of Others Information (a)" entity="global">
      <input-control type="Date" attr="proxy_s026_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect the limitation due to the care of others to end? &lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s38@Interviews_Screens_xint" title="Care of Others Information (b)" entity="global">
      <input-control type="Text" attr="proxy_s027_01" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe your alternate means of care.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s39@Interviews_Screens_xint" title="Self Employment or Commission Work Information" entity="global">
      <input-control type="Text" attr="proxy_s028_01" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to self employment or commission work?&lt;/p&gt;
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s028_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you willing to quit self employment or commission work if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s40@Interviews_Screens_xint" title="Officer of a Closely Held Corporation Information" entity="global">
      <input-control type="Text" attr="proxy_s029_01" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;How many hours per week do you dedicate to serving as an officer of a closely held corporation?&lt;/p.
</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="1 - 10" default-visibility="true">1 - 10</option>
          <option text="11 - 20" default-visibility="true">11 - 20</option>
          <option text="21 - 30" default-visibility="true">21 - 30</option>
          <option text="31 - 40" default-visibility="true">31 - 40</option>
          <option text="More than 40" default-visibility="true">More than 40</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s029_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you willing to quit serving as an officer of a closely held corporation if you were to find suitable work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s41@Interviews_Screens_xint" title="Incarceration Information" entity="global">
      <input-control type="Date" attr="proxy_s030_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your incarceration begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="proxy_s030_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;hen do you expect your incarceration to end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s030_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you permitted to look for or accept work under a work release program?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s030_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the facility at which you are incarcerated?  If under house arrest, please list ‘Home’&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s42@Interviews_Screens_xint" title="Work Ability Information" entity="global">
      <input-control type="Statement" attr="proxy_s031_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a physical condition that limits your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s031_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a mental health condition that limits your ability to look for or accept work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s031_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you receiving or been approved for Social Security disability payments in the last 12 months?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s031_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have an application in progress for Social Security disability payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s43@Interviews_Screens_xint" title="Physical Limitation Information" entity="global" attr="b1@Interviews_Screens_xint">
      <input-control type="Date" attr="proxy_s032_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your physical limitation begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s032_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when physical limitation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s032_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation supporting your physical limitation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s032_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is there any work you can perform?&lt;/p&gt;&lt;hr&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;What is your physical limitation? Check all that apply.&lt;/p&gt;&lt;br&gt;&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="proxy_s032_06" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Lifting 50 lbs. or more&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s032_07" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Repetitive Motion&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s032_10" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Standing&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s032_08" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Limited Hours (please provide number of hours restricted to work) &lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s032_11" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Other&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s000_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do we need a widget on this screen?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s44@Interviews_Screens_xint" title="Physical Limitation Information (a)" entity="global">
      <input-control type="Date" attr="proxy_s033_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect your physical limitation to end?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s45@Interviews_Screens_xint" title="Mental Health Limitation Information" entity="global" attr="b2@Interviews_Screens_xint">
      <input-control type="Date" attr="proxy_s034_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your mental health limitation begin?&lt;/p&gt;

</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s034_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you know when mental health limitation will end?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s034_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have medical documentation supporting your mental health limitation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s034_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Can you perform any work in any capacity?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="proxy_s034_05" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Please describe your mental health limitation.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">4</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s46@Interviews_Screens_xint" title="Mental Health Limitation Information (a)" entity="global">
      <input-control type="Date" attr="proxy_s035_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect your mental health limitation to end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s47@Interviews_Screens_xint" title="Social Security Disability Information" entity="global">
      <input-control type="Statement" attr="proxy_s036_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you apply based on a physical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="proxy_s036_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you apply based on a mental health condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s48@Interviews_Screens_xint" title="Employment Address Details for WidgetsRus" entity="global">
      <input-control type="Text" attr="fc_s001_01" input-type="default">
        <default default="1" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Street Address:&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s001_02" input-type="default">
        <default default="Avon" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;City:&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s001_03" input-type="Dropdown">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;State:&lt;/p&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fc_s001_05" input-type="default">
        <default default="1" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Zip Code&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Number" attr="fc_s001_04" input-type="default">
        <default default="1" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Phone Number:&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s001_06" input-type="Dropdown">
        <default default="KY" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;The State in which you worked&lt;/p&gt;</caption>
        <list>
          <option text="ALABAMA" default-visibility="true">AL</option>
          <option text="ALASKA" default-visibility="true">AK</option>
          <option text="ARIZONA" default-visibility="true">AZ</option>
          <option text="ARKANSAS" default-visibility="true">AR</option>
          <option text="CALIFORNIA" default-visibility="true">CA</option>
          <option text="COLORADO" default-visibility="true">CO</option>
          <option text="CONNECTICUT" default-visibility="true">CT</option>
          <option text="DELAWARE" default-visibility="true">DE</option>
          <option text="DISTRICT OF COLUMBIA" default-visibility="true">DC</option>
          <option text="FLORIDA" default-visibility="true">FL</option>
          <option text="GEORGIA" default-visibility="true">GA</option>
          <option text="HAWAII" default-visibility="true">HI</option>
          <option text="IDAHO" default-visibility="true">ID</option>
          <option text="ILLINOIS" default-visibility="true">IL</option>
          <option text="INDIANA" default-visibility="true">IN</option>
          <option text="IOWA" default-visibility="true">IA</option>
          <option text="KANSAS" default-visibility="true">KS</option>
          <option text="KENTUCKY" default-visibility="true">KY</option>
          <option text="LOUISIANA" default-visibility="true">LA</option>
          <option text="MAINE" default-visibility="true">ME</option>
          <option text="MARYLAND" default-visibility="true">MD</option>
          <option text="MASSACHUSETTS" default-visibility="true">MA</option>
          <option text="MICHIGAN" default-visibility="true">MI</option>
          <option text="MINNESOTA" default-visibility="true">MN</option>
          <option text="MISSISSIPPI" default-visibility="true">MS</option>
          <option text="MISSOURI" default-visibility="true">MO</option>
          <option text="MONTANA" default-visibility="true">MT</option>
          <option text="NEBRASKA" default-visibility="true">NE</option>
          <option text="NEVADA" default-visibility="true">NV</option>
          <option text="NEW HAMPSHIRE" default-visibility="true">NH</option>
          <option text="NEW JERSEY" default-visibility="true">NJ</option>
          <option text="NEW MEXICO" default-visibility="true">NM</option>
          <option text="NEW YORK" default-visibility="true">NY</option>
          <option text="NORTH CAROLINA" default-visibility="true">NC</option>
          <option text="NORTH DAKOTA" default-visibility="true">ND</option>
          <option text="OHIO" default-visibility="true">OH</option>
          <option text="OKLAHOMA" default-visibility="true">OK</option>
          <option text="OREGON" default-visibility="true">OR</option>
          <option text="PENNSYLVANIA" default-visibility="true">PA</option>
          <option text="RHODE ISLAND" default-visibility="true">RI</option>
          <option text="SOUTH CAROLINA" default-visibility="true">SC</option>
          <option text="SOUTH DAKOTA" default-visibility="true">SD</option>
          <option text="TENNESSEE" default-visibility="true">TN</option>
          <option text="TEXAS" default-visibility="true">TX</option>
          <option text="UTAH" default-visibility="true">UT</option>
          <option text="VERMONT" default-visibility="true">VT</option>
          <option text="VIRGINIA" default-visibility="true">VA</option>
          <option text="WASHINGTON" default-visibility="true">WA</option>
          <option text="WEST VIRGINIA" default-visibility="true">WV</option>
          <option text="WISCONSIN" default-visibility="true">WI</option>
          <option text="WYOMING" default-visibility="true">WY</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s49@Interviews_Screens_xint" title="Pension Income for Employer WidgetsRus" entity="global">
      <input-control type="Statement" attr="fc_s002_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you contribute to this pension?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s002_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is this pension paid under the Social Security Act or the Railroad Retirement Act of 1974?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s002_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you receiving monthly payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s50@Interviews_Screens_xint" title="13 A - monthly distribution" entity="global">
      <input-control type="Currency" attr="fc_s003_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the gross amount received monthly?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s003_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did you receive the first payment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s51@Interviews_Screens_xint" title="13 B - lump sum distribution" entity="global">
      <input-control type="Currency" attr="fc_s004_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What was total lump sum amount?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s004_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;On what date did you receive the payment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s004_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you have the option to receive monthly payments?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Currency" attr="fc_s004_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If Yes, what would have been the gross amount received monthly?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s52@Interviews_Screens_xint" title="Employment Details for WidgetsRus" entity="global">
      <input-control type="Text" attr="fc_s005_01" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Wage Type?&lt;/p&gt;</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Hourly" default-visibility="true">Hourly</option>
          <option text="Salary" default-visibility="true">Salary</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s005_02" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Employment Type?&lt;/p&gt;</caption>
        <list>
          <option text="..." default-visibility="true">...</option>
          <option text="Full-Time" default-visibility="true">Full-Time</option>
          <option text="Part-Time" default-visibility="true">Part-Time</option>
          <option text="As-Needed" default-visibility="true">As-Needed</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s005_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Job Title?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s005_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Job Duties?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Currency" attr="fc_s005_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Rate of Pay?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s005_06" input-type="Radiobutton">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;The rate of pay is...&lt;/p&gt;&lt;br&gt;&lt;hr&gt;</caption>
        <list>
          <option text="Per/hour" default-visibility="true">Per/hour</option>
          <option text="Per/year" default-visibility="true">Per/year</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>For this period of employment, were you:&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fc_s005_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;A business owner/officer of a corporation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s005_08" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;An educational employee?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s005_09" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;An athletic professional?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s005_10" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;A water transportation employee?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s53@Interviews_Screens_xint" title="Athletic Professional Information" entity="global">
      <input-control type="Statement" attr="fc_s006_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you paid to participate in athletic events?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s006_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you paid to train or prepare to participate in athletic events?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s006_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you currently in between seasons?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s006_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you been given reasonable assurance that you will return in the upcoming season?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s006_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you under contract for the upcoming season?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s54@Interviews_Screens_xint" title="Athletic Professional Information (a)" entity="global">
      <input-control type="Text" attr="fc_s007_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;With what organization to you intend to participate for the upcoming season?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s007_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name and title of the individual who provided you reasonable assurance of your return?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s007_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the last season end?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s007_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When does the upcoming season begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s55@Interviews_Screens_xint" title="Educational Employee Information" entity="global">
      <input-control type="Statement" attr="fc_s008_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Is your employer an educational institution or an educational service agency?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s008_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you been given reasonable assurance that you will be an educational employee in the upcoming academic year?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s008_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you under contract for the upcoming academic year?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s008_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you expecting to return to a similar position in the upcoming academic year?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s56@Interviews_Screens_xint" title="Educational Employee Information (a)" entity="global" attr="b4@Interviews_Screens_xint">
      <input-control type="Text" attr="fc_s009_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the educational institution or service agency that provided you reasonable assurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s009_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the phone number of the educational institution or service agency that provided you reasonable assurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s009_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the name of the individual who provided you reasonable assurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s009_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the title of the individual who provided you reasonable assurance?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s009_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the date were you were provided reasonable assurance as an educational employee?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s009_06" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you accepted the offer for the upcoming academic year?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s009_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If you did not accept the offer, please explain&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s57@Interviews_Screens_xint" title="Educational Employee Information (b)" entity="global" attr="b3@Interviews_Screens_xint">
      <input-control type="Text" attr="fc_s010_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is your current position?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s010_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;What is the position you have accepted for the upcoming academic year?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s58@Interviews_Screens_xint" title="Water Transportation Employment Information" entity="global">
      <input-control type="Statement" attr="fc_s011_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you on a scheduled off-duty period?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s011_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did the off-duty period begin?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="fc_s011_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When are/were you scheduled to return from the off-duty period?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s59@Interviews_Screens_xint" title="Employment Status for WidgetsRus from 9/10/11 to 10/11/12" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p&gt;Below are descriptions of several categories related to loss of employment.&lt;/p&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li class="tblue"&gt;Currently Employed (Full-time or part-time)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) You continue working full-time in accordance with your employer's customary full-time work schedule or&lt;/li&gt;
	  &lt;li class="ns"&gt;You are working part-time, working on-call, as needed, PRN status&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tblue"&gt;Leave of Absence&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) On FMLA, Short-term disability, etc.&lt;/li&gt;
	  &lt;li class="ns"&gt;You are temporarily away from work for personal reasons and you are expected to return to your position&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tblue"&gt;Suspension&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) You are temporarily away from work due to a diciplinary action or&lt;/li&gt;
	  &lt;li class="ns"&gt;investigation initiated by your employer&lt;/li&gt;
	&lt;/ul&gt;  
  &lt;li class="tblue"&gt;Quit&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) An employee may choose to leave a job for changes in personal circumstances, working conditions, prospects of other work, etc.&lt;/li&gt;
	&lt;/ul&gt;
  &lt;li class="tblue"&gt;Retired (Voluntary or Involuntary)&lt;/li&gt;
    &lt;ul&gt;
      &lt;li class="ns"&gt;(eg.) You voluntarily retired from the workforce, you are  receiving retirement/pension or retainer benefits, or&lt;/li&gt;
      &lt;li class="ns"&gt;you retired in accordance with the employer mandqatory retirement policy.&lt;/li&gt;
    &lt;/ul&gt;	  
  &lt;li class="tblue"&gt;Discharged (aka. Terminated, fired, let-go, sacked, canned, etc)&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) Employer chooses to require the employee to leave, generally, the employer states that it is the fault of the employee:&lt;/li&gt;
	  &lt;li class="ns"&gt;attendance, policy violation, work performance, failed drug test, etc.&lt;/li&gt;
    &lt;/ul&gt;
  &lt;li class="tblue"&gt;Laid Off&lt;/li&gt;
    &lt;ul&gt;
	  &lt;li class="ns"&gt;(eg.) Position eliminated or a business slow-down occured due to economic cycles or&lt;/li&gt;
	  &lt;li class="ns"&gt;the company's need to restructure itself, the firm itself going out of business or a change in the function of the employer&lt;/li&gt;
	     &lt;ul&gt;
		   &lt;li class="ns"&gt;(eg.) A certain type of product or service is no longer offered by the company therefore jobs related to that product or service are no longer needed&lt;/li&gt;
		&lt;/ul&gt;
    &lt;/ul&gt;		
&lt;/ul&gt;  &lt;br&gt;&lt;br&gt;
&lt;p class="pg"&gt;ONLY THE QUIT OPTION WORKS FOR NOW&lt;/p&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fc_s012_01" input-type="Dropdown">
        <default default="..." />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Which of these categories best describes your circumstances with this employment?&lt;/p&gt;
</caption>
        <list>
          <option text="Currently Employed" default-visibility="true">Currently Employed</option>
          <option text="Leave of Absence" default-visibility="true">Leave of Absence</option>
          <option text="Suspension" default-visibility="true">Suspension</option>
          <option text="Quit" default-visibility="true">Quit</option>
          <option text="Retired" default-visibility="true">Retired</option>
          <option text="Discharged" default-visibility="true">Discharged</option>
          <option text="Laid Off" default-visibility="true">Laid Off</option>
          <option text="..." default-visibility="true">...</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s60@Interviews_Screens_xint" title="Quit Details for WidgetsRus from  9/10/11 to 10/11/12" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;p class="pr"&gt;What is the reason you left this employment?&lt;/p&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="fc_s013_01" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I left the employment for personal reasons&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s013_02" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I left the employment for work related reasons&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s013_03" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;I left the employment for prospects of other work&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s61@Interviews_Screens_xint" title="Quit Details (Personal) for WidgetsRus from  9/10/11 to 10/11/12" entity="global">
      <input-control type="Statement" attr="fc_s014_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to a medical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to religious beliefs?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you fail/refuse to return to work following a temporary layoff?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to the employer’s pay rate or pay practices?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to the distance to work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_06" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you abandon the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to your active duty military spouse being reassigned (Permanent Change of Station) to another state by a branch of the service?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_08" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment in anticipation of layoff or discharge?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_09" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment to retire?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s014_10" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you request a reduction in working hours from the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s62@Interviews_Screens_xint" title="Quit Details (Work Related) for WidgetsRus from  9/10/11 to 10/11/12" entity="global">
      <input-control type="Statement" attr="fc_s015_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment rather than take a drug/alcohol test as required by the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to a dispute in the work place?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to equipment problems?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to harassment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to lack of training or experience?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_06" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to working conditions?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to disciplinary actions imposed by the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_08" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment due to working hours required by the employer?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s015_09" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did your employer request that you resign?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s63@Interviews_Screens_xint" title="Quit Details (Medical)  for WidgetsRus from  9/10/11 to 10/11/12" entity="global">
      <input-control type="Statement" attr="fc_s016_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was this medical condition caused by this employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have competent medical evidence to prove the work caused the medical condition?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you file a claim for Worker’s Compensation?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_04" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Was the medical condition caused by an event away from the workplace?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_05" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you exhaust all available leave including any short term disability you may have had the option to take prior to leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_06" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you been released by a medical doctor to return to work either with or without restrictions?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s016_07" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you exhaust all reasonable alternatives prior to leaving the employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_s016_08" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;What medical conditions do you have that caused you to leave the employment?&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">2</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s64@Interviews_Screens_xint" title="Quit Details (Prospects)  for WidgetsRus from  9/10/11 to 10/11/12" entity="global">
      <input-control type="Statement" attr="fc_s017_01" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment to accept temporary or less than full-time employment?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s017_02" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Did you leave the employment for prospect of other work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="fc_s017_03" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;If this employment was 100 miles or more from you home, did you  leave this employment to accept work less
than 100 miles from your home?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s65@Interviews_Screens_xint" title="Claim Filing Certification and Authorization" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;p class="tcr"&gt;Intentionally submitting false information is a criminal act.  Any violation will result in prosecution under KRS.341.370 (2).&lt;p&gt;
&lt;br&gt;
&lt;p class="tc"&gt;You may access the Rights and Responsibilities pamphlet (PAM-UI-400) by clicking &lt;a href="https://uiclaims.des.ky.gov/eBenefits_enu/help/PAM_UI_400.htm"&gt;here&lt;/a&gt; or at your local Unemployment Insurance Office.&lt;/p&gt;
&lt;br&gt;
&lt;p class="tc"&gt;Effective January 1, 2012, Kentucky Unemployment Insurance law requires a one week waiting period per Benefit Year.&lt;br&gt; 
Your waiting period week will be your first payable week. 
If you are found eligible for benefits you will request benefits for two week periods,&lt;br&gt;however your first check will only be for one week.&lt;/p&gt;
&lt;br&gt;
&lt;p class="tcr"&gt;Please type your initials in each box to acknowledge each statement.&lt;/p&gt;
&lt;hr&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fc_001" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I was given access to the PAM-UI-400, Rights and Responsibilities pamphlet.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_002" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that I must report ALL WAGES EARNED.&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_003" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that I must look for one or more jobs per week.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_004" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand that there is a one week waiting period per Benefit Year.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_005" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I authorize my former employer(s) to release all information requested in connection with my claim
for unemployment insurance benefits.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="fc_006" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I certify that the information I have provided on this claim for unemployment insurance benefits is true 
and correct to the best of my knowledge.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;&lt;p class ="pr"&gt;Please sign in box to the right to submit your application.&lt;/p&gt;
&lt;p&gt;Use blue or black ink only&lt;/p&gt;&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="fc_007" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;I understand my rights and wish to submit my application for unemployment insurance benefits.&lt;/p&gt;
</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <folder>
          <caption>Preamble</caption>
          <items>
            <screen ref="s7@Interviews_Screens_xint" />
            <screen ref="s8@Interviews_Screens_xint" />
            <screen ref="s9@Interviews_Screens_xint" />
            <screen ref="s10@Interviews_Screens_xint" />
            <screen ref="s11@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Personal Information</caption>
          <items>
            <screen ref="s12@Interviews_Screens_xint" />
            <screen ref="s13@Interviews_Screens_xint" />
            <screen ref="s14@Interviews_Screens_xint" />
            <screen ref="s22@Interviews_Screens_xint" />
            <screen ref="s15@Interviews_Screens_xint" />
            <screen ref="s16@Interviews_Screens_xint" />
            <screen ref="s17@Interviews_Screens_xint" />
            <screen ref="s18@Interviews_Screens_xint" />
            <screen ref="s19@Interviews_Screens_xint" />
            <screen ref="s20@Interviews_Screens_xint" />
            <screen ref="s21@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Employer</caption>
          <items>
            <screen ref="s3@Interviews_Screens_xint" />
            <folder>
              <caption>Employer-Information</caption>
              <items />
            </folder>
          </items>
        </folder>
        <for-each relationship="global_cont_employer">
          <items>
            <folder>
              <caption>Employment</caption>
              <items>
                <screen ref="s4@Interviews_Screens_xint" />
                <for-each relationship="employer_cont_employment">
                  <items>
                    <folder>
                      <caption>Employment-Information</caption>
                      <items>
                        <screen ref="s6@Interviews_Screens_xint" />
                      </items>
                    </folder>
                  </items>
                </for-each>
                <for-each relationship="employer_cont_employment">
                  <items>
                    <folder>
                      <caption>Separation</caption>
                      <items>
                        <screen ref="s5@Interviews_Screens_xint" />
                      </items>
                    </folder>
                  </items>
                </for-each>
              </items>
            </folder>
          </items>
        </for-each>
        <folder>
          <caption>Able and Available</caption>
          <items>
            <screen ref="s26@Interviews_Screens_xint" />
            <screen ref="s27@Interviews_Screens_xint" />
            <screen ref="s28@Interviews_Screens_xint" />
            <screen ref="s29@Interviews_Screens_xint" />
            <screen ref="s30@Interviews_Screens_xint" />
            <screen ref="s31@Interviews_Screens_xint" />
            <screen ref="s32@Interviews_Screens_xint" />
            <screen ref="s33@Interviews_Screens_xint" />
            <screen ref="s34@Interviews_Screens_xint" />
            <screen ref="s35@Interviews_Screens_xint" />
            <screen ref="s36@Interviews_Screens_xint" />
            <screen ref="s37@Interviews_Screens_xint" />
            <screen ref="s38@Interviews_Screens_xint" />
            <screen ref="s39@Interviews_Screens_xint" />
            <screen ref="s40@Interviews_Screens_xint" />
            <screen ref="s41@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Ability to Work</caption>
          <items>
            <screen ref="s42@Interviews_Screens_xint" />
            <screen ref="s43@Interviews_Screens_xint" />
            <screen ref="s44@Interviews_Screens_xint" />
            <screen ref="s45@Interviews_Screens_xint" />
            <screen ref="s46@Interviews_Screens_xint" />
            <screen ref="s47@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>NotReadyForPrimeTimeEmploymentDetails</caption>
          <items>
            <screen ref="s48@Interviews_Screens_xint" />
            <screen ref="s49@Interviews_Screens_xint" />
            <screen ref="s50@Interviews_Screens_xint" />
            <screen ref="s51@Interviews_Screens_xint" />
            <screen ref="s52@Interviews_Screens_xint" />
            <screen ref="s53@Interviews_Screens_xint" />
            <screen ref="s54@Interviews_Screens_xint" />
            <screen ref="s55@Interviews_Screens_xint" />
            <screen ref="s56@Interviews_Screens_xint" />
            <screen ref="s57@Interviews_Screens_xint" />
            <screen ref="s58@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>NotReadyForPrimeTimeSeparation</caption>
          <items>
            <screen ref="s59@Interviews_Screens_xint" />
            <screen ref="s60@Interviews_Screens_xint" />
            <screen ref="s61@Interviews_Screens_xint" />
            <screen ref="s62@Interviews_Screens_xint" />
            <screen ref="s63@Interviews_Screens_xint" />
            <screen ref="s64@Interviews_Screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Final</caption>
          <items>
            <screen ref="s65@Interviews_Screens_xint" />
          </items>
        </folder>
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>