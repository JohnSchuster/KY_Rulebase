<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Initial Determination" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>
&lt;h2&gt;Important Notice&lt;/h2&gt;
&lt;p&gt;This is an application for Unemployment Insurance.
Knowingly submitting false information to obtain benefits is a criminal act.&lt;br&gt; 
Any violation will result in prosecution under KRS.341.370(2)&lt;/p&gt;

&lt;br&gt;
&lt;font color="red"&gt;&lt;p&gt;YOU ARE RESPONSIBLE FOR THE ACCURACY OF ALL OF YOUR ANSWERS&lt;/p&gt;&lt;/font&gt;
&lt;br&gt;
&lt;p&gt;You are also responsible for reading the Rights and Responsibilities section located elsewhere on this site.&lt;/p&gt;
&lt;i&gt;To File Your Kentucky Unemployment Claim You will Need:&lt;/i&gt;
&lt;br&gt;&lt;br&gt;
&lt;i&gt;Information about you&lt;/i&gt;
&lt;br&gt;
&lt;ul&gt;
  &lt;li&gt; Social Security Number&lt;/li&gt;
  &lt;li&gt; Date of Birth&lt;/li&gt;
  &lt;li&gt; Your complete and current mailing address (including zip code)&lt;/li&gt;
  &lt;li&gt; Phone Number (including area code)&lt;/li&gt;
  &lt;li&gt; Alien Registration Number (non-US citizens only) &lt;/li&gt;
&lt;/ul&gt;

&lt;i&gt;Employment Information: (for the last 18 months)&lt;/i&gt;&lt;br&gt;

&lt;ul&gt;
  &lt;li&gt; Company - name&lt;/li&gt;
  &lt;li&gt; Company - complete and current mailing address (including zip code)&lt;/li&gt;
  &lt;li&gt; Company - Phone Number (including area code)&lt;/li&gt;
  &lt;li&gt; Dates of Employment (Starting –through - Ending)&lt;/li&gt;
  &lt;li&gt; Reason(s) you are no longer working (for each employer listed)&lt;/li&gt;
&lt;/ul&gt;

&lt;i&gt;Other Information You May Need:&lt;/i&gt;&lt;br&gt; 

&lt;ul&gt;
  &lt;li&gt;A list of States you worked in (Other than Kentucky)&lt;/li&gt;
  &lt;li&gt;A list of names of Temporary Staffing Agency’s&lt;/li&gt;
  &lt;li&gt;If employed by the Federal Government – Agency Name and Component Name as well as a copy of SF8&lt;/li&gt;
  &lt;li&gt;If engaged as a member of the United States Armed Forces –a copy of DD214 member 4.&lt;/li&gt;
  &lt;li&gt;If an active member of a Trade Union – A list of contractors for whom you worked.&lt;/li&gt;
&lt;/ul&gt;

&lt;font color="blue"&gt;&lt;i&gt;*If you do not have this information available&lt;/i&gt;&lt;/font&gt;
&lt;ul&gt;
  &lt;li&gt;Log-off &lt;/li&gt;
  &lt;li&gt;Gather the required information&lt;/li&gt;
  &lt;li&gt;Return to this site and continue the claim filing process.&lt;/li&gt;
&lt;/ul&gt;

&lt;h4&gt;This filing process takes about thirty (30) minutes to finish. Please set aside enough time to complete this process.&lt;br&gt;
At the completion of your claim, you will receive a confirmation page. &lt;br&gt;
If you do not see a confirmation page, your claim did not process successfully.&lt;/h4&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <goal-control type="Goal" flow="f1@Interviews_IFFClaimInterview_xint">
        <visibility default="enabled" />
        <caption>When you are ready to start your interview, click here</caption>
        <internal-properties>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </goal-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s12@Interviews_IFFClaimInterview_xint" title="Kentucky Employment Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="b4@Rules_KentuckyIsNotLiable_doc" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Did you work in Kentucky during your base period?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="b5@Rules_KentuckyIsNotLiable_doc" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Are you receiving Unemployment Benefits from a state other than Kentucky?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s14@Interviews_IFFClaimInterview_xint" title="Personal Information" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;i&gt;The following questions will help us should there be a problem with your application&lt;/i&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_alias" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Have you ever been known by a different name?
(Example - maiden name)&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="i_claimant_birthday" input-type="default">
        <default attr="i_claimant_birthday" default="1960-01-01" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Your birthday</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">d</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">True</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_home_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Primary phone&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_cell_phone" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Other phone&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_email" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;E-Mail&lt;/p&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;i&gt;The following questions are optional and are for statistical purposes only&lt;/i&gt;&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_gender" input-type="Dropdown">
        <default default="Male" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Gender:&lt;/p&gt;</caption>
        <list>
          <option text="Male" default-visibility="true">Male</option>
          <option text="Female" default-visibility="true">Female</option>
          <option text="No Answer" default-visibility="true">No Answer</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_ethnicity" input-type="Dropdown">
        <default default="Not Hispanic or Latino" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Ethnic group&lt;/p&gt;</caption>
        <list>
          <option text="Hispanic or Latino" default-visibility="true">Hispanic or Latino</option>
          <option text="Not Hispanic or Latino" default-visibility="true">Not Hispanic or Latino</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_race" input-type="Dropdown">
        <default default="White" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;Race&lt;/p&gt;</caption>
        <list>
          <option text="White" default-visibility="true">White</option>
          <option text="Black or African American" default-visibility="true">Black or African American</option>
          <option text="Asian" default-visibility="true">Asian</option>
          <option text="American Indian or Alaskan Native" default-visibility="true">American Indian or Alaskan Native</option>
          <option text="Native Hawaiian or Other Pacific Islander" default-visibility="true">Native Hawaiian or Other Pacific Islander</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_disability" input-type="Dropdown">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do you have a disability&lt;/p&gt;</caption>
        <list>
          <option text="Yes" default-visibility="true">true</option>
          <option text="No" default-visibility="true">false</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s54@Interviews_IFFClaimInterview_xint" title="Federal/Military" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_armed_forces" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Did you serve in the military during your base period?
&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_federal" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Were you employed by the Federal government during your base period?
&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_postal" input-type="default">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Did you work for the US Post office during your base period?
&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s122@Interviews_IFFClaimInterview_xint" title="Pension and other Compensation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_pension_benifit" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Are you currently receiving a pension check from and employer you worked for during your base period ?
&lt;br/&gt;&lt;br/&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_workers_comp" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Are you receiving - or have you applied for; workers compensation payments during your base period?
&lt;br/&gt;&lt;br/&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s124@Interviews_IFFClaimInterview_xint" title="Resident  Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_us_citizen" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Are you a US citizen?
&lt;br&gt;&lt;br&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_in_kentucky_filing" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_work_in_other_state" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Other than being on a military assignment,&lt;br&gt;
did you work in a state other than Kentucky duiring your base period?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s71@Interviews_IFFClaimInterview_xint" title="Payment Method Informatiom" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;b&gt;&lt;h3&gt;Important Notice&lt;/h3&gt;&lt;/b&gt;
Intentionally submitting false information about your Payment Method is a criminal act.
Any violation will result in prosecution under KRS.341.370(2)&lt;br/&gt;&lt;br/&gt;
&lt;font color="red"&gt;&lt;b&gt;
YOU ARE RESPONSIBLE FOR THE ACCURACY OF PAYMENT METHOD DATA&lt;/b&gt;&lt;/font&gt;
&lt;br/&gt;
&lt;h3&gt;&lt;font color="blue"&gt;Facts About Checks:&lt;/font&gt;&lt;/h3&gt;
&lt;br/&gt;
&lt;ol&gt;
&lt;li&gt;You should receive your check within 3–4 business days of making your claim for benefit.&lt;/li&gt;
&lt;li&gt;You must make your request for benefits on the date you are given at the completion of filing your claim and every 2 weeks thereafter.&lt;/li&gt;
&lt;li&gt;To enroll in Direct Deposit for payment of Unemployment Insurance, please – choose Direct Deposit from the list below.&lt;/li&gt;
&lt;/ol&gt;
&lt;br/&gt;
&lt;h3&gt;&lt;font color="blue"&gt;Facts About Direct Deposit:&lt;/font&gt;&lt;/h3&gt;
&lt;br/&gt;
&lt;ol&gt;
&lt;li&gt;Enrolment in direct Deposit is not a request for benefits. You must make your request for benefits on the date you are given at the completion of your claim and every 2 weeks thereafter.&lt;/li&gt;
&lt;li&gt;You should expect a deposit in your account within 3-4 business days &lt;b&gt;&lt;i&gt;after requesting your benefits.&lt;/i&gt;&lt;/b&gt;&lt;/li&gt;
&lt;li&gt;You can confirm deposit of your unemployment insurance benefits by contacting your bank.&lt;/li&gt;
&lt;li&gt;New or changed direct deposits will result in one paper check after submission.&lt;/li&gt;
&lt;li&gt;The Office of Employment and Training must be notified of any account changes &lt;b&gt;&lt;i&gt;immediately&lt;/i&gt;&lt;/b&gt; in order to ensure proper payment of funds.&lt;/li&gt;
&lt;li&gt;Should the bank not be able to process the deposited funds into the specified account, the claimant is responsible for any resulting bank fees incurred.&lt;/li&gt;
&lt;li&gt;The authorization to deposit funds into the noted account will remain in effect until the claimant initiates a change.&lt;/li&gt;
&lt;/ol&gt;
&lt;br/&gt;&lt;br/&gt;

</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_payment_method" input-type="Dropdown">
        <default default="Check" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Based on the information above, what is Your preferred method of payment?</caption>
        <list>
          <option text="Check" default-visibility="true">Check</option>
          <option text="Direct  Deposit" default-visibility="true">Direct  Deposit</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_federal_tax" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Do you want 10 percent of your benefit check withheld for federal taxes?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_state_tax" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Do You want 4 percent of your benefit check withheld for State Taxes?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;&lt;font color="blue"&gt;A note about having us withhold taxes (federal and state)&lt;/font&gt;&lt;/h3&gt;&lt;br&gt;&lt;br&gt;
Selecting No for this option will not relieve you of your obligation to pay federal and state tax&lt;br&gt;
If you do not elect to have us withhold taxes, please make sure set aside enough to pay yor tax liability in April
&lt;br&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s134@Interviews_IFFClaimInterview_xint" title="Rights and Responsibilities" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;CERTIFICATION/AUTHORIZATION&lt;/h2&gt;&lt;br&gt;&lt;br&gt;
&lt;p&gt;I certify that the information on this claim for unemployment benefits is true and correct to the best of my knowledge.&lt;br&gt;
 I certify that I have read and understand the (PAM-UI-400), Rights and Responsibilities pamphlet and accept responsibility&lt;br&gt;
 for reading this pamphlet and asking questions of claims personnel if I do not understand the instructions or any procedures &lt;br&gt;
law or regulation affecting my claim. I understand that any false statements or omissions of material facts to obtain benefits is&lt;br&gt;
 punishable by fine or imprisonment. I AUTHORIZE my former employer(s) to release all information &lt;br&gt;
requested in connection with my claim for unemployment benefits.&lt;/p&gt;&lt;br&gt;&lt;br&gt;
&lt;p&gt;You may access The Rights and Responsibilities pamphlet (PAM-UI-400) over the internet by clicking &lt;a href="https://uiclaims.des.ky.gov/eBenefits_enu/help/PAM_UI_400.htm"&gt;here&lt;/a&gt; &lt;br/&gt;or by visiting your local Unemployment Insurance Office.&lt;/p&gt;&lt;br&gt;&lt;br&gt;
&lt;p&gt;Due to recent changes in the Unemployment Insurance law, you must now serve a  one week waiting period per benefit year.&lt;br&gt;
Your waiting week will always be your first payable week. You will request benefits for a two week period. If you are otherwise eligible, &lt;br&gt;
the amount of your first check will only be for one week. For further information, &lt;a href="http://www.kewes.ky.gov/"&gt;Please Click Here&lt;/a&gt;&lt;/p&gt;
&lt;br/&gt;&lt;br/&gt;&lt;br/&gt;
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Text" attr="i_access_pam" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>I was given access to the PAM-UI-400 Rights and Responsibilities pamphlet </caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_understand" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>I understand that I must report &lt;b&gt;all wages earned&lt;/b&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Text" attr="i_understand_waiting" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>I understand that effective January 1st, 2012, Kentucky Unemployment Insurance Law requires one (waiting week) per benifit year</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br/&gt;&lt;br/&gt;
Your waiting week will always be your first payable week. You will request benefits for a two week period&lt;br&gt;
If you are otherwise eligible, the amount of your first check will only be for one week&lt;br&gt;
Your maximum benifit amount will not change&lt;br&gt;&lt;br&gt;
 </caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>Please enter your First Name, Middle Initial and Last Name in the space provided to CERTIFY&lt;br&gt;
The information provided and AUTHORIZE Unemployment Benefits claim Initiation&lt;br/&gt;&lt;br/&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s138@Interviews_IFFClaimInterview_xint" title="Confirmation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;br/&gt;
%i_first_name% %i_last_name% : Reference number is: U812
&lt;br/&gt;
File Date:
&lt;br/&gt;&lt;br/&gt;
The date to begin requesting your check for&lt;br&gt;
Unemployment Insurance benefits is :  07-OCT-2012&lt;br/&gt;
&lt;br/&gt;
Please use the following time frame to request your benefit checks - &lt;font color="green"&gt;every two weeks&lt;/font&gt;
&lt;br/&gt;
&lt;br/&gt;
All Unemployment Insurance claimants needing to request a benefit check&lt;br&gt;
may may do so by clicking &lt;a href="http://www.kewes.ky.gov/"&gt;Here&lt;/a&gt;&lt;br/&gt;&lt;br/&gt;
&lt;br/&gt;
Unemployment Insurance (UI) and Emergency Unemployment Compensation (EUC)&lt;br&gt;
claimants may also use the phone system by calling (877) 365.5534 
&lt;br/&gt;
&lt;br/&gt;
&lt;br/&gt;
&lt;h6&gt;Good-eye-mate&lt;/h6&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s64@Interviews_IFFClaimInterview_xint" title="Disqualified" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;b&gt;Your Registration Failed&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;
Your application for Unemployment Insurance with the State of Kentucky has been denied.&lt;br/&gt;&lt;br/&gt;
&lt;b&gt;Right to Protest or Appeal&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;
&lt;ol&gt;
&lt;li&gt;You have the right to protest or appeal this decision within 30 day of receiving this notice.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;In your protest or appeal, indicate the reason(s) why you do not agree with
the (re)determination. Also, provide any new or additional facts not
presented in your first statement.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;Attach copies of any documents, employer notices, correspondence, or
other types of information which may clarify the issue you are protesting.
These documents will not be returned so you should send duplicates or
copies.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;You must protest in writing or by fax.  In order to be on time, your protest
must be received by the bureau within 30 days of the date of this
determination&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;If your protest is not received in time, it will affect the decision you receive.&lt;/li&gt;&lt;br/&gt;
&lt;li&gt;If the 30 day protest period has already elapsed, your statement should
indicate why your protest was not on time.&lt;/li&gt;&lt;br/&gt;
&lt;/ol&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s45@Interviews_IFFClaimInterview_xint" title="Claim Explanations" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;About the base period&lt;/h2&gt;
&lt;ul&gt;
&lt;li&gt;Your claim for Unemployment Insurance is effective the Sunday of the week in which you complete your claim.&lt;/li&gt;
&lt;li&gt;The benefit year effective date is the date that your claim for Unemployment benefits officially begins.&lt;/li&gt;
&lt;li&gt;The expire date is the date your benefit year ends – usually 52 weeks following the effective date.&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;Your benefit year effective date is: &amp;nbsp15-SEP-2012&lt;/p&gt;

&lt;ul&gt;
&lt;li&gt;Your base period is the first four of the last five completed calendar quarters immediately prior to the quarter in which you file your claim.&lt;/li&gt;
&lt;li&gt;The base period beginning date is the start of the 12 month period and the base period ending date is the ending date of that 12 month period.&lt;/li&gt;
&lt;li&gt;Your earnings during this 12 month period will determine your weekly benefit amount.&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;
The time between the base period start date and the base period end date is your &lt;b&gt;base period&lt;/b&gt;
&lt;br&gt;
Your base period start date is:&amp;nbsp &amp;nbsp 1-APR-2011&lt;br&gt;
Your base period end date is: &amp;nbsp 31-MAR-2012&lt;br&gt;&lt;br&gt;
&lt;font color="blue"&gt;Please make note of what your base period is &lt;br&gt; 
Several questions we ask will concern events during &lt;b&gt;your base period&lt;/b&gt;&lt;/font&gt;

&lt;br/&gt;&lt;br/&gt;
You will receive notice of the weekly amount of your claim and the maximum amount of money you can receive. &lt;br&gt;This amount is only applicable until your benefit year expiration date.&lt;br/&gt;&lt;br/&gt;
&lt;/p&gt;
&lt;br/&gt;&lt;br/&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h4&gt;&lt;font color="red"&gt;The Questions on the following screens are necessary to process your claim.&lt;br/&gt;
Incomplete or Inaccurate answers will delay your benifits&lt;/font&gt;&lt;/h4&gt;&lt;br/&gt;&lt;br/&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s139@Interviews_IFFClaimInterview_xint" title="Labor Union" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_union_member" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_union_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s140@Interviews_IFFClaimInterview_xint" title="Alien Status" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;%i_first_name% &amp;nbsp %i_last_name%&lt;br&gt;
Your base period is %i_base_start% through %i_base_end% &lt;/h2&gt; 
</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </control>
      <input-control type="Statement" attr="i_legal_alien" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_spouse_legal_alien" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="i_spouse_of_citizen" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s147@Interviews_IFFClaimInterview_xint" title="Ability to work" entity="global">
      <input-control type="Statement" attr="fpr_physically_able_to_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you physically able to work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Statement" attr="fpr_mentally_able" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Are you mentally able to work?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s155@Interviews_IFFClaimInterview_xint" title="Mental Ability" entity="global">
      <input-control type="Statement" attr="fpr_mental_prevents_work" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Do your mental health problems prevent you from working?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_mental_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your mental health problems began?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_mental_end" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect to be healty enough to return to work ?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s157@Interviews_IFFClaimInterview_xint" title="Physical ability" entity="global">
      <input-control type="Statement" attr="fpr_physical_prevents_work" input-type="default">
        <default default="true" />
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;Does your physical health restriction prevent you from working?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_physical_start" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When did your physical health problems began?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">ymd</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <input-control type="Date" attr="fc_physical_end" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>&lt;p&gt;When do you expect to be healty enough to return to work ?&lt;/p&gt;</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="__input-style" type="string">ymd</property>
          <property name="IsHTML" type="boolean">true</property>
        </internal-properties>
        <custom-properties>
          <property name="UseCalendarDateControl">False</property>
        </custom-properties>
      </input-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="Data Review">
      <items>
        <screen ref="s45@Interviews_IFFClaimInterview_xint" />
        <screen ref="s12@Interviews_IFFClaimInterview_xint" />
        <screen ref="s14@Interviews_IFFClaimInterview_xint" />
        <screen ref="s54@Interviews_IFFClaimInterview_xint" />
        <screen ref="s122@Interviews_IFFClaimInterview_xint" />
        <screen ref="s139@Interviews_IFFClaimInterview_xint" />
        <screen ref="s124@Interviews_IFFClaimInterview_xint" />
        <screen ref="s71@Interviews_IFFClaimInterview_xint" />
        <screen ref="s134@Interviews_IFFClaimInterview_xint" />
        <screen ref="s138@Interviews_IFFClaimInterview_xint" />
        <screen ref="s64@Interviews_IFFClaimInterview_xint" />
        <screen ref="s140@Interviews_IFFClaimInterview_xint" />
        <screen ref="s147@Interviews_IFFClaimInterview_xint" />
        <screen ref="s157@Interviews_IFFClaimInterview_xint" />
        <screen ref="s155@Interviews_IFFClaimInterview_xint" />
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>