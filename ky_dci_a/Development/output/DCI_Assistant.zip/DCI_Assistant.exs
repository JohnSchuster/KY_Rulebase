<?xml version="1.0" encoding="utf-8"?>
<interactive-components schema-version="7" xml:lang="en-US" region="en-US">
  <screen-set>
    <screen type="Summary" id="summary" title="Disputed Claim Investigator's Assistant" entity="global">
      <control type="Label">
        <visibility attr="label_investigation_open" default="false" />
        <caption>&lt;h3&gt;Investigation Status: Open&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h2&gt;Id: %claimant_pii_full_name% %i_claimant_pii_ssn%,%i_claim_ref%,%i_issue_type%,%i_issue_sequence_cd%&lt;/h2&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;h3&gt;Prima facie Evidence&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <container-control type="RelationshipContainer" entity="global">
        <caption>Evidence</caption>
        <visibility default="true" />
        <goal-control type="Goal" flow="f5@Interviews_screens_xint">
          <visibility default="enabled" />
          <caption>Claimant Separation Statements</caption>
          <internal-properties>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control type="Goal" flow="f12@Interviews_screens_xint">
          <visibility default="enabled" />
          <caption>Claimant Non-Separation</caption>
          <internal-properties>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control type="Goal" flow="f6@Interviews_screens_xint">
          <visibility default="enabled" />
          <caption>Employer Separation Statements</caption>
          <internal-properties>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </goal-control>
        <internal-properties />
        <custom-properties />
      </container-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;&lt;h3&gt;Pinpointing:  Policy Driven Q&amp;A &lt;/h3&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <container-control type="RelationshipContainer" entity="global">
        <caption>Policy Guided Investigation</caption>
        <visibility default="true" />
        <goal-control attr="o_decision_report">
          <caption type="unknown">Click here to determine if the notice of determination (decision report), is available</caption>
          <visibility default="enabled" />
          <internal-properties>
            <property name="IsHTML" type="boolean">false</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control attr="b50@Rules_Functional_Goals_doc">
          <caption type="unknown">Click here to determine if the claim should be disqualified</caption>
          <visibility default="enabled" />
          <internal-properties>
            <property name="IsHTML" type="boolean">true</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control attr="claimant_legal_resident">
          <caption type="unknown">Investigate whether the claimant is currently a legal resident for purposes of Kentucky unemployment insurance</caption>
          <visibility default="enabled" />
          <internal-properties>
            <property name="IsHTML" type="boolean">false</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control attr="b7@Rules_System_DisplayVisibility_doc">
          <caption type="unknown">Investigate whether  the most recent employer is chargeable</caption>
          <visibility default="enabled" />
          <internal-properties>
            <property name="IsHTML" type="boolean">true</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </goal-control>
        <goal-control attr="claimant_quit_voluntarily">
          <caption type="unknown">Click here to determine if the claimant quit voluntarily</caption>
          <visibility default="enabled" />
          <internal-properties>
            <property name="IsHTML" type="boolean">false</property>
            <property name="StyleOverride" type="string" />
            <property name="ClassOverride" type="string" />
          </internal-properties>
          <custom-properties />
        </goal-control>
        <internal-properties />
        <custom-properties />
      </container-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;&lt;h3&gt;Edit 492 NOD Content&lt;/h3&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <container-control type="RelationshipContainer" entity="global">
        <caption>Document</caption>
        <visibility default="true" />
        <goal-control type="Goal" flow="f7@Interviews_screens_xint">
          <visibility default="enabled" />
          <caption>Edit Document UI NOD (4V 492)</caption>
          <internal-properties>
            <property name="ClassOverride" type="string" />
            <property name="StyleOverride" type="string" />
            <property name="IsHTML" type="boolean">false</property>
          </internal-properties>
          <custom-properties />
        </goal-control>
        <internal-properties />
        <custom-properties />
      </container-control>
      <control type="Label">
        <visibility default="true" />
        <caption>TODO:  Base the primary investigation decision on the issue type invoked.  Allow new issues to be raised during investigation?  how to capture and control?</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s6@Interviews_screens_xint" title="Separation Claimant" entity="global">
      <input-control type="Statement" attr="i_secondary_stress" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Claimant give pressure or stress as the secondary reason for separation:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string">&lt;h3&gt;</property>
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="documented_harassment" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Claimant has proven evidence of documented harassment:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string">&lt;h3&gt;</property>
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="b13@Rules_PolicyBase_Quit_doc" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Claimant has shown evidence of unreasonable reprimands:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string">&lt;h3&gt;</property>
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s7@Interviews_screens_xint" title="Non-Separation" entity="global">
      <control type="Label">
        <visibility default="true" />
        <caption>EXAMPLE: This screen captures the non-separation ststements, placed into evidence by the claimant. 
It allows the DCI to select/ mark specific ( controversial or conflicted ) statements for  investigation.
</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 3</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Statement" attr="claimant_nonsep_in_school" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="b40@Rules_Functional_Goals_doc" input-type="checkbox">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>DCI Discretion: Is attending training, an acceptable constraint?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="claimant_unable_to_work" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="b37@Rules_Functional_Goals_doc" input-type="checkbox">
        <default default="false" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>DCI Discretion: Is inability to work, an acceptable constraint?</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>ETC...</caption>
        <internal-properties>
          <property name="text-style" type="string">Heading 2</property>
          <property name="IsHTML" type="boolean">false</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s8@Interviews_screens_xint" title="Separation: Employer" entity="global">
      <input-control type="Statement" attr="b19@Rules_Functional_Goals_doc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="b20@Rules_Functional_Goals_doc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="b12@Rules_Functional_Goals_doc" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s9@Interviews_screens_xint" title="Edit Most Recent Employer Details for %i_claimant_pii_ssn%" entity="global">
      <input-control type="Text" attr="mre_phone_number" input-type="default">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>Phone number:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="mer_company_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Company name:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="mre_addr_l1" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Company address line 1:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="mre_addr_l2" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Company address line 2:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="mre_city_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>City:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="mre_zip_code" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Zip code:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s11@Interviews_screens_xint" title="Edit Claimant Details" entity="global">
      <input-control type="Text" attr="claimant_pii_full_name" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <caption>Claimant's full name:</caption>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s13@Interviews_screens_xint" title="Alien legal Status" entity="global">
      <input-control type="Statement" attr="claimant_is_citizen" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="claimant_is_legal_alien" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="claimant_spouse_us-citizen" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Statement" attr="claimant_spouse_us_citizen" input-type="checkbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <control type="Label">
        <visibility default="true" />
        <caption>&lt;hr&gt;</caption>
        <internal-properties>
          <property name="text-style" type="string">Normal</property>
          <property name="IsHTML" type="boolean">true</property>
          <property name="ClassOverride" type="string" />
          <property name="StyleOverride" type="string" />
        </internal-properties>
        <custom-properties />
      </control>
      <input-control type="Text" attr="dci_reason_legal_alien" input-type="Listbox">
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <caption>&lt;h3&gt;DCI reason, claimant is legal alien because?&lt;/h3&gt;</caption>
        <list>
          <option text="Section 203(a)(7) INA" default-visibility="true">Section 203(a)(7) INA</option>
          <option text="Section 212(d)(5) INA" default-visibility="true">Section 212(d)(5) INA</option>
          <option text="Lawfully Admitted" default-visibility="true">Lawfully Admitted</option>
          <option text="Lawfully Present" default-visibility="true">Lawfully Present</option>
          <option text="Residing Under Color Of Law" default-visibility="true">Under Color Of Law</option>
        </list>
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">true</property>
          <property name="__list-name" type="string" />
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
    <screen type="Question" id="s14@Interviews_screens_xint" title="Authorization for Approved Attendance at School Or Training" entity="global">
      <input-control type="Text" attr="training_institution" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Text" attr="training_auth_code" input-type="default">
        <visibility default="true" />
        <mandatory default="true" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="lines" type="integer">1</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="training_auth_start_date" input-type="default">
        <default attr="default_training_auth_start" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <input-control type="Date" attr="training_auth_end_date" input-type="default">
        <default attr="default_training_auth_end" />
        <visibility default="true" />
        <mandatory default="false" />
        <read-only default="false" />
        <internal-properties>
          <property name="StyleOverride" type="string" />
          <property name="ClassOverride" type="string" />
          <property name="IsHTML" type="boolean">false</property>
          <property name="__input-style" type="string">ymd</property>
        </internal-properties>
        <custom-properties />
      </input-control>
      <custom-properties />
    </screen>
  </screen-set>
  <screen-order-set>
    <screen-order id="DefaultScreenOrder" entity="global" title="DCI Investigation Review Screen">
      <items>
        <folder>
          <caption>Findings (in Evidence)</caption>
          <items>
            <screen ref="s6@Interviews_screens_xint" />
            <screen ref="s7@Interviews_screens_xint" />
            <screen ref="s8@Interviews_screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Edit Document UI-NOD-4V492</caption>
          <items>
            <screen ref="s9@Interviews_screens_xint" />
            <screen ref="s11@Interviews_screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>Public Law</caption>
          <items>
            <screen ref="s13@Interviews_screens_xint" />
          </items>
        </folder>
        <folder>
          <caption>DCI Data Capture</caption>
          <items>
            <screen ref="s14@Interviews_screens_xint" />
          </items>
        </folder>
      </items>
    </screen-order>
  </screen-order-set>
  <document-set />
</interactive-components>